"""
Generate Sample Test Documents for Insurance Claim Testing
Creates PDFs for: medical_report, hospital_bill, discharge_summary, id_proof, prescription
"""

from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY
from datetime import datetime
import os

def create_medical_report_pdf():
    """Create sample medical report PDF"""
    filename = "medical_report.pdf"
    doc = SimpleDocTemplate(filename, pagesize=letter, rightMargin=0.5*inch, leftMargin=0.5*inch)
    story = []
    styles = getSampleStyleSheet()
    
    # Header
    story.append(Paragraph("MEDICAL REPORT", styles['Heading1']))
    story.append(Spacer(1, 0.2*inch))
    
    # Hospital details
    data = [
        ['Hospital Name:', 'Apollo Hospital, New Delhi'],
        ['Patient Name:', 'Raj Kumar'],
        ['Date of Admission:', '2024-02-20'],
        ['Date of Discharge:', '2024-02-25'],
        ['Duration:', '5 Days'],
    ]
    table = Table(data, colWidths=[2*inch, 4*inch])
    table.setStyle(TableStyle([('GRID', (0, 0), (-1, -1), 1, colors.black)]))
    story.append(table)
    story.append(Spacer(1, 0.2*inch))
    
    # Diagnosis
    story.append(Paragraph("<b>DIAGNOSIS:</b>", styles['Heading2']))
    story.append(Paragraph("Acute Coronary Syndrome (ACS) - ICD Code: I24.9", styles['Normal']))
    story.append(Spacer(1, 0.2*inch))
    
    # Chief complaint
    story.append(Paragraph("<b>CHIEF COMPLAINT:</b>", styles['Heading2']))
    story.append(Paragraph("Acute chest pain and breathlessness", styles['Normal']))
    story.append(Spacer(1, 0.2*inch))
    
    # Investigations
    story.append(Paragraph("<b>INVESTIGATIONS:</b>", styles['Heading2']))
    inv_data = [
        ['Test', 'Result', 'Normal Range'],
        ['ECG', 'ST elevation in leads II, III, aVF', 'Normal'],
        ['Troponin I', '2.8 ng/mL', '<0.04'],
        ['CK-MB', '85 U/L', '<5'],
    ]
    inv_table = Table(inv_data, colWidths=[1.5*inch, 2*inch, 1.5*inch])
    inv_table.setStyle(TableStyle([('GRID', (0, 0), (-1, -1), 1, colors.black),
                                   ('BACKGROUND', (0, 0), (-1, 0), colors.grey)]))
    story.append(inv_table)
    story.append(Spacer(1, 0.2*inch))
    
    # Treatment
    story.append(Paragraph("<b>TREATMENT PROVIDED:</b>", styles['Heading2']))
    story.append(Paragraph("1. Emergency Cardiac Catheterization - 2024-02-20", styles['Normal']))
    story.append(Paragraph("2. Percutaneous Coronary Intervention (PCI) with stent placement in RCA", styles['Normal']))
    story.append(Paragraph("3. Aspirin 300 mg loading dose", styles['Normal']))
    story.append(Paragraph("4. Clopidogrel 600 mg loading dose", styles['Normal']))
    story.append(Spacer(1, 0.2*inch))
    
    # Doctor signature
    story.append(Paragraph("<b>ATTENDING PHYSICIAN:</b>", styles['Heading2']))
    story.append(Paragraph("Dr. Rajesh Kumar, MD, DM (Cardiology)", styles['Normal']))
    story.append(Paragraph("License No: 12345678", styles['Normal']))
    story.append(Paragraph(f"Date: {datetime.now().strftime('%Y-%m-%d')}", styles['Normal']))
    
    doc.build(story)
    print(f"✅ Created: {filename}")
    return filename

def create_hospital_bill_pdf():
    """Create sample hospital bill PDF"""
    filename = "hospital_bill.pdf"
    doc = SimpleDocTemplate(filename, pagesize=letter, rightMargin=0.5*inch, leftMargin=0.5*inch)
    story = []
    styles = getSampleStyleSheet()
    
    # Header
    story.append(Paragraph("HOSPITAL BILL / INVOICE", styles['Heading1']))
    story.append(Paragraph("Apollo Hospital, New Delhi", styles['Normal']))
    story.append(Spacer(1, 0.2*inch))
    
    # Patient details
    patient_data = [
        ['Bill No:', 'APOL-2024-001234', 'Date:', '2024-02-25'],
        ['Patient Name:', 'Raj Kumar', 'Age:', '48 years'],
        ['Admission Date:', '2024-02-20', 'Discharge Date:', '2024-02-25'],
    ]
    patient_table = Table(patient_data, colWidths=[1.5*inch, 1.5*inch, 1.5*inch, 1.5*inch])
    patient_table.setStyle(TableStyle([('GRID', (0, 0), (-1, -1), 1, colors.black)]))
    story.append(patient_table)
    story.append(Spacer(1, 0.2*inch))
    
    # Charges
    story.append(Paragraph("<b>ITEMIZED CHARGES:</b>", styles['Heading2']))
    charges_data = [
        ['Description', 'Amount (₹)'],
        ['ICU Room Charges (4 nights)', '14,000'],
        ['Nursing & Ancillary Charges', '8,000'],
        ['Doctor Consultation Fees', '15,000'],
        ['Cardiac Catheterization', '41,000'],
        ['Medications & Injections', '12,000'],
        ['Diagnostics & Investigations', '9,500'],
        ['Lab Tests', '4,000'],
        ['Supplies & Materials', '6,000'],
        ['Physiotherapy', '2,000'],
        ['Miscellaneous', '2,500'],
    ]
    charges_table = Table(charges_data, colWidths=[3*inch, 2*inch])
    charges_table.setStyle(TableStyle([('GRID', (0, 0), (-1, -1), 1, colors.black),
                                       ('BACKGROUND', (0, 0), (-1, 0), colors.grey)]))
    story.append(charges_table)
    story.append(Spacer(1, 0.2*inch))
    
    # Total
    story.append(Paragraph("<b>SUBTOTAL (Before GST): ₹84,500</b>", styles['Normal']))
    story.append(Paragraph("<b>GST @ 5%: ₹4,225</b>", styles['Normal']))
    story.append(Paragraph("<b>TOTAL BILL AMOUNT: ₹88,725</b>", styles['Heading2']))
    
    doc.build(story)
    print(f"✅ Created: {filename}")
    return filename

def create_discharge_summary_pdf():
    """Create sample discharge summary PDF"""
    filename = "discharge_summary.pdf"
    doc = SimpleDocTemplate(filename, pagesize=letter, rightMargin=0.5*inch, leftMargin=0.5*inch)
    story = []
    styles = getSampleStyleSheet()
    
    # Header
    story.append(Paragraph("DISCHARGE SUMMARY", styles['Heading1']))
    story.append(Spacer(1, 0.2*inch))
    
    # Details
    story.append(Paragraph("<b>Patient Information:</b>", styles['Heading2']))
    story.append(Paragraph("Name: Raj Kumar | Age: 48 years | Gender: Male", styles['Normal']))
    story.append(Paragraph("Admission Date: 2024-02-20 | Discharge Date: 2024-02-25", styles['Normal']))
    story.append(Spacer(1, 0.2*inch))
    
    # Diagnosis
    story.append(Paragraph("<b>Primary Diagnosis:</b>", styles['Heading2']))
    story.append(Paragraph("Acute Coronary Syndrome (ACS)", styles['Normal']))
    story.append(Spacer(1, 0.2*inch))
    
    # Procedures
    story.append(Paragraph("<b>Procedures Performed:</b>", styles['Heading2']))
    story.append(Paragraph("1. Emergency Cardiac Catheterization", styles['Normal']))
    story.append(Paragraph("2. Percutaneous Coronary Intervention with Drug-Eluting Stent", styles['Normal']))
    story.append(Spacer(1, 0.2*inch))
    
    # Discharge medications
    story.append(Paragraph("<b>Discharge Medications:</b>", styles['Heading2']))
    meds = [
        ['Medication', 'Dosage'],
        ['Aspirin', '75 mg once daily'],
        ['Clopidogrel', '75 mg once daily'],
        ['Bisoprolol', '5 mg once daily'],
        ['Lisinopril', '5 mg once daily'],
        ['Atorvastatin', '40 mg once daily'],
    ]
    meds_table = Table(meds, colWidths=[2.5*inch, 2.5*inch])
    meds_table.setStyle(TableStyle([('GRID', (0, 0), (-1, -1), 1, colors.black)]))
    story.append(meds_table)
    story.append(Spacer(1, 0.2*inch))
    
    # Discharge instructions
    story.append(Paragraph("<b>Discharge Instructions:</b>", styles['Heading2']))
    story.append(Paragraph("1. Strict bed rest for 1 week", styles['Normal']))
    story.append(Paragraph("2. Attend cardiac rehabilitation program", styles['Normal']))
    story.append(Paragraph("3. Follow-up with cardiologist in 2 weeks", styles['Normal']))
    story.append(Paragraph("4. Avoid strenuous activities for 4 weeks", styles['Normal']))
    story.append(Paragraph("5. Low sodium, low cholesterol diet", styles['Normal']))
    story.append(Spacer(1, 0.2*inch))
    
    # Doctor signature
    story.append(Paragraph("<b>Authorized by: Dr. Rajesh Kumar, MD, DM (Cardiology)</b>", styles['Normal']))
    
    doc.build(story)
    print(f"✅ Created: {filename}")
    return filename

def create_id_proof_pdf():
    """Create sample ID proof PDF"""
    filename = "id_proof.pdf"
    doc = SimpleDocTemplate(filename, pagesize=letter, rightMargin=0.5*inch, leftMargin=0.5*inch)
    story = []
    styles = getSampleStyleSheet()
    
    # Header
    story.append(Paragraph("AADHAR CARD (Identity Proof)", styles['Heading1']))
    story.append(Spacer(1, 0.2*inch))
    
    # Details
    id_data = [
        ['Name:', 'Raj Kumar'],
        ['Aadhar Number:', '1234 5678 9012 XXXX'],
        ['Date of Birth:', '15-06-1975'],
        ['Gender:', 'Male'],
        ['Address:', 'Apartment 301, Green Valley Society, New Delhi - 110001'],
        ['Mobile:', '+91-9876543210'],
        ['Email:', 'raj.kumar@email.com'],
        ['Issue Date:', '2020-03-15'],
        ['Valid Until:', 'Lifetime'],
    ]
    id_table = Table(id_data, colWidths=[2*inch, 4*inch])
    id_table.setStyle(TableStyle([('GRID', (0, 0), (-1, -1), 1, colors.black)]))
    story.append(id_table)
    story.append(Spacer(1, 0.3*inch))
    
    # Signature
    story.append(Paragraph("Issued by: Government of India, UIDAI", styles['Normal']))
    story.append(Paragraph(f"Document Date: {datetime.now().strftime('%Y-%m-%d')}", styles['Normal']))
    
    doc.build(story)
    print(f"✅ Created: {filename}")
    return filename

def create_prescription_pdf():
    """Create sample prescription PDF"""
    filename = "prescription.pdf"
    doc = SimpleDocTemplate(filename, pagesize=letter, rightMargin=0.5*inch, leftMargin=0.5*inch)
    story = []
    styles = getSampleStyleSheet()
    
    # Header
    story.append(Paragraph("MEDICAL PRESCRIPTION", styles['Heading1']))
    story.append(Spacer(1, 0.2*inch))
    
    # Doctor details
    story.append(Paragraph("Apollo Hospital Cardiology Department", styles['Normal']))
    story.append(Paragraph("Dr. Rajesh Kumar, MD, DM (Cardiology)", styles['Normal']))
    story.append(Paragraph("License: 12345678", styles['Normal']))
    story.append(Spacer(1, 0.2*inch))
    
    # Patient details
    story.append(Paragraph("<b>Patient Details:</b>", styles['Heading2']))
    story.append(Paragraph("Name: Raj Kumar | Age: 48 years", styles['Normal']))
    story.append(Paragraph("Date: 2024-02-25", styles['Normal']))
    story.append(Spacer(1, 0.2*inch))
    
    # Medications
    story.append(Paragraph("<b>PRESCRIBED MEDICATIONS:</b>", styles['Heading2']))
    rx_data = [
        ['S.No', 'Medicine Name', 'Strength', 'Dosage', 'Duration'],
        ['1', 'Aspirin', '75 mg', 'Once daily after food', '12 months'],
        ['2', 'Clopidogrel', '75 mg', 'Once daily after food', '12 months'],
        ['3', 'Bisoprolol', '5 mg', 'Once daily in morning', 'Ongoing'],
        ['4', 'Lisinopril', '5 mg', 'Once daily at night', 'Ongoing'],
        ['5', 'Atorvastatin', '40 mg', 'Once daily at night', 'Ongoing'],
        ['6', 'Isosorbide Mononitrate', '10 mg', 'Twice daily', 'As needed'],
    ]
    rx_table = Table(rx_data, colWidths=[0.5*inch, 1.8*inch, 1*inch, 1.5*inch, 1.2*inch])
    rx_table.setStyle(TableStyle([('GRID', (0, 0), (-1, -1), 1, colors.black),
                                  ('BACKGROUND', (0, 0), (-1, 0), colors.grey)]))
    story.append(rx_table)
    story.append(Spacer(1, 0.2*inch))
    
    # Warnings
    story.append(Paragraph("<b>IMPORTANT NOTES:</b>", styles['Heading2']))
    story.append(Paragraph("• Do not skip doses without consulting doctor", styles['Normal']))
    story.append(Paragraph("• Avoid alcohol while on medication", styles['Normal']))
    story.append(Paragraph("• Report any side effects immediately", styles['Normal']))
    story.append(Paragraph("• Follow-up visit after 2 weeks", styles['Normal']))
    story.append(Spacer(1, 0.2*inch))
    
    # Doctor signature
    story.append(Paragraph("<b>Doctor Signature:</b>", styles['Heading2']))
    story.append(Paragraph("Dr. Rajesh Kumar", styles['Normal']))
    story.append(Paragraph(f"Date: {datetime.now().strftime('%d-%m-%Y')}", styles['Normal']))
    
    doc.build(story)
    print(f"✅ Created: {filename}")
    return filename

def main():
    """Generate all sample documents"""
    print("\n" + "="*60)
    print("GENERATING SAMPLE DOCUMENTS FOR TESTING")
    print("="*60 + "\n")
    
    # Create directory for documents
    os.makedirs("test_documents", exist_ok=True)
    
    # Change to test documents directory
    original_dir = os.getcwd()
    os.chdir("test_documents")
    
    try:
        # Generate all PDFs
        create_medical_report_pdf()
        create_hospital_bill_pdf()
        create_discharge_summary_pdf()
        create_id_proof_pdf()
        create_prescription_pdf()
        
        print("\n" + "="*60)
        print("✅ ALL SAMPLE DOCUMENTS CREATED SUCCESSFULLY!")
        print("="*60)
        print("\nGenerated Files (in test_documents/ folder):")
        print("  1. medical_report.pdf")
        print("  2. hospital_bill.pdf")
        print("  3. discharge_summary.pdf")
        print("  4. id_proof.pdf")
        print("  5. prescription.pdf")
        print("\nUSAGE:")
        print("  1. Run this script: python generate_test_documents.py")
        print("  2. Files will be created in 'test_documents/' folder")
        print("  3. Use these files for uploading when filing claims")
        print("  4. In Streamlit: File Claim → Upload Documents → Select these PDFs")
        print("\n" + "="*60 + "\n")
        
    finally:
        os.chdir(original_dir)

if __name__ == "__main__":
    main()