"""
INSURANCE CLAIMS SYSTEM - Main App
UI: Futuristic Blue & White with Clean Input Styling
✨ BLUE BORDER GLOW with staggered pulse animation
🎨 WHITE BACKGROUND + BLACK TEXT for all inputs
🔐 PERSISTENT SESSION HANDLING
✅ FIX: Auto-generated sidebar nav (customer home, buy insurance, etc.) fully hidden
✅ FIX: Sidebar hidden completely on login/register page
"""

import streamlit as st
import os
from dotenv import load_dotenv
from modules.data_handler import (
    initialize_files,
    authenticate_user,
    register_user,
    get_user_by_id
)

load_dotenv()
initialize_files()

st.set_page_config(
    page_title="InsureAI — Claims System",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ════════════════════════════════════════════════════════════════
# ✅ HIDE AUTO-NAV — injected immediately after set_page_config
#    Covers every selector Streamlit has used across versions.
# ════════════════════════════════════════════════════════════════

st.markdown("""
<style>
/* ── Streamlit ≤ 1.28 ── */
[data-testid="stSidebarNav"]          { display:none !important; }

/* ── Streamlit 1.29 – 1.35 ── */
[data-testid="stSidebarNavItems"]     { display:none !important; }
[data-testid="stSidebarNavLink"]      { display:none !important; }
[data-testid="stSidebarNavSeparator"] { display:none !important; }

/* ── Streamlit 1.36 + (renamed to stNavigation) ── */
[data-testid="stNavigation"]          { display:none !important; }

/* ── Generic: any <nav> inside the sidebar ── */
section[data-testid="stSidebar"] nav  { display:none !important; }

/* ── Belt-and-suspenders: hide the first <ul> Streamlit injects ── */
section[data-testid="stSidebar"] > div:first-child > div > div > ul {
    display:none !important;
}
section[data-testid="stSidebar"] > div:first-child ul {
    display:none !important;
}
</style>
""", unsafe_allow_html=True)

# ════════════════════════════════════════════════════════════════
# 🔐 PERSISTENT SESSION STATE INITIALIZATION
# ════════════════════════════════════════════════════════════════

def initialize_session_state():
    defaults = {
        'user_logged_in' : False,
        'user_id'        : None,
        'user_name'      : None,
        'user_email'     : None,
        'user_phone'     : None,
        'user_role'      : None,
        'selected_role'  : "customer",
        'login_timestamp': None,
    }
    for key, val in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = val

initialize_session_state()

# ════════════════════════════════════════════════════════════════
# ✨ CSS — BLUE BORDER GLOW + WHITE BG BLACK TEXT
# ════════════════════════════════════════════════════════════════

st.markdown("""
<style>

@import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;600;800&family=Exo+2:wght@300;400;500;600;700&display=swap');

html, body { background: #F0F6FF !important; }
[data-testid="stAppViewContainer"],
[data-testid="stMain"], .main, .block-container,
section.main > div { background: #F0F6FF !important; }

[data-testid="stAppViewContainer"]::before {
    content:''; position:fixed; top:0; left:0; right:0; bottom:0;
    background-image:
        linear-gradient(rgba(0,87,255,0.035) 1px, transparent 1px),
        linear-gradient(90deg, rgba(0,87,255,0.035) 1px, transparent 1px);
    background-size:44px 44px; pointer-events:none; z-index:0;
}

html, body, * { font-family:'Exo 2',sans-serif; color:#0A1628; }
.block-container { padding-top:1rem !important; padding-bottom:1rem !important; }
div[data-testid="stVerticalBlock"] > div { margin-bottom:0 !important; }
.element-container { margin-bottom:0.25rem !important; }
[data-testid="column"] { padding:0 6px !important; }
#MainMenu, footer, header, [data-testid="stDecoration"] { visibility:hidden !important; display:none !important; }

[data-testid="stSidebar"],
[data-testid="stSidebar"] > div,
[data-testid="stSidebar"] section {
    background:linear-gradient(180deg,#060F24 0%,#0B1E4A 55%,#060F24 100%) !important;
    border-right:1px solid rgba(0,212,255,0.25) !important;
    box-shadow:4px 0 30px rgba(0,87,255,0.2) !important;
}

[data-testid="stSidebar"] p,
[data-testid="stSidebar"] span,
[data-testid="stSidebar"] label,
[data-testid="stSidebar"] div { color:#D6EAFF !important; }

[data-testid="stSidebar"] .stRadio > div > label {
    background:rgba(0,87,255,0.08) !important;
    border:1px solid rgba(0,212,255,0.15) !important;
    border-radius:10px !important;
    padding:8px 12px !important; margin:2px 0 !important;
    transition:all 0.2s !important; display:block !important;
    color:#D6EAFF !important;
}

[data-testid="stSidebar"] .stRadio > div > label:hover {
    background:rgba(0,87,255,0.25) !important;
    border-color:rgba(0,212,255,0.5) !important;
    transform:translateX(4px) !important;
}

[data-testid="stSidebar"] hr { border-color:rgba(0,212,255,0.15) !important; margin:8px 0 !important; }

.stTabs [data-baseweb="tab-list"] {
    background:rgba(0,87,255,0.06) !important;
    border-radius:14px !important; padding:4px !important;
    border:1px solid rgba(0,87,255,0.15) !important; gap:4px !important;
}

.stTabs [data-baseweb="tab"] {
    border-radius:10px !important; font-family:'Exo 2',sans-serif !important;
    font-weight:600 !important; font-size:14px !important;
    color:#2D4A7A !important; padding:8px 28px !important;
    background:transparent !important;
}

.stTabs [aria-selected="true"] {
    background:linear-gradient(135deg,#0057FF,#0099FF) !important;
    color:#FFFFFF !important;
    box-shadow:0 4px 15px rgba(0,87,255,0.35) !important;
}

.stButton > button {
    background:linear-gradient(135deg,#0057FF,#0099FF) !important;
    color:#FFFFFF !important; border:none !important;
    border-radius:12px !important; padding:10px 28px !important;
    font-family:'Exo 2',sans-serif !important; font-weight:600 !important;
    font-size:14px !important; transition:all 0.3s ease !important;
    box-shadow:0 4px 18px rgba(0,87,255,0.28) !important;
    margin-top:4px !important;
}

.stButton > button:hover {
    transform:translateY(-2px) !important;
    box-shadow:0 8px 28px rgba(0,87,255,0.5) !important;
}

.stTextInput > div > div {
    background:#FFFFFF !important;
    border:2px solid rgba(0,87,255,0.3) !important;
    border-radius:12px !important; transition:all 0.3s !important;
}

.stTextInput > div > div:focus-within {
    border-color:#0057FF !important;
    box-shadow:0 0 0 3px rgba(0,87,255,0.1),0 0 18px rgba(0,87,255,0.12) !important;
}

.stTextInput > div > div > input {
    background:#FFFFFF !important; color:#000000 !important;
    font-family:'Exo 2',sans-serif !important; font-size:14px !important;
    font-weight:500 !important; caret-color:#0057FF !important;
    border:none !important; box-shadow:none !important; padding:10px 14px !important;
}

.stTextInput > div > div > input::placeholder { color:#666666 !important; }
.stTextInput > div > div > input:focus { outline:none !important; box-shadow:none !important; }

.stTextArea > div > div > textarea {
    background:#FFFFFF !important; border:2px solid rgba(0,87,255,0.3) !important;
    border-radius:12px !important; color:#000000 !important;
    font-family:'Exo 2',sans-serif !important; caret-color:#0057FF !important;
}

.stTextArea > div > div > textarea:focus {
    border-color:#0057FF !important;
    box-shadow:0 0 0 3px rgba(0,87,255,0.1) !important; outline:none !important;
}

.stTextArea > div > div > textarea::placeholder { color:#666666 !important; }

.stSelectbox > div > div {
    background:#FFFFFF !important; border:2px solid rgba(0,87,255,0.3) !important;
    border-radius:12px !important;
}

.stSelectbox > div > div > div { color:#000000 !important; }
.stSelectbox [data-baseweb="select"] > div { background:#FFFFFF !important; }
[data-baseweb="popover"] { background:#FFFFFF !important; }
[data-baseweb="menu"] {
    background:#FFFFFF !important; border:1px solid rgba(0,87,255,0.2) !important;
    border-radius:12px !important;
}
[data-baseweb="menu"] li { color:#000000 !important; background:#FFFFFF !important; }
[data-baseweb="menu"] li:hover { background:rgba(0,87,255,0.1) !important; color:#000000 !important; }

label, .stTextInput label, .stTextArea label, .stSelectbox label {
    font-family:'Exo 2',sans-serif !important; font-size:13px !important;
    font-weight:600 !important; color:#2D4A7A !important;
}

[data-testid="stMetric"] {
    background:#FFFFFF !important; border:1px solid rgba(0,87,255,0.12) !important;
    border-radius:16px !important; padding:16px !important;
    box-shadow:0 4px 18px rgba(0,87,255,0.07) !important;
    transition:transform 0.3s, box-shadow 0.3s !important;
}
[data-testid="stMetric"]:hover { transform:translateY(-2px) !important; }
[data-testid="stMetricValue"] { font-family:'Orbitron',sans-serif !important; color:#0057FF !important; }
[data-testid="stMetricLabel"] { color:#6B8EC2 !important; }

.stSuccess { background:rgba(0,200,150,0.08)  !important; border:1px solid rgba(0,200,150,0.35) !important; border-radius:12px !important; }
.stError   { background:rgba(255,71,87,0.07)   !important; border:1px solid rgba(255,71,87,0.3)  !important; border-radius:12px !important; }
.stWarning { background:rgba(255,184,0,0.08)   !important; border:1px solid rgba(255,184,0,0.35) !important; border-radius:12px !important; }
.stInfo    { background:rgba(0,87,255,0.05)    !important; border:1px solid rgba(0,87,255,0.22)  !important; border-radius:12px !important; }

.stProgress > div > div > div { background:linear-gradient(90deg,#0057FF,#00D4FF) !important; border-radius:10px !important; }

hr { border:none !important; border-top:1px solid rgba(0,87,255,0.12) !important; margin:10px 0 !important; }

::-webkit-scrollbar { width:5px; }
::-webkit-scrollbar-track { background:#EBF4FF; }
::-webkit-scrollbar-thumb { background:linear-gradient(#0057FF,#00D4FF); border-radius:10px; }

[data-testid="stFileUploader"] {
    background:#FFFFFF !important; border:2px dashed rgba(0,87,255,0.3) !important;
    border-radius:16px !important;
}

.streamlit-expanderHeader {
    background:rgba(0,87,255,0.05) !important; border:1px solid rgba(0,87,255,0.15) !important;
    border-radius:12px !important; color:#0057FF !important; font-weight:600 !important;
}

.caps-label {
    text-align:center; font-family:'Exo 2',sans-serif;
    font-size:10px; color:#A0B8D8; letter-spacing:4px; margin:6px 0 12px 0;
}

.glow-card {
    background: #FFFFFF; border: 2px solid rgba(0,87,255,0.3);
    border-radius: 20px; padding: 28px 16px 24px 16px;
    text-align: center; position: relative; overflow: hidden;
    cursor: pointer; transition: all 0.3s ease;
    animation: border-pulse 2.4s ease-in-out infinite;
}

.glow-card-1 { animation-delay: 0.0s; }
.glow-card-2 { animation-delay: 0.6s; }
.glow-card-3 { animation-delay: 1.2s; }
.glow-card-4 { animation-delay: 1.8s; }

@keyframes border-pulse {
    0%   { border-color: rgba(0,87,255,0.25); box-shadow: 0 0 8px rgba(0,87,255,0.15); }
    50%  { border-color: rgba(0,87,255,0.7);  box-shadow: 0 0 15px rgba(0,87,255,0.4), 0 0 25px rgba(0,212,255,0.3), inset 0 0 20px rgba(0,87,255,0.08); }
    100% { border-color: rgba(0,87,255,0.25); box-shadow: 0 0 8px rgba(0,87,255,0.15); }
}

.glow-card-inner { position: relative; z-index: 2; }

.glow-icon {
    font-size: 32px; line-height: 1; display: block; margin-bottom: 12px;
    animation: icon-subtle-breathe 2.8s ease-in-out infinite alternate;
}

.glow-card-1 .glow-icon { animation-delay: 0.0s; }
.glow-card-2 .glow-icon { animation-delay: 0.4s; }
.glow-card-3 .glow-icon { animation-delay: 0.8s; }
.glow-card-4 .glow-icon { animation-delay: 1.2s; }

@keyframes icon-subtle-breathe {
    from { filter: drop-shadow(0 0 2px rgba(0,87,255,0.1));  transform: translateY(0px)  scale(1);    }
    to   { filter: drop-shadow(0 0 12px rgba(0,212,255,0.5)); transform: translateY(-3px) scale(1.08); }
}

.glow-card:hover {
    transform: translateY(-6px); border-color: rgba(0,87,255,0.8);
    box-shadow: 0 0 20px rgba(0,87,255,0.5), 0 0 35px rgba(0,212,255,0.3), inset 0 0 20px rgba(0,87,255,0.1), 0 12px 35px rgba(0,87,255,0.15);
}

.glow-card:active {
    transform: translateY(-2px) scale(0.98); border-color: #00D4FF;
    box-shadow: 0 0 0 3px rgba(0,212,255,0.4), 0 0 25px rgba(0,212,255,0.6), 0 0 45px rgba(0,87,255,0.25);
}

.glow-title {
    font-family: 'Orbitron', sans-serif; font-size: 11px; font-weight: 700;
    color: #0057FF; letter-spacing: 1.5px; margin-bottom: 6px;
}

.glow-subtitle { font-family: 'Exo 2', sans-serif; font-size: 12px; color: #7A8EC2; line-height: 1.4; }

</style>
""", unsafe_allow_html=True)

# ════════════════════════════════════════════════════════════════
# 🔐 SESSION MANAGEMENT HELPER FUNCTIONS
# ════════════════════════════════════════════════════════════════

def is_user_logged_in():
    return st.session_state.get('user_logged_in', False)

def set_user_login(user_dict, role):
    from datetime import datetime
    st.session_state.user_logged_in  = True
    st.session_state.user_id         = user_dict.get("user_id")
    st.session_state.user_name       = user_dict.get("name")
    st.session_state.user_email      = user_dict.get("email")
    st.session_state.user_phone      = user_dict.get("phone")
    st.session_state.user_role       = role
    st.session_state.login_timestamp = datetime.now().isoformat()

def logout_user():
    st.session_state.user_logged_in  = False
    st.session_state.user_id         = None
    st.session_state.user_name       = None
    st.session_state.user_email      = None
    st.session_state.user_phone      = None
    st.session_state.user_role       = None
    st.session_state.selected_role   = "customer"
    st.session_state.login_timestamp = None
    st.rerun()

def get_logged_in_user():
    if not is_user_logged_in():
        return None
    return {
        "user_id": st.session_state.user_id,
        "name":    st.session_state.user_name,
        "email":   st.session_state.user_email,
        "phone":   st.session_state.user_phone,
        "role":    st.session_state.user_role,
    }

def role_card(icon, title, subtitle, role_key, is_selected):
    if is_selected:
        border = "3px solid #0057FF"
        shadow = "0 6px 24px rgba(0,87,255,0.22)"
        bg     = "linear-gradient(135deg,rgba(0,87,255,0.07),rgba(0,212,255,0.05))"
        badge  = ("<div style='position:absolute;top:8px;right:10px;"
                  "background:#0057FF;color:#fff;border-radius:20px;"
                  "font-family:Exo 2,sans-serif;font-size:9px;font-weight:700;"
                  "padding:2px 8px;letter-spacing:1px;'>SELECTED</div>")
    else:
        border = "2px solid rgba(0,87,255,0.18)"
        shadow = "0 2px 12px rgba(0,87,255,0.06)"
        bg     = "#FFFFFF"
        badge  = ""

    st.markdown(
        f"<div style='background:{bg};border:{border};"
        f"border-radius:16px;padding:20px 14px;text-align:center;"
        f"box-shadow:{shadow};position:relative;transition:all 0.2s;'>"
        f"{badge}"
        f"<div style='font-size:38px;line-height:1.1;margin-bottom:8px;'>{icon}</div>"
        f"<div style='font-family:Orbitron,sans-serif;font-size:13px;"
        f"font-weight:700;color:#0057FF;letter-spacing:1px;margin-bottom:4px;'>{title}</div>"
        f"<div style='font-family:Exo 2,sans-serif;font-size:11px;color:#6B8EC2;'>{subtitle}</div>"
        f"</div>",
        unsafe_allow_html=True
    )
    return st.button(f"Select {title}", key=f"role_btn_{role_key}", use_container_width=True)

# ════════════════════════════════════════════════════════════════
# LOGIN PAGE
# ════════════════════════════════════════════════════════════════

def show_login_page():

    # ── ✅ Hide sidebar completely on login / register screen ──
    st.markdown("""
    <style>
    [data-testid="stSidebar"]        { display: none !important; }
    [data-testid="collapsedControl"] { display: none !important; }
    section[data-testid="stSidebar"] { display: none !important; }
    </style>
    """, unsafe_allow_html=True)

    st.markdown(
        "<h1 style='text-align:center;font-family:Orbitron,sans-serif;"
        "font-size:40px;font-weight:800;"
        "background:linear-gradient(135deg,#0057FF,#00D4FF);"
        "-webkit-background-clip:text;-webkit-text-fill-color:transparent;"
        "letter-spacing:3px;margin-bottom:4px;'>🛡️ INSUREAI</h1>",
        unsafe_allow_html=True
    )
    st.markdown(
        "<p style='text-align:center;font-family:Exo 2,sans-serif;"
        "font-size:11px;color:#6B8EC2;letter-spacing:5px;margin:0;'>"
        "INTELLIGENT CLAIMS MANAGEMENT SYSTEM</p>",
        unsafe_allow_html=True
    )
    st.markdown(
        "<div style='width:60px;height:3px;"
        "background:linear-gradient(90deg,#0057FF,#00D4FF);"
        "border-radius:10px;margin:8px auto 16px auto;'></div>",
        unsafe_allow_html=True
    )

    _, col, _ = st.columns([1, 2, 1])

    with col:
        tab1, tab2 = st.tabs(["🔐  Login", "📝  Register"])

        with tab1:
            st.markdown(
                "<p style='font-family:Orbitron,sans-serif;font-size:14px;"
                "font-weight:700;color:#0057FF;letter-spacing:1px;"
                "margin:10px 0 6px 0;'>WELCOME BACK</p>",
                unsafe_allow_html=True
            )
            login_email    = st.text_input("Email Address", placeholder="your.email@example.com", key="login_email")
            login_password = st.text_input("Password", placeholder="Enter your password", type="password", key="login_password")

            st.markdown(
                "<p style='font-family:Exo 2,sans-serif;font-size:12px;"
                "font-weight:600;color:#2D4A7A;margin:10px 0 6px 0;'>"
                "Select your role:</p>",
                unsafe_allow_html=True
            )

            rc1, rc2 = st.columns(2)
            with rc1:
                if role_card("👤", "CUSTOMER", "Buy & file claims", "customer",
                             st.session_state.selected_role == "customer"):
                    st.session_state.selected_role = "customer"
                    st.rerun()
            with rc2:
                if role_card("🏢", "OFFICER", "Review & approve", "officer",
                             st.session_state.selected_role == "officer"):
                    st.session_state.selected_role = "officer"
                    st.rerun()

            role_display = "👤 Customer" if st.session_state.selected_role == "customer" else "🏢 Insurance Officer"
            st.markdown(
                f"<div style='background:rgba(0,87,255,0.06);border:1px solid rgba(0,87,255,0.2);"
                f"border-radius:8px;padding:6px 12px;margin:6px 0;"
                f"font-family:Exo 2,sans-serif;font-size:12px;"
                f"color:#0057FF;font-weight:600;text-align:center;'>"
                f"✅ &nbsp;Logging in as: <strong>{role_display}</strong></div>",
                unsafe_allow_html=True
            )

            if st.button("🔐  Login", type="primary", use_container_width=True):
                if not login_email or not login_password:
                    st.error("❌ Please enter email and password")
                else:
                    user = authenticate_user(login_email, login_password)
                    if user:
                        actual_role   = user.get("role", "customer")
                        selected_role = st.session_state.selected_role

                        if actual_role != selected_role:
                            role_label = "Customer" if actual_role == "customer" else "Insurance Officer"
                            st.error(
                                f"❌ This account is registered as a **{role_label}**. "
                                f"Please select the correct role and try again."
                            )
                        else:
                            set_user_login(user, actual_role)
                            st.success(f"✅ Welcome back, {user['name']}!")
                            st.balloons()
                            st.rerun()
                    else:
                        st.error("❌ Invalid email or password")

            st.info("💡 Demo: raj.kumar@email.com / password123")

        with tab2:
            st.markdown(
                "<p style='font-family:Orbitron,sans-serif;font-size:14px;"
                "font-weight:700;color:#0057FF;letter-spacing:1px;"
                "margin:10px 0 6px 0;'>CREATE ACCOUNT</p>",
                unsafe_allow_html=True
            )

            st.markdown(
                "<p style='font-family:Exo 2,sans-serif;font-size:12px;"
                "font-weight:600;color:#2D4A7A;margin:10px 0 6px 0;'>"
                "Select Role:</p>",
                unsafe_allow_html=True
            )

            r1, r2 = st.columns(2)
            with r1:
                if role_card("👤", "CUSTOMER", "Buy & file claims", "reg_customer",
                             st.session_state.selected_role == "customer"):
                    st.session_state.selected_role = "customer"
                    st.rerun()
            with r2:
                if role_card("🏢", "OFFICER", "Review & approve", "reg_officer",
                             st.session_state.selected_role == "officer"):
                    st.session_state.selected_role = "officer"
                    st.rerun()

            c1, c2 = st.columns(2)
            with c1:
                signup_name  = st.text_input("Full Name",    placeholder="John Doe",               key="signup_name")
                signup_email = st.text_input("Email",        placeholder="your.email@example.com", key="signup_email")
                signup_phone = st.text_input("Phone Number", placeholder="9876543210",             key="signup_phone")
            with c2:
                signup_password = st.text_input("Password",         placeholder="Min 4 characters", type="password", key="signup_password")
                signup_confirm  = st.text_input("Confirm Password", placeholder="Repeat password",  type="password", key="signup_confirm")

            secret_key = None
            if st.session_state.selected_role == "officer":
                secret_key = st.text_input(
                    "Officer Secret Key",
                    type="password",
                    placeholder="Enter officer authorization key"
                )

            if st.button("✨  Create Account", use_container_width=True):
                if not signup_name:
                    st.error("❌ Name required")
                elif not signup_email:
                    st.error("❌ Email required")
                elif not signup_password:
                    st.error("❌ Password required")
                elif len(signup_password) < 4:
                    st.error("❌ Password min 4 characters")
                elif signup_password != signup_confirm:
                    st.error("❌ Passwords do not match")
                elif not signup_phone:
                    st.error("❌ Phone required")
                else:
                    new_user = register_user(
                        name=signup_name,
                        email=signup_email,
                        password=signup_password,
                        phone=signup_phone,
                        role=st.session_state.selected_role,
                    )
                    if new_user:
                        set_user_login(new_user, new_user.get("role", "customer"))
                        st.success(f"✅ Welcome, {new_user['name']}!")
                        st.balloons()
                        st.rerun()
                    else:
                        st.error("❌ Registration failed — email exists or invalid officer key")

    st.divider()
    st.markdown("<p class='caps-label'>✦ &nbsp; PLATFORM CAPABILITIES &nbsp; ✦</p>", unsafe_allow_html=True)

    c1, c2, c3, c4 = st.columns(4)
    features = [
        ("🛡️", "BUY INSURANCE",  "Car · Health · Travel",  "glow-card-1"),
        ("📋", "FILE CLAIMS",    "AI-powered processing",   "glow-card-2"),
        ("🤖", "AI ANALYSIS",    "Fraud detection & RAG",   "glow-card-3"),
        ("⚡", "FAST DECISIONS", "24hr officer review",     "glow-card-4"),
    ]
    for col, (icon, title, sub, cls) in zip([c1, c2, c3, c4], features):
        with col:
            st.markdown(
                f"<div class='glow-card {cls}'>"
                f"<div class='glow-card-inner'>"
                f"<span class='glow-icon'>{icon}</span>"
                f"<div class='glow-title'>{title}</div>"
                f"<div class='glow-subtitle'>{sub}</div>"
                f"</div></div>",
                unsafe_allow_html=True
            )

# ════════════════════════════════════════════════════════════════
# DASHBOARD — Role-strict sidebar
# ════════════════════════════════════════════════════════════════

def show_dashboard():

    if not st.session_state.user_role:
        logout_user()
        return

    with st.sidebar:
        st.markdown(
            "<div style='text-align:center;padding:14px 0 6px 0;'>"
            "<div style='font-family:Orbitron,sans-serif;font-size:17px;font-weight:800;"
            "background:linear-gradient(135deg,#00D4FF,#FFFFFF);"
            "-webkit-background-clip:text;-webkit-text-fill-color:transparent;"
            "letter-spacing:2px;'>🛡️ INSUREAI</div>"
            "<div style='font-family:Exo 2,sans-serif;font-size:8px;"
            "color:rgba(0,212,255,0.6);letter-spacing:4px;margin-top:3px;'>"
            "CLAIMS SYSTEM</div></div>",
            unsafe_allow_html=True
        )
        st.divider()

        role_icon  = "👤" if st.session_state.user_role == "customer" else "🏢"
        role_label = "Customer" if st.session_state.user_role == "customer" else "Officer"
        st.markdown(
            f"<div style='background:rgba(0,87,255,0.12);"
            f"border:1px solid rgba(0,212,255,0.2);"
            f"border-radius:12px;padding:12px 14px;margin-bottom:12px;'>"
            f"<div style='font-family:Orbitron,sans-serif;font-size:9px;"
            f"color:#00D4FF;letter-spacing:1px;margin-bottom:4px;'>LOGGED IN AS</div>"
            f"<div style='font-size:22px;margin-bottom:4px;'>{role_icon}</div>"
            f"<div style='font-family:Exo 2,sans-serif;font-size:14px;"
            f"font-weight:700;color:#FFFFFF;'>{st.session_state.user_name}</div>"
            f"<div style='font-family:Exo 2,sans-serif;font-size:11px;"
            f"color:rgba(200,220,255,0.7);margin-top:1px;'>{st.session_state.user_email}</div>"
            f"<div style='font-family:Orbitron,sans-serif;font-size:9px;"
            f"color:rgba(0,212,255,0.9);margin-top:4px;letter-spacing:1px;'>"
            f"{role_label.upper()}</div></div>",
            unsafe_allow_html=True
        )

        if st.session_state.user_role == "customer":
            st.caption("CUSTOMER MENU")
            page = st.radio("nav", [
                "🛡️ Buy Insurance",
                "📋 File Claim",
                "📊 My Claims",
                "🤖 Chat Support"
            ], label_visibility="collapsed")
        else:
            st.caption("OFFICER MENU")
            page = st.radio("nav", [
                "👔 Dashboard",
                "📊 Pending Claims",
                "📈 Reports"
            ], label_visibility="collapsed")

        st.divider()
        if st.button("🚪  Logout", use_container_width=True):
            logout_user()
        st.markdown(
            "<div style='text-align:center;margin-top:12px;'>"
            "<span style='font-family:Exo 2,sans-serif;font-size:8px;"
            "color:rgba(0,212,255,0.35);letter-spacing:2px;'>"
            "POWERED BY AI · v1.0</span></div>",
            unsafe_allow_html=True
        )

    if st.session_state.user_role == "customer":
        if   page == "🛡️ Buy Insurance": st.switch_page("pages/02_buy_insurance.py")
        elif page == "📋 File Claim":     st.switch_page("pages/03_file_claim_WITH_PDF.py")
        elif page == "📊 My Claims":      st.switch_page("pages/04_my_claims.py")
        elif page == "🤖 Chat Support":   st.switch_page("pages/05_chatbot.py")

    elif st.session_state.user_role == "officer":
        if   page == "👔 Dashboard":      st.switch_page("pages/06_officer_dashboard.py")
        elif page == "📊 Pending Claims": st.switch_page("pages/06_officer_dashboard.py")
        elif page == "📈 Reports":
            st.markdown(
                "<h2 style='font-family:Orbitron,sans-serif;color:#0057FF;'>"
                "📈 REPORTS & ANALYTICS</h2>"
                "<p style='color:#6B8EC2;'>Coming soon</p>",
                unsafe_allow_html=True
            )
            st.info("📌 Claim trends, approval rates and fraud analytics will appear here.")
    else:
        st.error("⚠️ Unknown role detected. Please log in again.")
        logout_user()

# ════════════════════════════════════════════════════════════════
# MAIN
# ════════════════════════════════════════════════════════════════

def main():
    if is_user_logged_in():
        show_dashboard()
    else:
        show_login_page()

if __name__ == "__main__":
    main()
