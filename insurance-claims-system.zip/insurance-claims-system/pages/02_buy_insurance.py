"""

02_buy_insurance.py

BUY INSURANCE PAGE — Dynamic version (Redesigned)

Policies are pulled from data_handler.AVAILABLE_POLICIES
Add/remove/edit policies in data_handler.py — this page updates automatically

UI: Same theme — Futuristic Blue & White
Layout: Tabbed (Browse Plans | My Policies) with horizontal row-style cards
New: "📊 View Status" button on every owned policy → redirects to customer_home

"""

import streamlit as st
import sys
sys.path.append(".")
from modules.data_handler import (
    buy_policy,
    get_user_policies,
    get_available_policies
)

# ════════════════════════════════════════════════════════════════
# SESSION GUARD
# ════════════════════════════════════════════════════════════════

if not st.session_state.get("user_logged_in"):
    st.error("❌ Please login first")
    st.stop()

user_id = st.session_state["user_id"]

# ════════════════════════════════════════════════════════════════
# PAGE CONFIG
# ════════════════════════════════════════════════════════════════

st.set_page_config(
    page_title="Buy Insurance — InsureAI",
    page_icon="🛡️",
    layout="wide"
)

# ════════════════════════════════════════════════════════════════
# HIDE CUSTOMER HOME FROM SIDEBAR NAV
# ════════════════════════════════════════════════════════════════

st.markdown("""
<style>
[data-testid="stSidebarNav"] a[href*="customer_home"],
[data-testid="stSidebarNav"] li:has(a[href*="customer_home"]) {
    display: none !important;
}
</style>
""", unsafe_allow_html=True)

# ════════════════════════════════════════════════════════════════
# CSS — SAME THEME, DIFFERENT LAYOUT COMPONENTS
# ════════════════════════════════════════════════════════════════

st.markdown("""
<style>

@import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;600;800&family=Exo+2:wght@300;400;500;600;700&display=swap');

/* ═══════════════════════════════════════
   BACKGROUND & LAYOUT
   ═══════════════════════════════════════ */

html, body { background: #F0F6FF !important; }
[data-testid="stAppViewContainer"],
[data-testid="stMain"], .main, .block-container,
section.main > div { background: #F0F6FF !important; }

[data-testid="stAppViewContainer"]::before {
    content:''; position:fixed; top:0; left:0; right:0; bottom:0;
    background-image:
        linear-gradient(rgba(0,87,255,0.035) 1px, transparent 1px),
        linear-gradient(90deg, rgba(0,87,255,0.035) 1px, transparent 1px);
    background-size:44px 44px; pointer-events:none; z-index:0;
}

html, body, * { font-family:'Exo 2',sans-serif; color:#0A1628; }
.block-container { padding-top:1rem !important; padding-bottom:1rem !important; }
div[data-testid="stVerticalBlock"] > div { margin-bottom:0 !important; }
.element-container { margin-bottom:0.25rem !important; }
[data-testid="column"] { padding:0 6px !important; }
#MainMenu, footer, header, [data-testid="stDecoration"] { visibility:hidden !important; display:none !important; }

/* ═══════════════════════════════════════
   SIDEBAR STYLING
   ═══════════════════════════════════════ */

[data-testid="stSidebar"],
[data-testid="stSidebar"] > div,
[data-testid="stSidebar"] section {
    background:linear-gradient(180deg,#060F24 0%,#0B1E4A 55%,#060F24 100%) !important;
    border-right:1px solid rgba(0,212,255,0.25) !important;
    box-shadow:4px 0 30px rgba(0,87,255,0.2) !important;
}

[data-testid="stSidebar"] p,
[data-testid="stSidebar"] span,
[data-testid="stSidebar"] label,
[data-testid="stSidebar"] div { color:#D6EAFF !important; }

[data-testid="stSidebar"] hr { border-color:rgba(0,212,255,0.15) !important; margin:8px 0 !important; }

/* ═══════════════════════════════════════
   BUTTON STYLING
   ═══════════════════════════════════════ */

.stButton > button {
    background:linear-gradient(135deg,#0057FF,#0099FF) !important;
    color:#FFFFFF !important; border:none !important;
    border-radius:12px !important; padding:10px 28px !important;
    font-family:'Exo 2',sans-serif !important; font-weight:600 !important;
    font-size:14px !important; transition:all 0.3s ease !important;
    box-shadow:0 4px 18px rgba(0,87,255,0.28) !important;
    margin-top:4px !important;
}

.stButton > button:hover {
    transform:translateY(-2px) !important;
    box-shadow:0 8px 28px rgba(0,87,255,0.5) !important;
}

/* ═══════════════════════════════════════
   ALERT STYLING
   ═══════════════════════════════════════ */

.stSuccess { background:rgba(0,200,150,0.08) !important; border:1px solid rgba(0,200,150,0.35) !important; border-radius:12px !important; }
.stError   { background:rgba(255,71,87,0.07)  !important; border:1px solid rgba(255,71,87,0.3)  !important; border-radius:12px !important; }
.stWarning { background:rgba(255,184,0,0.08)  !important; border:1px solid rgba(255,184,0,0.35) !important; border-radius:12px !important; }
.stInfo    { background:rgba(0,87,255,0.05)   !important; border:1px solid rgba(0,87,255,0.22)  !important; border-radius:12px !important; }

/* ═══════════════════════════════════════
   DIVIDER & SCROLLBAR
   ═══════════════════════════════════════ */

hr { border:none !important; border-top:1px solid rgba(0,87,255,0.12) !important; margin:10px 0 !important; }

::-webkit-scrollbar { width:5px; }
::-webkit-scrollbar-track { background:#EBF4FF; }
::-webkit-scrollbar-thumb { background:linear-gradient(#0057FF,#00D4FF); border-radius:10px; }

/* ═══════════════════════════════════════
   EXPANDER
   ═══════════════════════════════════════ */

.streamlit-expanderHeader {
    background:rgba(0,87,255,0.05) !important;
    border:1px solid rgba(0,87,255,0.15) !important;
    border-radius:12px !important;
    color:#0057FF !important;
    font-weight:600 !important;
}

/* ═══════════════════════════════════════
   TABS STYLING
   ═══════════════════════════════════════ */

[data-testid="stTabs"] [data-baseweb="tab-list"] {
    background: rgba(0,87,255,0.05) !important;
    border-radius: 14px !important;
    padding: 4px !important;
    border: 1px solid rgba(0,87,255,0.12) !important;
    gap: 4px !important;
}

[data-testid="stTabs"] [data-baseweb="tab"] {
    background: transparent !important;
    border-radius: 10px !important;
    color: #6B8EC2 !important;
    font-family: 'Exo 2', sans-serif !important;
    font-weight: 600 !important;
    font-size: 13px !important;
    padding: 8px 20px !important;
    border: none !important;
}

[data-testid="stTabs"] [aria-selected="true"] {
    background: linear-gradient(135deg,#0057FF,#0099FF) !important;
    color: #FFFFFF !important;
    box-shadow: 0 4px 14px rgba(0,87,255,0.3) !important;
}

[data-testid="stTabs"] [data-baseweb="tab-highlight"] {
    display: none !important;
}

</style>
""", unsafe_allow_html=True)

# ════════════════════════════════════════════════════════════════
# PAGE HEADER
# ════════════════════════════════════════════════════════════════

st.markdown(
    "<h2 style='font-family:Orbitron,sans-serif;font-size:30px;font-weight:800;"
    "background:linear-gradient(135deg,#0057FF,#00D4FF);"
    "-webkit-background-clip:text;-webkit-text-fill-color:transparent;"
    "letter-spacing:2px;margin-bottom:2px;line-height:1.1;'>🛡️ BUY INSURANCE</h2>",
    unsafe_allow_html=True
)
st.markdown(
    "<p style='font-family:Exo 2,sans-serif;font-size:11px;"
    "color:#6B8EC2;letter-spacing:3px;margin:0;'>"
    "CHOOSE YOUR PLAN · INSTANT ACTIVATION</p>",
    unsafe_allow_html=True
)
st.markdown(
    "<div style='width:50px;height:3px;"
    "background:linear-gradient(90deg,#0057FF,#00D4FF);"
    "border-radius:10px;margin:8px 0 16px 0;'></div>",
    unsafe_allow_html=True
)

# ════════════════════════════════════════════════════════════════
# DYNAMIC DATA
# ════════════════════════════════════════════════════════════════

available_policies = get_available_policies()
user_policies      = get_user_policies(user_id)
owned_types        = {p['policy_type'] for p in user_policies}
owned_policy_map   = {p['policy_type']: p for p in user_policies}

def to_doc_key(policy_type):
    return policy_type.lower().replace(" ", "_")

POLICY_ICONS = {
    "car insurance":    "🚗",
    "health insurance": "🏥",
    "travel insurance": "✈️",
    "home insurance":   "🏠",
    "life insurance":   "💙",
    "bike insurance":   "🏍️",
}

def get_icon(policy_type):
    return POLICY_ICONS.get(policy_type.lower(), "🛡️")

# ════════════════════════════════════════════════════════════════
# STATS BANNER STRIP
# ════════════════════════════════════════════════════════════════

max_cov = f"₹{max(p['coverage_amount'] for p in available_policies):,}" if available_policies else "—"
banner_items = [
    ("📋", str(len(available_policies)), "Available Plans"),
    ("✅", str(len(user_policies)),      "Your Active Plans"),
    ("💰", max_cov,                      "Max Coverage"),
]

cols = st.columns(3)
for col, (icon, val, label) in zip(cols, banner_items):
    with col:
        st.markdown(
            f"<div style='background:#FFFFFF;border:1.5px solid rgba(0,87,255,0.14);"
            f"border-top:3px solid #0057FF;border-radius:14px;padding:16px 18px;"
            f"box-shadow:0 4px 18px rgba(0,87,255,0.07);'>"
            f"<div style='font-size:22px;margin-bottom:6px;'>{icon}</div>"
            f"<div style='font-family:Orbitron,sans-serif;font-size:22px;font-weight:800;color:#0057FF;'>{val}</div>"
            f"<div style='font-family:Exo 2,sans-serif;font-size:11px;color:#6B8EC2;margin-top:2px;'>{label}</div>"
            f"</div>",
            unsafe_allow_html=True
        )

st.markdown("<div style='height:20px;'></div>", unsafe_allow_html=True)

# ════════════════════════════════════════════════════════════════
# TABBED LAYOUT
# ════════════════════════════════════════════════════════════════

tab1, tab2 = st.tabs(["📋  Browse Plans", "✅  My Policies"])

# ─────────────────────────────────────────
# TAB 1 — BROWSE & BUY
# ─────────────────────────────────────────
with tab1:
    st.markdown("<div style='height:12px;'></div>", unsafe_allow_html=True)

    if not available_policies:
        st.info("No policies available at the moment.")
    else:
        for policy in available_policies:
            ptype    = policy['policy_type']
            coverage = policy['coverage_amount']
            premium  = policy['premium_amount']
            desc     = policy.get('description', 'Comprehensive insurance coverage.')
            icon     = get_icon(ptype)
            owned    = ptype in owned_types
            doc_key  = to_doc_key(ptype)

            owned_badge = (
                "<span style='background:#00C896;color:#fff;border-radius:20px;"
                "font-size:9px;font-weight:700;padding:2px 10px;margin-left:8px;'>✅ OWNED</span>"
                if owned else ""
            )
            border = "2px solid #00C896" if owned else "1.5px solid rgba(0,87,255,0.14)"
            bg     = "rgba(0,200,150,0.03)" if owned else "#FFFFFF"

            left, mid, right = st.columns([4, 3, 2])

            with left:
                st.markdown(
                    f"<div style='background:{bg};border:{border};border-radius:16px;"
                    f"padding:18px 20px;box-shadow:0 3px 16px rgba(0,87,255,0.07);"
                    f"display:flex;align-items:flex-start;gap:14px;'>"
                    f"<span style='font-size:32px;flex-shrink:0;'>{icon}</span>"
                    f"<div><div style='font-family:Orbitron,sans-serif;font-size:13px;"
                    f"font-weight:700;color:#0057FF;letter-spacing:1px;'>"
                    f"{ptype.upper()}{owned_badge}</div>"
                    f"<div style='font-family:Exo 2,sans-serif;font-size:12px;"
                    f"color:#6B8EC2;margin-top:5px;line-height:1.5;'>{desc}</div>"
                    f"</div></div>",
                    unsafe_allow_html=True
                )

            with mid:
                st.markdown(
                    f"<div style='background:#FFFFFF;border:1.5px solid rgba(0,87,255,0.10);"
                    f"border-radius:16px;padding:18px 20px;box-shadow:0 3px 16px rgba(0,87,255,0.05);'>"
                    f"<div style='margin-bottom:12px;'>"
                    f"<div style='font-family:Exo 2,sans-serif;font-size:10px;color:#6B8EC2;letter-spacing:1px;'>COVERAGE AMOUNT</div>"
                    f"<div style='font-family:Orbitron,sans-serif;font-size:18px;font-weight:800;color:#0057FF;'>₹{coverage:,}</div>"
                    f"</div>"
                    f"<div style='border-top:1px solid rgba(0,87,255,0.08);padding-top:10px;'>"
                    f"<div style='font-family:Exo 2,sans-serif;font-size:10px;color:#6B8EC2;letter-spacing:1px;'>PREMIUM / YEAR</div>"
                    f"<div style='font-family:Orbitron,sans-serif;font-size:18px;font-weight:800;color:#00A87A;'>₹{premium:,}</div>"
                    f"</div></div>",
                    unsafe_allow_html=True
                )

            with right:
                st.markdown("<div style='height:4px;'></div>", unsafe_allow_html=True)
                if owned:
                    if st.button("📊 View Status", key=f"vstatus_browse_{ptype}", use_container_width=True):
                        st.session_state["view_status_policy"] = ptype
                        st.switch_page("pages/01_customer_home.py")

                if st.button("📋 File Claim", key=f"claim_{ptype}", use_container_width=True):
                    st.session_state["selected_policy_for_claim"] = doc_key
                    st.switch_page("pages/03_file_claim_WITH_PDF.py")

            st.markdown("<div style='height:10px;'></div>", unsafe_allow_html=True)

# ─────────────────────────────────────────
# TAB 2 — MY POLICIES
# ─────────────────────────────────────────
with tab2:
    st.markdown("<div style='height:12px;'></div>", unsafe_allow_html=True)

    if not user_policies:
        st.info("You haven't purchased any policies yet. Head to Browse Plans to get started!")
    else:
        st.markdown(
            "<p style='font-family:Orbitron,sans-serif;font-size:11px;"
            "font-weight:700;color:#0057FF;letter-spacing:1px;margin-bottom:14px;'>"
            f"✅ {len(user_policies)} ACTIVE POLICY(IES)</p>",
            unsafe_allow_html=True
        )

        for p in user_policies:
            icon    = get_icon(p['policy_type'])
            doc_key = to_doc_key(p['policy_type'])
            ptype   = p['policy_type']

            status       = p.get("status", "Active")
            status_lower = status.lower()

            if status_lower == "active":
                bg, border, color, emoji = "rgba(0,200,150,0.1)", "rgba(0,200,150,0.3)", "#00A87A", "✅"
            elif status_lower == "pending":
                bg, border, color, emoji = "rgba(255,184,0,0.1)", "rgba(255,184,0,0.4)", "#CC8800", "🟡"
            elif status_lower in ("rejected", "cancelled"):
                bg, border, color, emoji = "rgba(255,71,87,0.1)", "rgba(255,71,87,0.3)", "#CC2233", "❌"
            elif status_lower == "approved":
                bg, border, color, emoji = "rgba(0,87,255,0.1)", "rgba(0,87,255,0.3)", "#0057FF", "✔️"
            else:
                bg, border, color, emoji = "rgba(100,100,100,0.1)", "rgba(100,100,100,0.3)", "#666666", "⚪"

            info_col, status_col, action_col = st.columns([4, 2, 3])

            with info_col:
                st.markdown(
                    f"<div style='background:#FFFFFF;border:1px solid rgba(0,200,150,0.25);"
                    f"border-left:4px solid #00C896;border-radius:12px;padding:14px 18px;"
                    f"box-shadow:0 2px 12px rgba(0,200,150,0.07);'>"
                    f"<div style='display:flex;align-items:center;gap:12px;'>"
                    f"<span style='font-size:26px;'>{icon}</span>"
                    f"<div><div style='font-family:Orbitron,sans-serif;font-size:13px;"
                    f"font-weight:700;color:#0057FF;'>{ptype.upper()}</div>"
                    f"<div style='font-family:Exo 2,sans-serif;font-size:11px;color:#6B8EC2;margin-top:3px;'>"
                    f"ID: {p['policy_id']} &nbsp;·&nbsp; "
                    f"Coverage: ₹{p['coverage_amount']:,} &nbsp;·&nbsp; "
                    f"Purchased: {p['purchase_date'][:10]}"
                    f"</div></div></div></div>",
                    unsafe_allow_html=True
                )

            with status_col:
                st.markdown("<div style='height:6px;'></div>", unsafe_allow_html=True)
                st.markdown(
                    f"<div style='background:{bg};border:1px solid {border};"
                    f"border-radius:10px;padding:10px 12px;text-align:center;"
                    f"font-family:Exo 2,sans-serif;font-size:12px;font-weight:700;color:{color};'>"
                    f"{emoji} {status.upper()}</div>",
                    unsafe_allow_html=True
                )

            with action_col:
                st.markdown("<div style='height:6px;'></div>", unsafe_allow_html=True)

                if st.button("📊 View Status", key=f"vstatus_mine_{p['policy_id']}", use_container_width=True):
                    st.session_state["view_status_policy"] = ptype
                    st.switch_page("pages/01_customer_home.py")

                if st.button("📋 File Claim", key=f"myclaim_{p['policy_id']}", use_container_width=True):
                    st.session_state["selected_policy_for_claim"] = doc_key
                    st.switch_page("pages/03_file_claim_WITH_PDF.py")

            st.markdown("<div style='height:8px;'></div>", unsafe_allow_html=True)

# ════════════════════════════════════════════════════════════════
# SIDEBAR
# ════════════════════════════════════════════════════════════════

with st.sidebar:
    st.markdown(
        "<div style='text-align:center;padding:14px 0 6px 0;'>"
        "<div style='font-family:Orbitron,sans-serif;font-size:17px;font-weight:800;"
        "background:linear-gradient(135deg,#00D4FF,#FFFFFF);"
        "-webkit-background-clip:text;-webkit-text-fill-color:transparent;"
        "letter-spacing:2px;'>🛡️ INSUREAI</div>"
        "<div style='font-family:Exo 2,sans-serif;font-size:8px;"
        "color:rgba(0,212,255,0.6);letter-spacing:4px;margin-top:3px;'>CLAIMS SYSTEM</div>"
        "<div style='width:40px;height:2px;"
        "background:linear-gradient(90deg,transparent,#00D4FF,transparent);"
        "margin:8px auto 0;'></div></div>",
        unsafe_allow_html=True
    )
    st.divider()

    st.markdown(
        "<p style='font-family:Orbitron,sans-serif;font-size:9px;"
        "color:#00D4FF;letter-spacing:2px;margin-bottom:10px;'>◈ HOW IT WORKS</p>",
        unsafe_allow_html=True
    )
    for step, txt in [
        ("1", "Browse the plans tab"),
        ("2", "Click Buy Now on any plan"),
        ("3", "Policy activates instantly"),
        ("4", "Click View Status anytime"),
        ("5", "File a claim when needed"),
    ]:
        st.markdown(
            f"<div style='display:flex;align-items:center;gap:8px;"
            f"font-family:Exo 2,sans-serif;font-size:12px;color:#D6EAFF;padding:4px 0;'>"
            f"<span style='background:rgba(0,87,255,0.4);color:#00D4FF;"
            f"border-radius:50%;width:18px;height:18px;display:inline-flex;"
            f"align-items:center;justify-content:center;"
            f"font-size:10px;font-weight:700;flex-shrink:0;'>{step}</span>{txt}</div>",
            unsafe_allow_html=True
        )

    st.divider()

    st.markdown(
        "<p style='font-family:Orbitron,sans-serif;font-size:9px;"
        "color:#00D4FF;letter-spacing:2px;margin-bottom:10px;'>◈ YOUR SUMMARY</p>",
        unsafe_allow_html=True
    )
    for label, val, color in [
        ("📋 Plans Available", len(available_policies), "#0099FF"),
        ("✅ Plans Owned",     len(user_policies),      "#00C896"),
    ]:
        st.markdown(
            f"<div style='display:flex;justify-content:space-between;"
            f"font-family:Exo 2,sans-serif;font-size:12px;color:#D6EAFF;padding:4px 0;'>"
            f"<span>{label}</span>"
            f"<span style='font-family:Orbitron,sans-serif;font-weight:700;color:{color};'>"
            f"{val}</span></div>",
            unsafe_allow_html=True
        )

    st.divider()

    st.markdown(
        "<div style='text-align:center;margin-top:12px;'>"
        "<span style='font-family:Exo 2,sans-serif;font-size:8px;"
        "color:rgba(0,212,255,0.35);letter-spacing:2px;'>"
        "POWERED BY AI · v1.0</span></div>",
        unsafe_allow_html=True
    )
