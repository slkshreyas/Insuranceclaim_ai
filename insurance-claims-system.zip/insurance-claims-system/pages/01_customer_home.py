import streamlit as st
import sys
from datetime import datetime

sys.path.append(".")
from modules.data_handler import get_user_policies, get_user_claims

# ════════════════════════════════════════════════════════════════
# HIDE THIS PAGE FROM SIDEBAR
# ════════════════════════════════════════════════════════════════

st.markdown("""
<style>
[data-testid="stSidebarNav"] ul li:nth-child(2) { display: none !important; }
</style>
""", unsafe_allow_html=True)

# ════════════════════════════════════════════════════════════════
# SESSION GUARD
# ════════════════════════════════════════════════════════════════

if not st.session_state.get('user_logged_in'):
    st.error("❌ Please login first")
    st.stop()

user_id   = st.session_state["user_id"]
user_name = st.session_state["user_name"]

# ════════════════════════════════════════════════════════════════
# PAGE CONFIG
# ════════════════════════════════════════════════════════════════

st.set_page_config(
    page_title="Home — InsureAI",
    page_icon="🏠",
    layout="wide"
)

# ════════════════════════════════════════════════════════════════
# CSS — SAME AS FILE_CLAIM (WHITE BG + BLACK TEXT)
# ════════════════════════════════════════════════════════════════

st.markdown("""
<style>

@import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;600;800&family=Exo+2:wght@300;400;500;600;700&display=swap');

/* ═══════════════════════════════════════
   BACKGROUND & LAYOUT
   ═══════════════════════════════════════ */

html, body { background: #F0F6FF !important; }
[data-testid="stAppViewContainer"],
[data-testid="stMain"], .main, .block-container,
section.main > div { background: #F0F6FF !important; }

[data-testid="stAppViewContainer"]::before {
    content:''; position:fixed; top:0; left:0; right:0; bottom:0;
    background-image:
        linear-gradient(rgba(0,87,255,0.035) 1px, transparent 1px),
        linear-gradient(90deg, rgba(0,87,255,0.035) 1px, transparent 1px);
    background-size:44px 44px; pointer-events:none; z-index:0;
}

html, body, * { font-family:'Exo 2',sans-serif; color:#0A1628; }
.block-container { padding-top:1rem !important; padding-bottom:1rem !important; }
div[data-testid="stVerticalBlock"] > div { margin-bottom:0 !important; }
.element-container { margin-bottom:0.25rem !important; }
[data-testid="column"] { padding:0 6px !important; }
#MainMenu, footer, header, [data-testid="stDecoration"] { visibility:hidden !important; display:none !important; }

/* ═══════════════════════════════════════
   SIDEBAR STYLING
   ═══════════════════════════════════════ */

[data-testid="stSidebar"],
[data-testid="stSidebar"] > div,
[data-testid="stSidebar"] section {
    background:linear-gradient(180deg,#060F24 0%,#0B1E4A 55%,#060F24 100%) !important;
    border-right:1px solid rgba(0,212,255,0.25) !important;
    box-shadow:4px 0 30px rgba(0,87,255,0.2) !important;
}

[data-testid="stSidebar"] p,
[data-testid="stSidebar"] span,
[data-testid="stSidebar"] label,
[data-testid="stSidebar"] div { color:#D6EAFF !important; }

[data-testid="stSidebar"] .stRadio > div > label {
    background:rgba(0,87,255,0.08) !important;
    border:1px solid rgba(0,212,255,0.15) !important;
    border-radius:10px !important;
    padding:8px 12px !important; margin:2px 0 !important;
    transition:all 0.2s !important; display:block !important;
    color:#D6EAFF !important;
}

[data-testid="stSidebar"] .stRadio > div > label:hover {
    background:rgba(0,87,255,0.25) !important;
    border-color:rgba(0,212,255,0.5) !important;
    transform:translateX(4px) !important;
}

[data-testid="stSidebar"] hr { border-color:rgba(0,212,255,0.15) !important; margin:8px 0 !important; }

/* ═══════════════════════════════════════
   HIDE CUSTOMER HOME FROM SIDEBAR NAV
   Targets the nav item by its position — adjust nth-child if order changes
   ═══════════════════════════════════════ */

[data-testid="stSidebarNav"] a[href*="customer_home"],
[data-testid="stSidebarNav"] li:has(a[href*="customer_home"]) {
    display: none !important;
}

/* ═══════════════════════════════════════
   TAB STYLING
   ═══════════════════════════════════════ */

.stTabs [data-baseweb="tab-list"] {
    background:rgba(0,87,255,0.06) !important;
    border-radius:14px !important; padding:4px !important;
    border:1px solid rgba(0,87,255,0.15) !important; gap:4px !important;
}

.stTabs [data-baseweb="tab"] {
    border-radius:10px !important; font-family:'Exo 2',sans-serif !important;
    font-weight:600 !important; font-size:13px !important;
    color:#2D4A7A !important; padding:8px 18px !important;
    background:transparent !important;
}

.stTabs [aria-selected="true"] {
    background:linear-gradient(135deg,#0057FF,#0099FF) !important;
    color:#FFFFFF !important;
    box-shadow:0 4px 15px rgba(0,87,255,0.35) !important;
}

/* ═══════════════════════════════════════
   BUTTON STYLING
   ═══════════════════════════════════════ */

.stButton > button {
    background:linear-gradient(135deg,#0057FF,#0099FF) !important;
    color:#FFFFFF !important; border:none !important;
    border-radius:12px !important; padding:10px 28px !important;
    font-family:'Exo 2',sans-serif !important; font-weight:600 !important;
    font-size:14px !important; transition:all 0.3s ease !important;
    box-shadow:0 4px 18px rgba(0,87,255,0.28) !important;
    margin-top:4px !important;
}

.stButton > button:hover {
    transform:translateY(-2px) !important;
    box-shadow:0 8px 28px rgba(0,87,255,0.5) !important;
}

.stDownloadButton > button {
    background:linear-gradient(135deg,#00C896,#00A87A) !important;
    color:#FFFFFF !important; border:none !important;
    border-radius:12px !important;
    font-family:'Exo 2',sans-serif !important; font-weight:600 !important;
    font-size:14px !important; transition:all 0.3s ease !important;
    box-shadow:0 4px 18px rgba(0,200,150,0.28) !important;
}

.stDownloadButton > button:hover {
    transform:translateY(-2px) !important;
    box-shadow:0 8px 28px rgba(0,200,150,0.45) !important;
}

/* ═══════════════════════════════════════
   INPUT STYLING - WHITE BG BLACK TEXT
   ═══════════════════════════════════════ */

.stTextInput > div > div {
    background:#FFFFFF !important;
    border:2px solid rgba(0,87,255,0.3) !important;
    border-radius:12px !important;
    transition:all 0.3s !important;
}

.stTextInput > div > div:focus-within {
    border-color:#0057FF !important;
    box-shadow:0 0 0 3px rgba(0,87,255,0.1),0 0 18px rgba(0,87,255,0.12) !important;
}

.stTextInput > div > div > input {
    background:#FFFFFF !important;
    color:#000000 !important;
    font-family:'Exo 2',sans-serif !important; font-size:14px !important;
    font-weight:500 !important; caret-color:#0057FF !important;
    border:none !important; box-shadow:none !important;
    padding:10px 14px !important;
}

.stTextInput > div > div > input::placeholder { color:#666666 !important; }
.stTextInput > div > div > input:focus { outline:none !important; box-shadow:none !important; }

/* ═══════════════════════════════════════
   TEXTAREA STYLING
   ═══════════════════════════════════════ */

.stTextArea > div > div > textarea {
    background:#FFFFFF !important;
    border:2px solid rgba(0,87,255,0.3) !important;
    border-radius:12px !important;
    color:#000000 !important;
    font-family:'Exo 2',sans-serif !important;
    caret-color:#0057FF !important;
    font-size:14px !important;
    font-weight:500 !important;
}

.stTextArea > div > div > textarea:focus {
    border-color:#0057FF !important;
    box-shadow:0 0 0 3px rgba(0,87,255,0.1),0 0 18px rgba(0,87,255,0.12) !important;
    outline:none !important;
}

.stTextArea > div > div > textarea::placeholder { color:#666666 !important; }

/* ═══════════════════════════════════════
   SELECTBOX STYLING
   ═══════════════════════════════════════ */

.stSelectbox > div > div {
    background:#FFFFFF !important;
    border:2px solid rgba(0,87,255,0.3) !important;
    border-radius:12px !important;
}

.stSelectbox > div > div > div {
    color:#0A1628 !important;
    font-family:'Exo 2',sans-serif !important;
    font-size:14px !important;
    font-weight:500 !important;
}

.stSelectbox svg { fill:#0057FF !important; }

[data-baseweb="menu"],
[data-baseweb="popover"],
[data-baseweb="popover"] div,
[data-baseweb="popover"] ul {
    background:#FFFFFF !important;
    color:#0A1628 !important;
    border:1.5px solid rgba(0,87,255,0.25) !important;
    border-radius:12px !important;
    box-shadow:0 8px 24px rgba(0,87,255,0.12) !important;
}

[data-baseweb="menu"] li,
[data-baseweb="option"],
[role="option"] {
    background:#FFFFFF !important;
    color:#0A1628 !important;
    font-family:'Exo 2',sans-serif !important;
    font-size:14px !important;
    font-weight:500 !important;
}

[data-baseweb="menu"] li:hover,
[data-baseweb="option"]:hover,
[role="option"]:hover {
    background:rgba(0,87,255,0.07) !important;
    color:#0057FF !important;
}

label, .stTextInput label, .stTextArea label, .stSelectbox label {
    font-family:'Exo 2',sans-serif !important; font-size:13px !important;
    font-weight:600 !important; color:#2D4A7A !important;
}

/* ═══════════════════════════════════════
   METRIC CARDS
   ═══════════════════════════════════════ */

[data-testid="stMetric"] {
    background:#FFFFFF !important;
    border:1px solid rgba(0,87,255,0.12) !important;
    border-radius:16px !important; padding:16px !important;
    box-shadow:0 4px 18px rgba(0,87,255,0.07) !important;
    transition:transform 0.3s, box-shadow 0.3s !important;
}

[data-testid="stMetric"]:hover {
    transform:translateY(-2px) !important;
    box-shadow:0 8px 28px rgba(0,87,255,0.13) !important;
}

[data-testid="stMetricValue"] { font-family:'Orbitron',sans-serif !important; color:#0057FF !important; }
[data-testid="stMetricLabel"] { color:#6B8EC2 !important; }

/* ═══════════════════════════════════════
   ALERT STYLING
   ═══════════════════════════════════════ */

.stSuccess { background:rgba(0,200,150,0.08) !important; border:1px solid rgba(0,200,150,0.35) !important; border-radius:12px !important; }
.stError   { background:rgba(255,71,87,0.07)  !important; border:1px solid rgba(255,71,87,0.3)  !important; border-radius:12px !important; }
.stWarning { background:rgba(255,184,0,0.08)  !important; border:1px solid rgba(255,184,0,0.35) !important; border-radius:12px !important; }
.stInfo    { background:rgba(0,87,255,0.05)   !important; border:1px solid rgba(0,87,255,0.22)  !important; border-radius:12px !important; }

/* ═══════════════════════════════════════
   PROGRESS & MISC
   ═══════════════════════════════════════ */

.stProgress > div > div > div { background:linear-gradient(90deg,#0057FF,#00D4FF) !important; border-radius:10px !important; }

hr { border:none !important; border-top:1px solid rgba(0,87,255,0.12) !important; margin:10px 0 !important; }

::-webkit-scrollbar { width:5px; }
::-webkit-scrollbar-track { background:#EBF4FF; }
::-webkit-scrollbar-thumb { background:linear-gradient(#0057FF,#00D4FF); border-radius:10px; }

.streamlit-expanderHeader {
    background:rgba(0,87,255,0.05) !important;
    border:1px solid rgba(0,87,255,0.15) !important;
    border-radius:12px !important; color:#0057FF !important;
    font-weight:600 !important;
}

/* ═══════════════════════════════════════
   STEP BADGE
   ═══════════════════════════════════════ */

.step-row {
    display:flex; align-items:center; gap:10px;
    font-family:'Orbitron',sans-serif;
    font-size:12px; font-weight:700;
    color:#0057FF; letter-spacing:1.5px;
    margin:16px 0 8px 0;
}

.step-circle {
    background:linear-gradient(135deg,#0057FF,#00D4FF);
    color:#FFFFFF; border-radius:50%;
    width:26px; height:26px; min-width:26px;
    display:inline-flex; align-items:center; justify-content:center;
    font-family:'Orbitron',sans-serif;
    font-size:11px; font-weight:800;
    box-shadow:0 0 12px rgba(0,87,255,0.4);
}

/* ═══════════════════════════════════════
   GLOW CARDS
   ═══════════════════════════════════════ */

.glow-card {
    background: #FFFFFF;
    border: 2px solid rgba(0,87,255,0.3);
    border-radius: 20px;
    padding: 28px 16px 24px 16px;
    text-align: center;
    position: relative;
    overflow: hidden;
    cursor: pointer;
    transition: all 0.3s ease;
    animation: border-pulse 2.4s ease-in-out infinite;
}

.glow-card-1 { animation-delay: 0.0s; }
.glow-card-2 { animation-delay: 0.6s; }
.glow-card-3 { animation-delay: 1.2s; }
.glow-card-4 { animation-delay: 1.8s; }

@keyframes border-pulse {
    0%   { border-color: rgba(0,87,255,0.25); box-shadow: 0 0 8px rgba(0,87,255,0.15); }
    50%  { border-color: rgba(0,87,255,0.7);  box-shadow: 0 0 15px rgba(0,87,255,0.4), 0 0 25px rgba(0,212,255,0.3), inset 0 0 20px rgba(0,87,255,0.08); }
    100% { border-color: rgba(0,87,255,0.25); box-shadow: 0 0 8px rgba(0,87,255,0.15); }
}

.glow-card-inner { position: relative; z-index: 2; }

.glow-icon {
    font-size: 32px; line-height: 1; display: block; margin-bottom: 12px;
    animation: icon-subtle-breathe 2.8s ease-in-out infinite alternate;
}

.glow-card-1 .glow-icon { animation-delay: 0.0s; }
.glow-card-2 .glow-icon { animation-delay: 0.4s; }
.glow-card-3 .glow-icon { animation-delay: 0.8s; }
.glow-card-4 .glow-icon { animation-delay: 1.2s; }

@keyframes icon-subtle-breathe {
    from { filter: drop-shadow(0 0 2px rgba(0,87,255,0.1));  transform: translateY(0px)  scale(1);    }
    to   { filter: drop-shadow(0 0 12px rgba(0,212,255,0.5)); transform: translateY(-3px) scale(1.08); }
}

.glow-card:hover {
    transform: translateY(-6px);
    border-color: rgba(0,87,255,0.8);
    box-shadow: 0 0 20px rgba(0,87,255,0.5), 0 0 35px rgba(0,212,255,0.3), inset 0 0 20px rgba(0,87,255,0.1), 0 12px 35px rgba(0,87,255,0.15);
}

.glow-title {
    font-family: 'Orbitron', sans-serif;
    font-size: 11px; font-weight: 700;
    color: #0057FF; letter-spacing: 1.5px; margin-bottom: 6px;
}

.glow-subtitle {
    font-family: 'Exo 2', sans-serif;
    font-size: 12px; color: #7A8EC2; line-height: 1.4;
}

/* ═══════════════════════════════════════
   FLOW METRIC CARDS
   ═══════════════════════════════════════ */

.flow-metric {
    background: #FFFFFF;
    border: 1.5px solid rgba(0,87,255,0.18);
    border-radius: 20px;
    padding: 22px 18px;
    box-shadow: 0 6px 24px rgba(0,87,255,0.09);
    transition: transform 0.35s cubic-bezier(.34,1.56,.64,1),
                box-shadow 0.35s ease,
                border-color 0.35s ease;
    cursor: default;
    position: relative;
    overflow: hidden;
}

.flow-metric::before {
    content: '';
    position: absolute; top: 0; left: -100%;
    width: 60%; height: 100%;
    background: linear-gradient(90deg, transparent, rgba(0,212,255,0.06), transparent);
    animation: shimmer 3.5s infinite;
}

@keyframes shimmer {
    0%   { left: -100%; }
    100% { left: 200%;  }
}

.flow-metric-inner { position: relative; z-index: 1; }

.flow-metric-icon { font-size: 28px; display: block; margin-bottom: 10px; }

.flow-metric-value {
    font-family: 'Orbitron', sans-serif;
    font-size: 28px; font-weight: 800; color: #0057FF;
    line-height: 1.1; margin-bottom: 4px;
}

.flow-metric-label {
    font-family: 'Exo 2', sans-serif;
    font-size: 12px; color: #6B8EC2; font-weight: 500; letter-spacing: 0.5px;
}

.flow-metric:hover {
    transform: translateY(-7px) scale(1.02);
    border-color: rgba(0,87,255,0.55);
    box-shadow: 0 14px 36px rgba(0,87,255,0.18), 0 0 0 2px rgba(0,87,255,0.2), 0 0 32px rgba(0,212,255,0.1);
}

/* ═══════════════════════════════════════
   STATUS SPOTLIGHT
   ═══════════════════════════════════════ */

@keyframes spotlightPulse {
    0%   { box-shadow: 0 0 0 0 rgba(0,87,255,0.25), 0 8px 32px rgba(0,87,255,0.12); }
    50%  { box-shadow: 0 0 0 8px rgba(0,87,255,0.06), 0 8px 32px rgba(0,87,255,0.2); }
    100% { box-shadow: 0 0 0 0 rgba(0,87,255,0.0),  0 8px 32px rgba(0,87,255,0.12); }
}

.status-spotlight { animation: spotlightPulse 2.4s ease-in-out 2; }

</style>
""", unsafe_allow_html=True)

# ════════════════════════════════════════════════════════════════
# DATA
# ════════════════════════════════════════════════════════════════

policies        = get_user_policies(user_id)
claims          = get_user_claims(user_id)
active_policies = [p for p in policies if p.get("status") == "Active"]
pending_claims  = [c for c in claims  if c.get("status") == "Pending Review"]

POLICY_ICONS = {
    "car insurance":    "🚗",
    "health insurance": "🏥",
    "travel insurance": "✈️",
    "home insurance":   "🏠",
    "life insurance":   "💙",
    "bike insurance":   "🏍️",
}

# ════════════════════════════════════════════════════════════════
# PAGE HEADER
# ════════════════════════════════════════════════════════════════

st.markdown(
    f"<h2 style='font-family:Orbitron,sans-serif;font-size:30px;font-weight:800;"
    f"background:linear-gradient(135deg,#0057FF,#00D4FF);"
    f"-webkit-background-clip:text;-webkit-text-fill-color:transparent;"
    f"letter-spacing:2px;margin-bottom:2px;line-height:1.1;'>"
    f"👋 Welcome back, {user_name.split()[0]}!</h2>",
    unsafe_allow_html=True
)
st.markdown(
    f"<p style='font-family:Exo 2,sans-serif;font-size:11px;"
    f"color:#6B8EC2;letter-spacing:3px;margin:0;'>"
    f"Today is {datetime.now().strftime('%B %d, %Y').upper()}</p>",
    unsafe_allow_html=True
)
st.markdown(
    "<div style='width:50px;height:3px;"
    "background:linear-gradient(90deg,#0057FF,#00D4FF);"
    "border-radius:10px;margin:8px 0 14px 0;'></div>",
    unsafe_allow_html=True
)
st.markdown(
    f"<div style='display:inline-block;background:rgba(0,87,255,0.06);"
    f"border:1px solid rgba(0,87,255,0.2);border-radius:20px;"
    f"padding:5px 16px;font-family:Exo 2,sans-serif;font-size:12px;"
    f"color:#0057FF;font-weight:600;margin-bottom:14px;'>"
    f"👤 &nbsp;{user_name}</div>",
    unsafe_allow_html=True
)

# ════════════════════════════════════════════════════════════════
# STATUS SPOTLIGHT
# ════════════════════════════════════════════════════════════════

view_policy_type = st.session_state.get("view_status_policy")

if view_policy_type:
    spotlight_policy = next(
        (p for p in policies if p['policy_type'].lower() == view_policy_type.lower()),
        None
    )

    if spotlight_policy:
        sp       = spotlight_policy
        sp_type  = sp['policy_type']
        sp_icon  = POLICY_ICONS.get(sp_type.lower(), "🛡️")
        sp_stat  = sp.get("status", "Active")
        sp_stat_l = sp_stat.lower()

        if sp_stat_l == "active":
            s_bg, s_border, s_color, s_emoji = "rgba(0,200,150,0.12)", "#00C896", "#00A87A", "✅"
        elif sp_stat_l == "pending":
            s_bg, s_border, s_color, s_emoji = "rgba(255,184,0,0.12)", "#FFB800", "#CC8800", "🟡"
        elif sp_stat_l in ("rejected", "cancelled"):
            s_bg, s_border, s_color, s_emoji = "rgba(255,71,87,0.12)", "#FF4757", "#CC2233", "❌"
        elif sp_stat_l == "approved":
            s_bg, s_border, s_color, s_emoji = "rgba(0,87,255,0.12)", "#0057FF", "#0057FF", "✔️"
        else:
            s_bg, s_border, s_color, s_emoji = "rgba(100,100,100,0.1)", "#999", "#666", "⚪"

        policy_claims = [
            c for c in claims
            if c.get("policy_type", "").lower() == sp_type.lower()
        ]
        claim_count = len(policy_claims)

        st.markdown(
            "<div class='step-row'><span class='step-circle'>★</span>POLICY STATUS SPOTLIGHT</div>",
            unsafe_allow_html=True
        )

        panel_l, panel_r = st.columns([3, 1])

        with panel_l:
            st.markdown(
                f"<div class='status-spotlight' style='"
                f"background:linear-gradient(135deg,#FFFFFF,{s_bg});"
                f"border:2px solid {s_border};"
                f"border-radius:20px;padding:22px 26px;"
                f"box-shadow:0 8px 32px rgba(0,87,255,0.12);'>"

                f"<div style='display:flex;align-items:center;gap:14px;margin-bottom:18px;'>"
                f"<span style='font-size:40px;'>{sp_icon}</span>"
                f"<div>"
                f"<div style='font-family:Orbitron,sans-serif;font-size:16px;"
                f"font-weight:800;color:#0057FF;letter-spacing:1.5px;'>{sp_type.upper()}</div>"
                f"<div style='font-family:Exo 2,sans-serif;font-size:11px;"
                f"color:#6B8EC2;margin-top:3px;'>Policy ID: {sp.get('policy_id','—')}</div>"
                f"</div>"
                f"<div style='margin-left:auto;background:{s_bg};"
                f"border:1.5px solid {s_border};border-radius:12px;"
                f"padding:8px 18px;font-family:Exo 2,sans-serif;font-size:14px;"
                f"font-weight:800;color:{s_color};'>{s_emoji} {sp_stat.upper()}</div>"
                f"</div>"

                f"<div style='display:grid;grid-template-columns:repeat(4,1fr);gap:12px;'>"
                f"<div style='background:rgba(0,87,255,0.05);border:1px solid rgba(0,87,255,0.1);border-radius:12px;padding:12px 14px;'>"
                f"<div style='font-family:Exo 2,sans-serif;font-size:10px;color:#6B8EC2;letter-spacing:1px;margin-bottom:4px;'>COVERAGE</div>"
                f"<div style='font-family:Orbitron,sans-serif;font-size:15px;font-weight:800;color:#0057FF;'>₹{sp.get('coverage_amount',0):,}</div>"
                f"</div>"
                f"<div style='background:rgba(0,200,150,0.05);border:1px solid rgba(0,200,150,0.15);border-radius:12px;padding:12px 14px;'>"
                f"<div style='font-family:Exo 2,sans-serif;font-size:10px;color:#6B8EC2;letter-spacing:1px;margin-bottom:4px;'>PREMIUM/YR</div>"
                f"<div style='font-family:Orbitron,sans-serif;font-size:15px;font-weight:800;color:#00A87A;'>₹{sp.get('premium_amount',0):,}</div>"
                f"</div>"
                f"<div style='background:rgba(0,87,255,0.05);border:1px solid rgba(0,87,255,0.1);border-radius:12px;padding:12px 14px;'>"
                f"<div style='font-family:Exo 2,sans-serif;font-size:10px;color:#6B8EC2;letter-spacing:1px;margin-bottom:4px;'>PURCHASED</div>"
                f"<div style='font-family:Exo 2,sans-serif;font-size:13px;font-weight:700;color:#0A1628;'>{sp.get('purchase_date','—')[:10]}</div>"
                f"</div>"
                f"<div style='background:rgba(255,184,0,0.06);border:1px solid rgba(255,184,0,0.2);border-radius:12px;padding:12px 14px;'>"
                f"<div style='font-family:Exo 2,sans-serif;font-size:10px;color:#6B8EC2;letter-spacing:1px;margin-bottom:4px;'>CLAIMS FILED</div>"
                f"<div style='font-family:Orbitron,sans-serif;font-size:15px;font-weight:800;color:#CC8800;'>{claim_count}</div>"
                f"</div>"
                f"</div>"

                + (
                    f"<div style='margin-top:16px;border-top:1px solid rgba(0,87,255,0.08);padding-top:14px;'>"
                    f"<div style='font-family:Exo 2,sans-serif;font-size:11px;font-weight:700;color:#6B8EC2;letter-spacing:1px;margin-bottom:10px;'>CLAIM HISTORY FOR THIS POLICY</div>"
                    + "".join([
                        f"<div style='display:flex;align-items:center;gap:10px;padding:7px 0;border-bottom:1px solid rgba(0,87,255,0.05);'>"
                        f"<span style='font-size:16px;'>{'✅' if c.get('status')=='Approved' else '❌' if c.get('status')=='Rejected' else '⏳'}</span>"
                        f"<div style='flex:1;'>"
                        f"<span style='font-family:Exo 2,sans-serif;font-size:12px;font-weight:600;color:#0A1628;'>Claim {c.get('claim_id','—')}</span>"
                        f"<span style='font-family:Exo 2,sans-serif;font-size:11px;color:#6B8EC2;margin-left:8px;'>{c.get('submission_date', c.get('created_at',''))[:10]}</span>"
                        f"</div>"
                        f"<span style='font-family:Exo 2,sans-serif;font-size:11px;font-weight:700;color:{'#00A87A' if c.get('status')=='Approved' else '#CC2233' if c.get('status')=='Rejected' else '#CC8800'};'>{c.get('status','—')}</span>"
                        f"</div>"
                        for c in policy_claims[-4:]
                    ])
                    + f"</div>"
                    if policy_claims else
                    f"<div style='margin-top:14px;font-family:Exo 2,sans-serif;font-size:12px;color:#6B8EC2;border-top:1px solid rgba(0,87,255,0.08);padding-top:12px;'>No claims filed for this policy yet.</div>"
                )
                + f"</div>",
                unsafe_allow_html=True
            )

        with panel_r:
            st.markdown("<div style='height:10px;'></div>", unsafe_allow_html=True)
            st.markdown(
                "<div style='background:#FFFFFF;border:1.5px solid rgba(0,87,255,0.12);"
                "border-radius:16px;padding:16px 14px;text-align:center;"
                "box-shadow:0 4px 14px rgba(0,87,255,0.07);'>"
                "<div style='font-family:Orbitron,sans-serif;font-size:9px;"
                "color:#0057FF;letter-spacing:1px;margin-bottom:10px;'>QUICK ACTIONS</div>",
                unsafe_allow_html=True
            )
            if st.button("📋 File a Claim", key="spotlight_claim", use_container_width=True):
                doc_key = sp_type.lower().replace(" ", "_")
                st.session_state["selected_policy_for_claim"] = doc_key
                st.switch_page("pages/03_file_claim_WITH_PDF.py")

            if st.button("🛒 Buy Insurance", key="spotlight_buy", use_container_width=True):
                st.switch_page("pages/02_buy_insurance.py")

            st.markdown(
                "<div style='margin-top:8px;font-family:Exo 2,sans-serif;"
                "font-size:10px;color:#6B8EC2;text-align:center;'>← Back to policies</div>"
                "</div>",
                unsafe_allow_html=True
            )
            st.markdown("<div style='height:8px;'></div>", unsafe_allow_html=True)
            if st.button("✖ Dismiss", key="dismiss_spotlight", use_container_width=True):
                del st.session_state["view_status_policy"]
                st.rerun()

        st.divider()
    else:
        del st.session_state["view_status_policy"]

# ════════════════════════════════════════════════════════════════
# METRIC CARDS
# ════════════════════════════════════════════════════════════════

