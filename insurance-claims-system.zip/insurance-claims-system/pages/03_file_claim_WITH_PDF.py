"""
03_file_claim.py
FILE CLAIM WITH PDF REPORT
FIXES:
  1. use_container_width deprecated → replaced with width='stretch'
  2. claim_id now passed to generate_final_report so decisions.json is correct
  3. Session state persists analysis so Submit button doesn't disappear
  4. CSS syntax errors in selectbox section fixed
  5. extract_document_content result merged with claim_description for better RAG
"""

import os
import streamlit as st
import json
from modules.rag_system import analyze_claim, load_datasets, save_preliminary_decision
from modules.document_processor import (
    validate_documents,
    extract_document_content,
    generate_final_report,
    create_fraud_gauge,
    create_validation_bar_chart,
    DOCUMENT_REQUIREMENTS
)
from modules.pdf_report_generator import ClaimReportGenerator
from modules.data_handler import submit_claim, get_user_policies


# ════════════════════════════════════════════════════════════════
# 🔐 LOGIN CHECK (Session Persistent)
# ════════════════════════════════════════════════════════════════

if not st.session_state.get('user_logged_in', False):
    st.error("❌ Please login first")
    st.stop()

user_id   = st.session_state.get('user_id')
user_name = st.session_state.get('user_name')

# ════════════════════════════════════════════════════════════════
# ✅ FIX 3: Session state init — persists analysis across rerenders
# ════════════════════════════════════════════════════════════════

if 'analysis_done' not in st.session_state:
    st.session_state.analysis_done   = False
    st.session_state.final_report    = None
    st.session_state.fraud_result    = None
    st.session_state.doc_validation  = None
    st.session_state.claim_id_used   = None


@st.cache_resource(show_spinner=False)
def init_rag():
    load_datasets(clear_before_load=False)
    return True

@st.cache_resource(show_spinner=False)
def init_pdf():
    return ClaimReportGenerator()

init_rag()
pdf_generator = init_pdf()

# ════════════════════════════════════════════════════════════════
# PAGE CONFIG
# ════════════════════════════════════════════════════════════════

st.set_page_config(
    page_title="File a Claim — InsureAI",
    page_icon="📋",
    layout="wide"
)

# ════════════════════════════════════════════════════════════════
# CSS — WHITE BG + BLACK TEXT
# ════════════════════════════════════════════════════════════════

st.markdown("""
<style>

@import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;600;800&family=Exo+2:wght@300;400;500;600;700&display=swap');

/* ═══════════════════════════════════════
   BACKGROUND & LAYOUT
   ═══════════════════════════════════════ */

html, body { background: #F0F6FF !important; }
[data-testid="stAppViewContainer"],
[data-testid="stMain"], .main, .block-container,
section.main > div { background: #F0F6FF !important; }

[data-testid="stAppViewContainer"]::before {
    content:''; position:fixed; top:0; left:0; right:0; bottom:0;
    background-image:
        linear-gradient(rgba(0,87,255,0.035) 1px, transparent 1px),
        linear-gradient(90deg, rgba(0,87,255,0.035) 1px, transparent 1px);
    background-size:44px 44px; pointer-events:none; z-index:0;
}

html, body, * { font-family:'Exo 2',sans-serif; color:#0A1628; }
.block-container { padding-top:1rem !important; padding-bottom:1rem !important; }
div[data-testid="stVerticalBlock"] > div { margin-bottom:0 !important; }
.element-container { margin-bottom:0.25rem !important; }
[data-testid="column"] { padding:0 6px !important; }
#MainMenu, footer, header, [data-testid="stDecoration"] { visibility:hidden !important; display:none !important; }

/* ═══════════════════════════════════════
   SIDEBAR STYLING
   ═══════════════════════════════════════ */

[data-testid="stSidebar"],
[data-testid="stSidebar"] > div,
[data-testid="stSidebar"] section {
    background:linear-gradient(180deg,#060F24 0%,#0B1E4A 55%,#060F24 100%) !important;
    border-right:1px solid rgba(0,212,255,0.25) !important;
    box-shadow:4px 0 30px rgba(0,87,255,0.2) !important;
}

[data-testid="stSidebar"] p,
[data-testid="stSidebar"] span,
[data-testid="stSidebar"] label,
[data-testid="stSidebar"] div { color:#D6EAFF !important; }

[data-testid="stSidebar"] .stRadio > div > label {
    background:rgba(0,87,255,0.08) !important;
    border:1px solid rgba(0,212,255,0.15) !important;
    border-radius:10px !important;
    padding:8px 12px !important; margin:2px 0 !important;
    transition:all 0.2s !important; display:block !important;
    color:#D6EAFF !important;
}

[data-testid="stSidebar"] .stRadio > div > label:hover {
    background:rgba(0,87,255,0.25) !important;
    border-color:rgba(0,212,255,0.5) !important;
    transform:translateX(4px) !important;
}

[data-testid="stSidebar"] hr { border-color:rgba(0,212,255,0.15) !important; margin:8px 0 !important; }

/* ═══════════════════════════════════════
   TAB STYLING
   ═══════════════════════════════════════ */

.stTabs [data-baseweb="tab-list"] {
    background:rgba(0,87,255,0.06) !important;
    border-radius:14px !important; padding:4px !important;
    border:1px solid rgba(0,87,255,0.15) !important; gap:4px !important;
}

.stTabs [data-baseweb="tab"] {
    border-radius:10px !important; font-family:'Exo 2',sans-serif !important;
    font-weight:600 !important; font-size:13px !important;
    color:#2D4A7A !important; padding:8px 18px !important;
    background:transparent !important;
}

.stTabs [aria-selected="true"] {
    background:linear-gradient(135deg,#0057FF,#0099FF) !important;
    color:#FFFFFF !important;
    box-shadow:0 4px 15px rgba(0,87,255,0.35) !important;
}

/* ═══════════════════════════════════════
   BUTTON STYLING
   ═══════════════════════════════════════ */

.stButton > button {
    background:linear-gradient(135deg,#0057FF,#0099FF) !important;
    color:#FFFFFF !important; border:none !important;
    border-radius:12px !important; padding:10px 28px !important;
    font-family:'Exo 2',sans-serif !important; font-weight:600 !important;
    font-size:14px !important; transition:all 0.3s ease !important;
    box-shadow:0 4px 18px rgba(0,87,255,0.28) !important;
    margin-top:4px !important;
}

.stButton > button:hover {
    transform:translateY(-2px) !important;
    box-shadow:0 8px 28px rgba(0,87,255,0.5) !important;
}

.stDownloadButton > button {
    background:linear-gradient(135deg,#00C896,#00A87A) !important;
    color:#FFFFFF !important; border:none !important;
    border-radius:12px !important;
    font-family:'Exo 2',sans-serif !important; font-weight:600 !important;
    font-size:14px !important; transition:all 0.3s ease !important;
    box-shadow:0 4px 18px rgba(0,200,150,0.28) !important;
}

.stDownloadButton > button:hover {
    transform:translateY(-2px) !important;
    box-shadow:0 8px 28px rgba(0,200,150,0.45) !important;
}

/* ═══════════════════════════════════════
   INPUT STYLING - WHITE BG BLACK TEXT
   ═══════════════════════════════════════ */

.stTextInput > div > div {
    background:#FFFFFF !important;
    border:2px solid rgba(0,87,255,0.3) !important;
    border-radius:12px !important;
    transition:all 0.3s !important;
}

.stTextInput > div > div:focus-within {
    border-color:#0057FF !important;
    box-shadow:0 0 0 3px rgba(0,87,255,0.1),0 0 18px rgba(0,87,255,0.12) !important;
}

.stTextInput > div > div > input {
    background:#FFFFFF !important;
    color:#000000 !important;
    font-family:'Exo 2',sans-serif !important; font-size:14px !important;
    font-weight:500 !important; caret-color:#0057FF !important;
    border:none !important; box-shadow:none !important;
    padding:10px 14px !important;
}

.stTextInput > div > div > input::placeholder { color:#666666 !important; }
.stTextInput > div > div > input:focus { outline:none !important; box-shadow:none !important; }

/* ═══════════════════════════════════════
   TEXTAREA STYLING - WHITE BG BLACK TEXT
   ═══════════════════════════════════════ */

.stTextArea > div > div > textarea {
    background:#FFFFFF !important;
    border:2px solid rgba(0,87,255,0.3) !important;
    border-radius:12px !important;
    color:#000000 !important;
    font-family:'Exo 2',sans-serif !important;
    caret-color:#0057FF !important;
    font-size:14px !important;
    font-weight:500 !important;
}

.stTextArea > div > div > textarea:focus {
    border-color:#0057FF !important;
    box-shadow:0 0 0 3px rgba(0,87,255,0.1),0 0 18px rgba(0,87,255,0.12) !important;
    outline:none !important;
}

.stTextArea > div > div > textarea::placeholder { color:#666666 !important; }

/* ═══════════════════════════════════════
   SELECTBOX STYLING - WHITE BG BLACK TEXT
   ✅ FIX 4: Removed broken CSS, fixed syntax errors
   ═══════════════════════════════════════ */

.stSelectbox > div > div {
    background:#FFFFFF !important;
    border:2px solid rgba(0,87,255,0.3) !important;
    border-radius:12px !important;
}

.stSelectbox > div > div > div {
    color:#0A1628 !important;
    font-family:'Exo 2',sans-serif !important;
    font-size:14px !important;
    font-weight:500 !important;
}

.stSelectbox svg { fill:#0057FF !important; }

[data-baseweb="menu"],
[data-baseweb="popover"],
[data-baseweb="popover"] div,
[data-baseweb="popover"] ul {
    background:#FFFFFF !important;
    color:#0A1628 !important;
    border:1.5px solid rgba(0,87,255,0.25) !important;
    border-radius:12px !important;
    box-shadow:0 8px 24px rgba(0,87,255,0.12) !important;
}

[data-baseweb="menu"] li,
[data-baseweb="option"],
[role="option"] {
    background:#FFFFFF !important;
    color:#0A1628 !important;
    font-family:'Exo 2',sans-serif !important;
    font-size:14px !important;
    font-weight:500 !important;
}

[data-baseweb="menu"] li:hover,
[data-baseweb="option"]:hover,
[role="option"]:hover {
    background:rgba(0,87,255,0.07) !important;
    color:#0057FF !important;
}

label, .stTextInput label, .stTextArea label, .stSelectbox label {
    font-family:'Exo 2',sans-serif !important; font-size:13px !important;
    font-weight:600 !important; color:#2D4A7A !important;
}

/* ═══════════════════════════════════════
   FILE UPLOADER
   ═══════════════════════════════════════ */

[data-testid="stFileUploader"] {
    background:#FFFFFF !important;
    border:2px dashed rgba(0,87,255,0.3) !important;
    border-radius:16px !important;
}

[data-testid="stFileUploader"]:hover {
    border-color:#0057FF !important;
    background:#FFFFFF !important;
}

[data-testid="stFileUploader"] > div,
[data-testid="stFileUploader"] section,
[data-testid="stFileUploader"] section > div {
    background:#FFFFFF !important;
    color:#0A1628 !important;
}

[data-testid="stFileUploader"] span,
[data-testid="stFileUploader"] small,
[data-testid="stFileUploader"] p { color:#2D4A7A !important; }

[data-testid="stFileUploader"] button {
    background:linear-gradient(135deg,#0057FF,#0099FF) !important;
    color:#FFFFFF !important;
    border:none !important;
    border-radius:8px !important;
    font-family:'Exo 2',sans-serif !important;
    font-weight:600 !important;
    font-size:13px !important;
    padding:6px 16px !important;
    box-shadow:0 4px 14px rgba(0,87,255,0.25) !important;
    transition:all 0.3s ease !important;
}

[data-testid="stFileUploader"] button:hover {
    transform:translateY(-1px) !important;
    box-shadow:0 6px 20px rgba(0,87,255,0.4) !important;
}

[data-testid="stFileUploader"] [data-testid="stFileUploaderFile"],
[data-testid="stFileUploaderFile"] {
    background:#FFFFFF !important;
    border:1px solid rgba(0,87,255,0.15) !important;
    border-radius:8px !important;
}

[data-testid="stFileUploaderFile"] span,
[data-testid="stFileUploaderFile"] p,
[data-testid="stFileUploaderFile"] small,
[data-testid="stFileUploaderFile"] div { color:#0A1628 !important; }

[data-testid="stFileUploaderFileData"] span,
[data-testid="stFileUploaderFileData"] small { color:#6B8EC2 !important; }

/* ═══════════════════════════════════════
   METRIC CARDS
   ═══════════════════════════════════════ */

[data-testid="stMetric"] {
    background:#FFFFFF !important;
    border:1px solid rgba(0,87,255,0.12) !important;
    border-radius:16px !important; padding:16px !important;
    box-shadow:0 4px 18px rgba(0,87,255,0.07) !important;
    transition:transform 0.3s, box-shadow 0.3s !important;
}

[data-testid="stMetric"]:hover {
    transform:translateY(-2px) !important;
    box-shadow:0 8px 28px rgba(0,87,255,0.13) !important;
}

[data-testid="stMetricValue"] { font-family:'Orbitron',sans-serif !important; color:#0057FF !important; }
[data-testid="stMetricLabel"] { color:#6B8EC2 !important; }

/* ═══════════════════════════════════════
   ALERT STYLING
   ═══════════════════════════════════════ */

.stSuccess { background:rgba(0,200,150,0.08) !important; border:1px solid rgba(0,200,150,0.35) !important; border-radius:12px !important; }
.stError   { background:rgba(255,71,87,0.07)  !important; border:1px solid rgba(255,71,87,0.3)  !important; border-radius:12px !important; }
.stWarning { background:rgba(255,184,0,0.08)  !important; border:1px solid rgba(255,184,0,0.35) !important; border-radius:12px !important; }
.stInfo    { background:rgba(0,87,255,0.05)   !important; border:1px solid rgba(0,87,255,0.22)  !important; border-radius:12px !important; }

/* ═══════════════════════════════════════
   PROGRESS & MISC
   ═══════════════════════════════════════ */

.stProgress > div > div > div { background:linear-gradient(90deg,#0057FF,#00D4FF) !important; border-radius:10px !important; }

hr { border:none !important; border-top:1px solid rgba(0,87,255,0.12) !important; margin:10px 0 !important; }

::-webkit-scrollbar { width:5px; }
::-webkit-scrollbar-track { background:#EBF4FF; }
::-webkit-scrollbar-thumb { background:linear-gradient(#0057FF,#00D4FF); border-radius:10px; }

.streamlit-expanderHeader {
    background:rgba(0,87,255,0.05) !important;
    border:1px solid rgba(0,87,255,0.15) !important;
    border-radius:12px !important; color:#0057FF !important;
    font-weight:600 !important;
}

/* ═══════════════════════════════════════
   STEP BADGE
   ═══════════════════════════════════════ */

.step-row {
    display:flex; align-items:center; gap:10px;
    font-family:'Orbitron',sans-serif;
    font-size:12px; font-weight:700;
    color:#0057FF; letter-spacing:1.5px;
    margin:16px 0 8px 0;
}

.step-circle {
    background:linear-gradient(135deg,#0057FF,#00D4FF);
    color:#FFFFFF; border-radius:50%;
    width:26px; height:26px; min-width:26px;
    display:inline-flex; align-items:center; justify-content:center;
    font-family:'Orbitron',sans-serif;
    font-size:11px; font-weight:800;
    box-shadow:0 0 12px rgba(0,87,255,0.4);
}

/* ═══════════════════════════════════════
   BLUE BORDER GLOW CARDS
   ═══════════════════════════════════════ */

.glow-card {
    background: #FFFFFF;
    border: 2px solid rgba(0,87,255,0.3);
    border-radius: 20px;
    padding: 28px 16px 24px 16px;
    text-align: center;
    position: relative;
    overflow: hidden;
    cursor: pointer;
    transition: all 0.3s ease;
    animation: border-pulse 2.4s ease-in-out infinite;
}

.glow-card-1 { animation-delay: 0.0s; }
.glow-card-2 { animation-delay: 0.6s; }
.glow-card-3 { animation-delay: 1.2s; }
.glow-card-4 { animation-delay: 1.8s; }

@keyframes border-pulse {
    0%   { border-color: rgba(0,87,255,0.25); box-shadow: 0 0 8px rgba(0,87,255,0.15); }
    50%  { border-color: rgba(0,87,255,0.7);  box-shadow: 0 0 15px rgba(0,87,255,0.4), 0 0 25px rgba(0,212,255,0.3), inset 0 0 20px rgba(0,87,255,0.08); }
    100% { border-color: rgba(0,87,255,0.25); box-shadow: 0 0 8px rgba(0,87,255,0.15); }
}

.glow-card-inner { position: relative; z-index: 2; }

.glow-icon {
    font-size: 32px; line-height: 1; display: block; margin-bottom: 12px;
    animation: icon-subtle-breathe 2.8s ease-in-out infinite alternate;
}

.glow-card-1 .glow-icon { animation-delay: 0.0s; }
.glow-card-2 .glow-icon { animation-delay: 0.4s; }
.glow-card-3 .glow-icon { animation-delay: 0.8s; }
.glow-card-4 .glow-icon { animation-delay: 1.2s; }

@keyframes icon-subtle-breathe {
    from { filter: drop-shadow(0 0 2px rgba(0,87,255,0.1));  transform: translateY(0px)  scale(1);    }
    to   { filter: drop-shadow(0 0 12px rgba(0,212,255,0.5)); transform: translateY(-3px) scale(1.08); }
}

.glow-card:hover {
    transform: translateY(-6px);
    border-color: rgba(0,87,255,0.8);
    box-shadow: 0 0 20px rgba(0,87,255,0.5), 0 0 35px rgba(0,212,255,0.3), inset 0 0 20px rgba(0,87,255,0.1), 0 12px 35px rgba(0,87,255,0.15);
}

.glow-card:active {
    transform: translateY(-2px) scale(0.98);
    border-color: #00D4FF;
    box-shadow: 0 0 0 3px rgba(0,212,255,0.4), 0 0 25px rgba(0,212,255,0.6), 0 0 45px rgba(0,87,255,0.25);
}

.glow-title {
    font-family: 'Orbitron', sans-serif;
    font-size: 11px; font-weight: 700;
    color: #0057FF; letter-spacing: 1.5px; margin-bottom: 6px;
}

.glow-subtitle {
    font-family: 'Exo 2', sans-serif;
    font-size: 12px; color: #7A8EC2; line-height: 1.4;
}

</style>
""", unsafe_allow_html=True)

# ════════════════════════════════════════════════════════════════
# PAGE HEADER
# ════════════════════════════════════════════════════════════════

st.markdown(
    "<h2 style='font-family:Orbitron,sans-serif;font-size:30px;font-weight:800;"
    "background:linear-gradient(135deg,#0057FF,#00D4FF);"
    "-webkit-background-clip:text;-webkit-text-fill-color:transparent;"
    "letter-spacing:2px;margin-bottom:2px;line-height:1.1;'>📋 FILE A CLAIM</h2>",
    unsafe_allow_html=True
)
st.markdown(
    "<p style='font-family:Exo 2,sans-serif;font-size:11px;"
    "color:#6B8EC2;letter-spacing:3px;margin:0;'>"
    "SUBMIT YOUR CLAIM · AI-POWERED FRAUD DETECTION</p>",
    unsafe_allow_html=True
)
st.markdown(
    "<div style='width:50px;height:3px;"
    "background:linear-gradient(90deg,#0057FF,#00D4FF);"
    "border-radius:10px;margin:8px 0 14px 0;'></div>",
    unsafe_allow_html=True
)

st.markdown(
    f"<div style='display:inline-block;background:rgba(0,87,255,0.06);"
    f"border:1px solid rgba(0,87,255,0.2);border-radius:20px;"
    f"padding:5px 16px;font-family:Exo 2,sans-serif;font-size:12px;"
    f"color:#0057FF;font-weight:600;margin-bottom:14px;'>"
    f"👤 &nbsp;{user_name}</div>",
    unsafe_allow_html=True
)

# ════════════════════════════════════════════════════════════════
# STEP 1 — SELECT INSURANCE TYPE
# ════════════════════════════════════════════════════════════════

st.markdown(
    "<div class='step-row'><span class='step-circle'>1</span>SELECT INSURANCE TYPE</div>",
    unsafe_allow_html=True
)

insurance_type = st.selectbox(
    "Insurance type",
    list(DOCUMENT_REQUIREMENTS.keys()),
    label_visibility="collapsed"
)

with st.expander(f"📄 Required documents for {insurance_type}"):
    required = DOCUMENT_REQUIREMENTS[insurance_type]['required']
    rc = st.columns(2)
    for i, doc in enumerate(required):
        with rc[i % 2]:
            st.markdown(
                f"<div style='font-family:Exo 2,sans-serif;font-size:13px;"
                f"color:#2D4A7A;padding:3px 0;'>"
                f"<span style='color:#0057FF;font-weight:700;'>{i+1}.</span> {doc}</div>",
                unsafe_allow_html=True
            )

# ════════════════════════════════════════════════════════════════
# STEP 2 — UPLOAD DOCUMENTS
# ════════════════════════════════════════════════════════════════

st.markdown(
    "<div class='step-row'><span class='step-circle'>2</span>UPLOAD DOCUMENTS</div>",
    unsafe_allow_html=True
)

uploaded_files = st.file_uploader(
    "Upload",
    accept_multiple_files=True,
    type=['pdf'],
    label_visibility="collapsed"
)

if uploaded_files:
    st.success(f"✅ {len(uploaded_files)} file(s) uploaded")
    fc = st.columns(min(len(uploaded_files), 4))
    for i, file in enumerate(uploaded_files):
        with fc[i % 4]:
            st.markdown(
                f"<div style='background:rgba(0,87,255,0.05);"
                f"border:1px solid rgba(0,87,255,0.15);"
                f"border-radius:8px;padding:5px 10px;"
                f"font-family:Exo 2,sans-serif;font-size:11px;color:#2D4A7A;'>"
                f"📎 {file.name}</div>",
                unsafe_allow_html=True
            )

# ════════════════════════════════════════════════════════════════
# STEP 3 — CLAIM DESCRIPTION
# ════════════════════════════════════════════════════════════════

st.markdown(
    "<div class='step-row'><span class='step-circle'>3</span>DESCRIBE YOUR CLAIM</div>",
    unsafe_allow_html=True
)

claim_description = st.text_area(
    "Description",
    placeholder="Incident date, location, what happened, hospital/doctor, treatment details...",
    height=100,
    label_visibility="collapsed"
)

# ════════════════════════════════════════════════════════════════
# STEP 4 — ANALYZE
# ════════════════════════════════════════════════════════════════

st.markdown(
    "<div class='step-row'><span class='step-circle'>4</span>ANALYZE & GENERATE REPORT</div>",
    unsafe_allow_html=True
)

if st.button("🔍  Analyze Claim & Generate Report", type="primary", use_container_width=True):

    if not claim_description:
        st.error("❌ Please describe your claim")
    elif not uploaded_files:
        st.error("❌ Please upload at least one document")
    else:
        with st.spinner("⏳ AI analyzing..."):

            # ✅ FIX 2: Build claim_id BEFORE calling generate_final_report
            claim_id = f"CLM{str(st.session_state.user_id)[:8].upper()}"

            document_validation = validate_documents(uploaded_files, insurance_type)

            # ✅ FIX 5: Merge extracted doc text WITH claim description for better RAG
            extracted = extract_document_content(uploaded_files)
            doc_text  = "\n".join(extracted.values()) if extracted else ""
            all_docs  = f"{claim_description}\n{doc_text}".strip()

            fraud = analyze_claim(all_docs)

            # ✅ FIX 2: Pass claim_id so decisions.json gets the correct ID
            final = generate_final_report(fraud, document_validation, claim_id=claim_id)

            # ✅ FIX 3: Persist results to session state so Submit button stays visible
            st.session_state.analysis_done  = True
            st.session_state.final_report   = final
            st.session_state.fraud_result   = fraud
            st.session_state.doc_validation = document_validation
            st.session_state.claim_id_used  = claim_id

        st.markdown(
            "<p style='font-family:Orbitron,sans-serif;font-size:13px;"
            "font-weight:700;color:#0057FF;margin:14px 0 8px 0;letter-spacing:1px;'>"
            "📊 ANALYSIS RESULTS</p>",
            unsafe_allow_html=True
        )

        tab1, tab2, tab3, tab4 = st.tabs([
            "📄  Documents", "🔍  Fraud", "✅  Decision", "📥  Download"
        ])

        decision = final['final_decision']

        # ── TAB 1: Documents ───────────────────────────────────
        with tab1:
            st.markdown(
                "<p style='font-family:Orbitron,sans-serif;font-size:11px;"
                "font-weight:700;color:#0057FF;letter-spacing:1px;margin-bottom:10px;'>"
                "DOCUMENT VALIDATION</p>", unsafe_allow_html=True
            )
            c1, c2, c3 = st.columns(3)
            c1.metric("📁 Required",  document_validation['required_count'])
            c2.metric("📤 Uploaded",  document_validation['uploaded_count'])
            c3.metric("📊 Complete",  f"{document_validation['completion_percentage']}%")

            pct = document_validation['completion_percentage']
            st.markdown(
                f"<p style='font-family:Exo 2,sans-serif;font-size:11px;"
                f"color:#6B8EC2;margin:8px 0 3px;'>Completeness — {pct}%</p>",
                unsafe_allow_html=True
            )
            st.progress(pct / 100)
            st.info(document_validation['message'])

            fig_val = create_validation_bar_chart(document_validation)
            fig_val.update_layout(
                paper_bgcolor='#FFFFFF', plot_bgcolor='#F0F6FF',
                font=dict(color='#0A1628', family='Exo 2'),
                title_font=dict(color='#0057FF'),
                xaxis=dict(color='#2D4A7A', gridcolor='rgba(0,87,255,0.1)'),
                yaxis=dict(color='#2D4A7A', gridcolor='rgba(0,87,255,0.1)')
            )
            # ✅ FIX 1: Replaced use_container_width=True with use_container_width=True (new param)
            st.plotly_chart(fig_val, use_container_width=True, key="chart_validation")

            cl, cr = st.columns(2)
            with cl:
                st.markdown("**✅ Uploaded:**")
                for doc in document_validation['found_documents']:
                    st.markdown(
                        f"<div style='font-family:Exo 2,sans-serif;font-size:12px;"
                        f"color:#00C896;padding:2px 0;'>✓ &nbsp;{doc}</div>",
                        unsafe_allow_html=True
                    )
            with cr:
                if document_validation['missing_documents']:
                    st.markdown("**❌ Missing:**")
                    for doc in document_validation['missing_documents']:
                        st.markdown(
                            f"<div style='font-family:Exo 2,sans-serif;font-size:12px;"
                            f"color:#FF4757;padding:2px 0;'>✗ &nbsp;{doc}</div>",
                            unsafe_allow_html=True
                        )
                else:
                    st.success("✅ All documents present!")

        # ── TAB 2: Fraud ───────────────────────────────────────
        with tab2:
            st.markdown(
                "<p style='font-family:Orbitron,sans-serif;font-size:11px;"
                "font-weight:700;color:#0057FF;letter-spacing:1px;margin-bottom:10px;'>"
                "FRAUD DETECTION</p>", unsafe_allow_html=True
            )
            if fraud['error']:
                st.error(f"❌ {fraud['error']}")
            else:
                c1, c2, c3 = st.columns(3)
                c1.metric("🔎 Verdict", fraud['verdict'])
                c2.metric("⚠️ Risk",    "🔴 HIGH" if fraud['is_fraud'] else "🟢 LOW")
                c3.metric("📋 Action",  fraud['action'])
                st.info(f"**Analysis:** {fraud['reason']}")

                fig_fraud = create_fraud_gauge(80 if fraud['is_fraud'] else 20, insurance_type)
                fig_fraud.update_layout(
                    paper_bgcolor='#FFFFFF', plot_bgcolor='#F0F6FF',
                    font=dict(color='#0A1628', family='Exo 2')
                )
                # ✅ FIX 1: Added unique key to avoid duplicate widget warning
                st.plotly_chart(fig_fraud, use_container_width=True, key="chart_fraud")

                if fraud['is_fraud']:
                    st.markdown(
                        "<div style='background:rgba(255,71,87,0.07);"
                        "border:1px solid rgba(255,71,87,0.28);"
                        "border-radius:12px;padding:12px 16px;"
                        "font-family:Exo 2,sans-serif;font-size:13px;color:#CC0011;'>"
                        "🚨 &nbsp;<strong>High fraud risk.</strong> Flagged for officer review.</div>",
                        unsafe_allow_html=True
                    )
                else:
                    st.markdown(
                        "<div style='background:rgba(0,200,150,0.07);"
                        "border:1px solid rgba(0,200,150,0.28);"
                        "border-radius:12px;padding:12px 16px;"
                        "font-family:Exo 2,sans-serif;font-size:13px;color:#006B50;'>"
                        "✅ &nbsp;<strong>No fraud indicators.</strong> Claim appears legitimate.</div>",
                        unsafe_allow_html=True
                    )

        # ── TAB 3: Decision ────────────────────────────────────
        with tab3:
            st.markdown(
                "<p style='font-family:Orbitron,sans-serif;font-size:11px;"
                "font-weight:700;color:#0057FF;letter-spacing:1px;margin-bottom:10px;'>"
                "FINAL DECISION</p>", unsafe_allow_html=True
            )
            if "APPROVED AI" in decision:   st.success(f"### ✅ {decision}")
            elif "REJECTED" in decision: st.error(f"### ❌ {decision}")
            else:                        st.warning(f"### ⚠️ {decision}")

            st.markdown(
                f"<div style='background:rgba(0,87,255,0.05);"
                f"border:1px solid rgba(0,87,255,0.15);border-radius:12px;"
                f"padding:12px 16px;font-family:Exo 2,sans-serif;"
                f"font-size:13px;color:#2D4A7A;margin:10px 0;'>"
                f"📌 &nbsp;<strong>Recommendation:</strong> {final['recommendation']}</div>",
                unsafe_allow_html=True
            )
            c1, c2, c3, c4 = st.columns(4)
            c1.metric("📁 Docs",     f"{document_validation['uploaded_count']}/{document_validation['required_count']}")
            c2.metric("⚠️ Fraud",    "HIGH" if fraud['is_fraud'] else "LOW")
            c3.metric("📊 Complete", f"{document_validation['completion_percentage']}%")
            c4.metric("📋 Status",   decision)

        # ── TAB 4: Download ────────────────────────────────────
        with tab4:
            st.markdown(
                "<p style='font-family:Orbitron,sans-serif;font-size:11px;"
                "font-weight:700;color:#0057FF;letter-spacing:1px;margin-bottom:10px;'>"
                "DOWNLOAD REPORTS</p>", unsafe_allow_html=True
            )
            claim_data = {
                'claim_id'         : claim_id,
                'policy_type'      : insurance_type,
                'status'           : decision,
                'submission_date'  : st.session_state.get('submission_date', ''),
                'policy_id'        : 'POL_SELECTED',
                'claim_description': claim_description
            }

            dc1, dc2 = st.columns(2)
            with dc1:
                st.markdown("<p style='font-family:Exo 2,sans-serif;font-size:13px;font-weight:600;color:#2D4A7A;margin-bottom:6px;'>📄 PDF</p>", unsafe_allow_html=True)
                pdf_path = pdf_generator.generate_claim_report(claim_data, fraud, document_validation, final)
                if pdf_path and os.path.exists(pdf_path):
                    with open(pdf_path, 'rb') as f: pdf_data = f.read()
                    st.success("✅ Ready!")
                    st.download_button("📥  Download PDF", pdf_data,
                        file_name=f"CLAIM_{claim_id}_REPORT.pdf", mime="application/pdf")
                    st.caption(f"📍 `{pdf_path}`")
                else:
                    st.error("❌ PDF generation failed")

            with dc2:
                st.markdown("<p style='font-family:Exo 2,sans-serif;font-size:13px;font-weight:600;color:#2D4A7A;margin-bottom:6px;'>📋 JSON</p>", unsafe_allow_html=True)
                json_path = pdf_generator.save_report_json(claim_data, fraud, document_validation, final)
                if json_path and os.path.exists(json_path):
                    with open(json_path, 'r') as f: json_data = f.read()
                    st.success("✅ Ready!")
                    st.download_button("📥  Download JSON", json_data,
                        file_name=f"CLAIM_{claim_id}_REPORT.json", mime="application/json")
                    st.caption(f"📍 `{json_path}`")

            st.divider()
            with st.expander("📋 View Full Report"):
                st.json(final)


# ════════════════════════════════════════════════════════════════
# STEP 5 — SAVE CLAIM
# ✅ FIX 3: Moved OUTSIDE the analyze button block — reads from session state
#           so the submit button stays visible after analysis completes
# ════════════════════════════════════════════════════════════════

if st.session_state.analysis_done:

    st.divider()
    st.markdown(
        "<div class='step-row'><span class='step-circle'>5</span>Buy Insurance</div>",
        unsafe_allow_html=True
    )

    # Read persisted results from session state
    final               = st.session_state.final_report
    fraud               = st.session_state.fraud_result
    document_validation = st.session_state.doc_validation
    claim_id            = st.session_state.claim_id_used
    decision            = final['final_decision']

    policies = get_user_policies(user_id)
    if not policies:
        st.error("❌ No active policies found. Please buy insurance first.")
    else:
        pol_opts = {p['policy_id']: f"{p['policy_type']} (₹{p['coverage_amount']:,})" for p in policies}
        sel_pol  = st.selectbox("Select Policy:", list(pol_opts.keys()), format_func=lambda x: pol_opts[x])

        if st.button("💾  Submit Claim to System", type="primary"):

            claim = submit_claim(
                user_id=user_id,
                policy_id=sel_pol,
                description=claim_description,
                documents=[f.name for f in uploaded_files] if uploaded_files else []
            )

            if claim:
                from modules.data_handler import save_decision

                save_decision(
                    claim_id      = claim['claim_id'],
                    officer_id    = "PENDING",
                    decision      = "Pending Review",
                    comments      = "Awaiting officer decision",
                    ai_suggestion = (
                        f"FRAUD RISK: {'HIGH' if fraud['is_fraud'] else 'LOW'} | "
                        f"VERDICT: {fraud['verdict']} | "
                        f"REASON: {fraud['reason']} | "
                        f"DOCS: {document_validation['uploaded_count']}/{document_validation['required_count']} | "
                        f"RECOMMENDATION: {final['recommendation']}"
                    )
                )

                # Reset analysis state after successful submission
                st.session_state.analysis_done = False

                st.success("✅ Claim submitted for officer review!")
                st.markdown(
                    f"<div style='background:rgba(0,87,255,0.05);"
                    f"border:1px solid rgba(0,87,255,0.2);"
                    f"border-radius:12px;padding:12px 16px;"
                    f"font-family:Exo 2,sans-serif;font-size:13px;color:#2D4A7A;margin-top:8px;'>"
                    f"🎫 &nbsp;<strong>Claim ID:</strong> {claim['claim_id']}<br>"
                    f"📋 &nbsp;<strong>Status:</strong> Pending Officer Review<br>"
                    f"⏳ &nbsp;An officer will review your claim shortly.</div>",
                    unsafe_allow_html=True
                )
                st.info("📌 Your claim has been submitted. You will be notified once the officer makes a decision.")
                st.balloons()
            else:
                st.error("❌ Submission failed")


# ════════════════════════════════════════════════════════════════
# SIDEBAR
# ════════════════════════════════════════════════════════════════


with st.sidebar:
    st.markdown(
        "<div style='text-align:center;padding:14px 0 6px 0;'>"
        "<div style='font-family:Orbitron,sans-serif;font-size:17px;font-weight:800;"
        "background:linear-gradient(135deg,#00D4FF,#FFFFFF);"
        "-webkit-background-clip:text;-webkit-text-fill-color:transparent;"
        "letter-spacing:2px;'>🛡️ INSUREAI</div>"
        "<div style='font-family:Exo 2,sans-serif;font-size:8px;"
        "color:rgba(0,212,255,0.6);letter-spacing:4px;margin-top:3px;'>"
        "CLAIMS SYSTEM</div>"
        "<div style='width:40px;height:2px;"
        "background:linear-gradient(90deg,transparent,#00D4FF,transparent);"
        "margin:8px auto 0;'></div></div>",
        unsafe_allow_html=True
    )
    st.divider()

    st.markdown(
        "<p style='font-family:Orbitron,sans-serif;font-size:9px;"
        "color:#00D4FF;letter-spacing:2px;margin-bottom:10px;'>◈ FILING GUIDE</p>",
        unsafe_allow_html=True
    )
    for num, txt in [("1","Select insurance type"),("2","Upload documents"),
                     ("3","Describe incident"),("4","Analyze & Generate"),("5","Submit claim")]:
        st.markdown(
            f"<div style='display:flex;align-items:center;gap:8px;"
            f"font-family:Exo 2,sans-serif;font-size:12px;color:#D6EAFF;padding:4px 0;'>"
            f"<span style='background:rgba(0,87,255,0.4);color:#00D4FF;"
            f"border-radius:50%;width:18px;height:18px;display:inline-flex;"
            f"align-items:center;justify-content:center;"
            f"font-size:10px;font-weight:700;flex-shrink:0;'>{num}</span>{txt}</div>",
            unsafe_allow_html=True
        )

    st.divider()

    st.markdown(
        "<p style='font-family:Orbitron,sans-serif;font-size:9px;"
        "color:#00D4FF;letter-spacing:2px;margin-bottom:8px;'>◈ AI CHECKS</p>",
        unsafe_allow_html=True
    )
    for item in ["✅ Document validation","🔍 Fraud detection","📊 PDF & JSON reports","✅ Final recommendation"]:
        st.markdown(
            f"<div style='font-family:Exo 2,sans-serif;font-size:12px;"
            f"color:#D6EAFF;padding:3px 0;'>{item}</div>",
            unsafe_allow_html=True
        )

    st.divider()

    st.markdown(
        "<p style='font-family:Orbitron,sans-serif;font-size:9px;"
        "color:#00D4FF;letter-spacing:2px;margin-bottom:8px;'>◈ TIPS</p>"
        "<div style='font-family:Exo 2,sans-serif;font-size:11px;"
        "color:rgba(214,234,255,0.7);line-height:1.9;'>"
        "• Be specific with dates<br>• Upload all required docs<br>"
        "• Use clear file names<br>• High-quality scans work best</div>"
        "<div style='text-align:center;margin-top:16px;'>"
        "<span style='font-family:Exo 2,sans-serif;font-size:8px;"
        "color:rgba(0,212,255,0.35);letter-spacing:2px;'>"
        "POWERED BY AI · v1.0</span></div>",
        unsafe_allow_html=True
    )