"""

06_officer_dashboard.py

OFFICER DASHBOARD — InsureAI

Integrates: data_handler, rag_system (2-step verification), document_processor

UI: Clean Light Theme — warm whites, slate accents, refined typography

"""

import streamlit as st
import sys
import json
import os
from pathlib import Path

# ── Fix working directory so all relative-path modules find their data files ──
_SCRIPT_DIR   = Path(__file__).resolve().parent
_PROJECT_ROOT = (
    _SCRIPT_DIR.parent
    if (_SCRIPT_DIR.parent / "modules").exists()
    else _SCRIPT_DIR
)
os.chdir(_PROJECT_ROOT)
sys.path.insert(0, str(_PROJECT_ROOT))

from modules.data_handler import (
    get_all_claims,
    get_user_by_id,
    get_policy_by_id,
    get_decision_by_claim,
    save_decision,
    update_claim_status,
)
from modules.rag_system import (
    get_pending_claims_for_officer,
    save_officer_final_decision,
)

# ════════════════════════════════════════════════════════════════
# DECISIONS.JSON — LOADER & HELPERS
# ════════════════════════════════════════════════════════════════

_THIS_DIR     = Path(__file__).resolve().parent
_PROJECT_ROOT = _THIS_DIR.parent
_SEARCH_PATHS = [
    _PROJECT_ROOT / "data"    / "decisions.json",
    _THIS_DIR     / "data"    / "decisions.json",
    _PROJECT_ROOT             / "decisions.json",
    _THIS_DIR                 / "decisions.json",
    Path(os.getcwd()) / "data"/ "decisions.json",
    Path(os.getcwd())         / "decisions.json",
]
DECISIONS_FILE: Path = next(
    (p for p in _SEARCH_PATHS if p.exists()),
    _PROJECT_ROOT / "data" / "decisions.json",
)


def _resolve_decisions_file() -> Path:
    return next(
        (p for p in _SEARCH_PATHS if p.exists()),
        _PROJECT_ROOT / "data" / "decisions.json",
    )


def load_decisions() -> list:
    fpath = _resolve_decisions_file()
    if not fpath.exists():
        return []
    try:
        with open(fpath, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, list) else [data]
    except (json.JSONDecodeError, OSError):
        return []


def save_officer_action_to_decisions(claim_id: str, officer_id: str,
                                      officer_action: str, comments: str = "") -> bool:
    fpath = _resolve_decisions_file()
    records = load_decisions()
    changed = False
    for rec in records:
        if rec.get("claim_id") == claim_id:
            current = rec.get("action_officer", "PENDING")
            if current in ("PENDING", "", None):
                rec["action_officer"]   = officer_action.upper()
                rec["final_decision"]   = officer_action.upper()
                rec["officer_id"]       = officer_id
                rec["officer_comments"] = comments
                changed = True
    if changed:
        try:
            with open(fpath, "w", encoding="utf-8") as f:
                json.dump(records, f, indent=2)
            return True
        except OSError:
            return False
    return False


def get_decisions_by_claim(claim_id: str) -> list:
    return [r for r in load_decisions() if r.get("claim_id") == claim_id]


def get_latest_decision(claim_id: str) -> dict:
    recs = get_decisions_by_claim(claim_id)
    if not recs:
        return {}
    return sorted(recs, key=lambda r: r.get("timestamp", ""), reverse=True)[0]


# ════════════════════════════════════════════════════════════════
# SESSION GUARD
# ════════════════════════════════════════════════════════════════

if not st.session_state.get("user_logged_in", False):
    st.error("❌ Please login first.")
    st.stop()

if st.session_state.get("user_role") != "officer":
    st.error("❌ Officer access only.")
    st.stop()

# ════════════════════════════════════════════════════════════════
# PAGE CONFIG
# ════════════════════════════════════════════════════════════════

st.set_page_config(
    page_title="Officer Dashboard — InsureAI",
    page_icon="👔",
    layout="wide",
)
st.markdown("""
<style>
[data-testid="stSidebarNav"],
[data-testid="stSidebarNavItems"],
[data-testid="stSidebarNavLink"],
[data-testid="stNavigation"],
section[data-testid="stSidebar"] nav,
section[data-testid="stSidebar"] > div:first-child ul { display:none !important; }
</style>
""", unsafe_allow_html=True)

# ════════════════════════════════════════════════════════════════
# CSS — CLEAN LIGHT THEME
# ════════════════════════════════════════════════════════════════

st.markdown("""
<style>

@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=DM+Mono:wght@400;500&family=Playfair+Display:wght@600;700&display=swap');

/* ── Base ── */
html, body { background: #F7F8FA !important; }
[data-testid="stAppViewContainer"],
[data-testid="stMain"], .main, .block-container,
section.main > div { background: #F7F8FA !important; }

html, body, * { font-family: 'DM Sans', sans-serif; color: #1C2333; }
.block-container { padding-top: 1.5rem !important; padding-bottom: 2rem !important; max-width: 1300px !important; }
div[data-testid="stVerticalBlock"] > div { margin-bottom: 0 !important; }
.element-container { margin-bottom: 0.3rem !important; }
[data-testid="column"] { padding: 0 8px !important; }
#MainMenu, footer, header, [data-testid="stDecoration"] { visibility: hidden !important; display: none !important; }

/* ── Sidebar ── */
[data-testid="stSidebar"],
[data-testid="stSidebar"] > div,
[data-testid="stSidebar"] section {
    background: #FFFFFF !important;
    border-right: 1px solid #E4E8F0 !important;
    box-shadow: 2px 0 16px rgba(28,35,51,0.06) !important;
}

[data-testid="stSidebar"] p,
[data-testid="stSidebar"] span,
[data-testid="stSidebar"] label,
[data-testid="stSidebar"] div { color: #1C2333 !important; }

[data-testid="stSidebar"] .stRadio > div > label {
    background: #F7F8FA !important;
    border: 1px solid #E4E8F0 !important;
    border-radius: 8px !important;
    padding: 8px 12px !important;
    margin: 2px 0 !important;
    transition: all 0.18s !important;
    display: block !important;
    color: #3D4A5C !important;
}

[data-testid="stSidebar"] .stRadio > div > label:hover {
    background: #EEF2FF !important;
    border-color: #6B7FD7 !important;
}

[data-testid="stSidebar"] hr { border-color: #E4E8F0 !important; margin: 10px 0 !important; }

/* ── Buttons ── */
.stButton > button {
    background: #FFFFFF !important;
    color: #3D4A5C !important;
    border: 1.5px solid #D1D8E4 !important;
    border-radius: 8px !important;
    padding: 9px 20px !important;
    font-family: 'DM Sans', sans-serif !important;
    font-weight: 500 !important;
    font-size: 13px !important;
    transition: all 0.18s ease !important;
    box-shadow: 0 1px 3px rgba(28,35,51,0.07) !important;
    margin-top: 4px !important;
}
.stButton > button:hover {
    background: #F0F3FF !important;
    border-color: #6B7FD7 !important;
    color: #3B4CC0 !important;
    transform: translateY(-1px) !important;
    box-shadow: 0 4px 12px rgba(107,127,215,0.18) !important;
}

/* ── Tabs ── */
.stTabs [data-baseweb="tab-list"] {
    background: #FFFFFF !important;
    border-radius: 10px !important;
    padding: 4px !important;
    border: 1px solid #E4E8F0 !important;
    gap: 2px !important;
    box-shadow: 0 1px 4px rgba(28,35,51,0.06) !important;
}
.stTabs [data-baseweb="tab"] {
    border-radius: 7px !important;
    font-family: 'DM Sans', sans-serif !important;
    font-weight: 500 !important;
    font-size: 13px !important;
    color: #6B7A90 !important;
    padding: 8px 18px !important;
    background: transparent !important;
}
.stTabs [aria-selected="true"] {
    background: #3B4CC0 !important;
    color: #FFFFFF !important;
    box-shadow: 0 2px 8px rgba(59,76,192,0.22) !important;
}

/* ── Textarea ── */
.stTextArea > div > div > textarea {
    background: #FFFFFF !important;
    border: 1.5px solid #D1D8E4 !important;
    border-radius: 8px !important;
    color: #1C2333 !important;
    font-family: 'DM Sans', sans-serif !important;
    font-size: 13px !important;
    caret-color: #3B4CC0 !important;
}
.stTextArea > div > div > textarea:focus {
    border-color: #6B7FD7 !important;
    box-shadow: 0 0 0 3px rgba(107,127,215,0.12) !important;
    outline: none !important;
}

/* ── Select box ── */
.stSelectbox > div > div {
    background: #FFFFFF !important;
    border: 1.5px solid #D1D8E4 !important;
    border-radius: 8px !important;
}

/* ── Text input ── */
.stTextInput > div > div > input {
    background: #FFFFFF !important;
    border: 1.5px solid #D1D8E4 !important;
    border-radius: 8px !important;
    color: #1C2333 !important;
    font-family: 'DM Sans', sans-serif !important;
}
.stTextInput > div > div > input:focus {
    border-color: #6B7FD7 !important;
    box-shadow: 0 0 0 3px rgba(107,127,215,0.12) !important;
}

/* ── Metrics — hide native Streamlit metric cards (replaced by custom HTML) ── */
[data-testid="stMetric"] { display: none !important; }

/* ── Animated Metric Cards ── */
@keyframes flowGlow {
    0%   { background-position: 200% center; }
    100% { background-position: -200% center; }
}
@keyframes breatheIcon {
    0%, 100% { transform: scale(1);   filter: drop-shadow(0 0 4px rgba(0,180,255,0.3)); }
    50%       { transform: scale(1.18); filter: drop-shadow(0 0 12px rgba(0,180,255,0.75)); }
}
@keyframes pulseRing {
    0%   { box-shadow: 0 0 0 0 rgba(59,76,192,0.35), 0 4px 20px rgba(59,76,192,0.12); }
    70%  { box-shadow: 0 0 0 10px rgba(59,76,192,0), 0 4px 20px rgba(59,76,192,0.12); }
    100% { box-shadow: 0 0 0 0 rgba(59,76,192,0), 0 4px 20px rgba(59,76,192,0.12); }
}
@keyframes electricBurst {
    0%   { transform: scale(1); }
    20%  { transform: scale(0.94); box-shadow: 0 0 0 0 rgba(0,212,255,0.6), 0 4px 20px rgba(59,76,192,0.2); }
    60%  { transform: scale(1.04); box-shadow: 0 0 0 18px rgba(0,212,255,0), 0 8px 32px rgba(59,76,192,0.35); }
    100% { transform: scale(1); }
}
@keyframes shimmer {
    0%   { left: -100%; }
    100% { left: 200%; }
}
@keyframes countUp {
    from { opacity: 0; transform: translateY(8px); }
    to   { opacity: 1; transform: translateY(0); }
}

.metric-grid {
    display: grid;
    grid-template-columns: repeat(6, 1fr);
    gap: 14px;
    margin-bottom: 8px;
}
.metric-card {
    position: relative;
    overflow: hidden;
    background: #FFFFFF;
    border: 1.5px solid rgba(59,76,192,0.14);
    border-radius: 16px;
    padding: 18px 18px 16px 18px;
    cursor: pointer;
    transition: transform 0.25s cubic-bezier(.34,1.56,.64,1),
                box-shadow 0.25s ease,
                border-color 0.25s ease;
    box-shadow: 0 2px 10px rgba(28,35,51,0.06);
    animation: pulseRing 3s ease infinite;
}
.metric-card:nth-child(1) { animation-delay: 0s; }
.metric-card:nth-child(2) { animation-delay: 0.4s; }
.metric-card:nth-child(3) { animation-delay: 0.8s; }
.metric-card:nth-child(4) { animation-delay: 1.2s; }
.metric-card:nth-child(5) { animation-delay: 1.6s; }
.metric-card:nth-child(6) { animation-delay: 2.0s; }

/* flowing glow top border */
.metric-card::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 3px;
    background: linear-gradient(90deg,
        transparent 0%,
        #3B4CC0 20%,
        #00D4FF 50%,
        #3B4CC0 80%,
        transparent 100%);
    background-size: 300% auto;
    animation: flowGlow 3s linear infinite;
    border-radius: 16px 16px 0 0;
}
.metric-card:nth-child(2)::before { animation-delay: -0.5s; }
.metric-card:nth-child(3)::before { animation-delay: -1.0s; }
.metric-card:nth-child(4)::before { animation-delay: -1.5s; }
.metric-card:nth-child(5)::before { animation-delay: -2.0s; }
.metric-card:nth-child(6)::before { animation-delay: -2.5s; }

/* shimmer sweep */
.metric-card::after {
    content: '';
    position: absolute;
    top: 0; left: -100%;
    width: 60%;
    height: 100%;
    background: linear-gradient(105deg,
        transparent 40%,
        rgba(255,255,255,0.55) 50%,
        transparent 60%);
    animation: shimmer 4s ease infinite;
    pointer-events: none;
}
.metric-card:nth-child(2)::after { animation-delay: -0.66s; }
.metric-card:nth-child(3)::after { animation-delay: -1.33s; }
.metric-card:nth-child(4)::after { animation-delay: -2.0s; }
.metric-card:nth-child(5)::after { animation-delay: -2.66s; }
.metric-card:nth-child(6)::after { animation-delay: -3.33s; }

.metric-card:hover {
    transform: translateY(-6px) scale(1.03);
    border-color: rgba(0,212,255,0.45);
    box-shadow:
        0 12px 32px rgba(59,76,192,0.18),
        0 0 0 3px rgba(0,212,255,0.15),
        inset 0 0 20px rgba(59,76,192,0.04);
}
.metric-card.clicked {
    animation: electricBurst 0.5s ease forwards;
}

.metric-icon {
    font-size: 20px;
    display: inline-block;
    animation: breatheIcon 2.8s ease-in-out infinite;
    margin-bottom: 8px;
}
.metric-card:nth-child(1) .metric-icon { animation-delay: 0s; }
.metric-card:nth-child(2) .metric-icon { animation-delay: 0.47s; }
.metric-card:nth-child(3) .metric-icon { animation-delay: 0.93s; }
.metric-card:nth-child(4) .metric-icon { animation-delay: 1.4s; }
.metric-card:nth-child(5) .metric-icon { animation-delay: 1.87s; }
.metric-card:nth-child(6) .metric-icon { animation-delay: 2.33s; }

.metric-label {
    font-family: 'DM Sans', sans-serif;
    font-size: 11px;
    font-weight: 600;
    color: #8896AB;
    letter-spacing: 0.6px;
    text-transform: uppercase;
    margin-bottom: 6px;
    display: block;
}
.metric-value {
    font-family: 'DM Mono', monospace;
    font-size: 30px;
    font-weight: 600;
    background: linear-gradient(135deg, #1C2333 0%, #3B4CC0 60%, #00B4D8 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    display: block;
    animation: countUp 0.6s ease both;
    line-height: 1.1;
}
.metric-card:nth-child(1) .metric-value { animation-delay: 0.1s; }
.metric-card:nth-child(2) .metric-value { animation-delay: 0.2s; }
.metric-card:nth-child(3) .metric-value { animation-delay: 0.3s; }
.metric-card:nth-child(4) .metric-value { animation-delay: 0.4s; }
.metric-card:nth-child(5) .metric-value { animation-delay: 0.5s; }
.metric-card:nth-child(6) .metric-value { animation-delay: 0.6s; }

/* ── Alerts ── */
.stSuccess { background: #F0FBF7 !important; border: 1px solid #A3DFC4 !important; border-radius: 8px !important; color: #1A6B4A !important; }
.stError   { background: #FFF5F5 !important; border: 1px solid #F5BCBC !important; border-radius: 8px !important; color: #8B1A1A !important; }
.stWarning { background: #FFFBF0 !important; border: 1px solid #F5DFA0 !important; border-radius: 8px !important; color: #7A5C00 !important; }
.stInfo    { background: #F0F4FF !important; border: 1px solid #BFC8F0 !important; border-radius: 8px !important; color: #2E3D8B !important; }

.stProgress > div > div > div { background: linear-gradient(90deg, #3B4CC0, #6B7FD7) !important; border-radius: 10px !important; }
hr { border: none !important; border-top: 1px solid #E4E8F0 !important; margin: 12px 0 !important; }
::-webkit-scrollbar { width: 5px; }
::-webkit-scrollbar-track { background: #F7F8FA; }
::-webkit-scrollbar-thumb { background: #C5CEDE; border-radius: 10px; }
::-webkit-scrollbar-thumb:hover { background: #9BA8BE; }
.streamlit-expanderHeader {
    background: #FFFFFF !important;
    border: 1px solid #E4E8F0 !important;
    border-radius: 8px !important;
    color: #3D4A5C !important;
    font-weight: 600 !important;
    font-size: 13px !important;
}

/* ── Claim card ── */
.claim-card {
    background: #FFFFFF;
    border: 1px solid #E4E8F0;
    border-radius: 14px;
    padding: 22px 26px;
    box-shadow: 0 2px 10px rgba(28,35,51,0.05);
    margin-bottom: 14px;
    transition: box-shadow 0.2s, transform 0.2s;
}
.claim-card:hover { box-shadow: 0 6px 24px rgba(28,35,51,0.09); }

/* ── Status badges ── */
.badge-pending  { background: #FFFBEC; border: 1px solid #F0D060; color: #7A5900; border-radius: 20px; padding: 3px 12px; font-size: 11px; font-weight: 600; font-family: 'DM Sans', sans-serif; letter-spacing: 0.3px; }
.badge-approved { background: #F0FBF7; border: 1px solid #72D4A8; color: #196B44; border-radius: 20px; padding: 3px 12px; font-size: 11px; font-weight: 600; font-family: 'DM Sans', sans-serif; letter-spacing: 0.3px; }
.badge-rejected { background: #FFF5F5; border: 1px solid #F5A0A0; color: #8B1A1A; border-radius: 20px; padding: 3px 12px; font-size: 11px; font-weight: 600; font-family: 'DM Sans', sans-serif; letter-spacing: 0.3px; }
.badge-review   { background: #F5F0FF; border: 1px solid #C0A8F0; color: #4B2DAA; border-radius: 20px; padding: 3px 12px; font-size: 11px; font-weight: 600; font-family: 'DM Sans', sans-serif; letter-spacing: 0.3px; }

/* ── Approve / Reject / Info button overrides ── */
button[kind="secondary"]:has(span:contains("Approve")),
div[data-testid*="approve"] .stButton > button {
    border-color: #72D4A8 !important;
    color: #196B44 !important;
}
div[data-testid*="reject"] .stButton > button {
    border-color: #F5A0A0 !important;
    color: #8B1A1A !important;
}

</style>
""", unsafe_allow_html=True)

# ════════════════════════════════════════════════════════════════
# PAGE HEADER
# ════════════════════════════════════════════════════════════════

st.markdown(
    "<h2 style='font-family: Playfair Display, Georgia, serif; font-size: 26px; font-weight: 700;"
    "color: #1C2333; letter-spacing: -0.3px; margin-bottom: 2px;'>Officer Dashboard</h2>",
    unsafe_allow_html=True,
)
st.markdown(
    "<p style='font-family: DM Sans, sans-serif; font-size: 13px; color: #8896AB;"
    "letter-spacing: 0.4px; margin: 0 0 4px 0;'>Review claims · AI analysis · Approve or reject</p>",
    unsafe_allow_html=True,
)
st.markdown(
    "<div style='width: 36px; height: 3px; background: #3B4CC0; border-radius: 10px; margin-bottom: 20px;'></div>",
    unsafe_allow_html=True,
)

# ════════════════════════════════════════════════════════════════
# DATA LOADING
# ════════════════════════════════════════════════════════════════

all_claims     = get_all_claims()
pending_simple = [c for c in all_claims if c["status"] == "Pending Review"]
approved       = [c for c in all_claims if c["status"] == "Approved"]
rejected       = [c for c in all_claims if c["status"] == "Rejected"]
more_info      = [c for c in all_claims if c["status"] == "More Info Needed"]

rag_pending = get_pending_claims_for_officer()

all_json_decisions   = load_decisions()
ai_approved_decs     = [d for d in all_json_decisions if d.get("action_AI", "").upper() == "APPROVED"]
ai_rejected_decs     = [d for d in all_json_decisions if d.get("action_AI", "").upper() == "REJECTED"]
officer_pending_decs = [d for d in all_json_decisions if d.get("action_officer", "").upper() == "PENDING"]
officer_done_decs    = [d for d in all_json_decisions if d.get("action_officer", "").upper() not in ("PENDING", "")]

seen_ids: set = set()
unique_json_decisions: list = []
for rec in sorted(all_json_decisions, key=lambda r: r.get("timestamp", ""), reverse=True):
    cid = rec.get("claim_id")
    if cid not in seen_ids:
        seen_ids.add(cid)
        unique_json_decisions.append(rec)

# ════════════════════════════════════════════════════════════════
# SUMMARY METRICS
# ════════════════════════════════════════════════════════════════

_metrics = [
    ("📋", "Total Claims",        len(all_claims)),
    ("⏳", "Pending Review",      len(pending_simple)),
    ("✅", "Approved",            len(approved)),
    ("❌", "Rejected",            len(rejected)),
]

_cards_html = "<div class='metric-grid'>"
for icon, label, val in _metrics:
    _cards_html += (
        f"<div class='metric-card' onclick=\"this.classList.remove('clicked');void this.offsetWidth;"
        f"this.classList.add('clicked');setTimeout(()=>this.classList.remove('clicked'),500)\">"
        f"<span class='metric-icon'>{icon}</span>"
        f"<span class='metric-label'>{label}</span>"
        f"<span class='metric-value'>{val}</span>"
        f"</div>"
    )
_cards_html += "</div>"

st.markdown(_cards_html, unsafe_allow_html=True)
st.divider()

# ════════════════════════════════════════════════════════════════
# TABS
# ════════════════════════════════════════════════════════════════

tab1, tab3, tab4 = st.tabs([
    "Pending Review",
    "AI Decisions (JSON)",
    "All Claims History",
])

# ════════════════════════════════════════════════════════════════
# HELPERS
# ════════════════════════════════════════════════════════════════

def badge(status: str) -> str:
    cls_map = {
        "Approved":               "badge-approved",
        "Rejected":               "badge-rejected",
        "Pending Review":         "badge-pending",
        "More Info Needed":       "badge-review",
        "Pending Officer Review": "badge-review",
    }
    cls = cls_map.get(status, "badge-pending")
    return f"<span class='{cls}'>{status}</span>"


def section_label(text: str):
    st.markdown(
        f"<p style='font-family: DM Sans, sans-serif; font-size: 11px; font-weight: 600;"
        f"color: #8896AB; letter-spacing: 1px; text-transform: uppercase; margin-bottom: 14px;'>"
        f"{text}</p>",
        unsafe_allow_html=True,
    )


def pill(label: str, color: str = "#3B4CC0", bg: str = "#EEF2FF") -> str:
    return (
        f"<span style='background:{bg};color:{color};border-radius:20px;"
        f"padding:2px 10px;font-size:11px;font-weight:600;font-family:DM Sans,sans-serif;'>{label}</span>"
    )


# ════════════════════════════════════════════════════════════════
# TAB 1 — SIMPLE PENDING CLAIMS
# ════════════════════════════════════════════════════════════════

with tab1:

    if not pending_simple:
        st.info("✅ No pending claims right now — all caught up!")
    else:
        section_label(f"{len(pending_simple)} claim(s) awaiting review")

        for claim in pending_simple:
            user   = get_user_by_id(claim["user_id"])
            policy = get_policy_by_id(claim["policy_id"])
            prev   = get_decision_by_claim(claim["claim_id"])

            ai_text        = prev.get("ai_suggestion", "") if prev else ""
            fraud_risk     = "HIGH" if "FRAUD RISK: HIGH" in ai_text else "LOW"
            verdict = reason = recommendation = docs_ratio = ""
            if ai_text:
                for part in ai_text.split(" | "):
                    if "VERDICT:"        in part: verdict        = part.replace("VERDICT:", "").strip()
                    if "REASON:"         in part: reason         = part.replace("REASON:", "").strip()
                    if "RECOMMENDATION:" in part: recommendation = part.replace("RECOMMENDATION:", "").strip()
                    if "DOCS:"           in part: docs_ratio     = part.replace("DOCS:", "").strip()

            st.markdown("<div class='claim-card'>", unsafe_allow_html=True)

            col_a, col_b = st.columns([3, 1])
            with col_a:
                st.markdown(
                    f"<div style='font-family: DM Mono, monospace; font-size: 13px;"
                    f"font-weight: 500; color: #3B4CC0; margin-bottom: 4px;'>{claim['claim_id']}</div>"
                    f"<div style='font-family: DM Sans, sans-serif; font-size: 12px; color: #8896AB;'>"
                    f"{user['name'] if user else claim['user_id']} &nbsp;·&nbsp; "
                    f"{policy['policy_type'] if policy else claim['policy_id']} &nbsp;·&nbsp; "
                    f"{claim['submission_date'][:10]}</div>",
                    unsafe_allow_html=True,
                )
            with col_b:
                st.markdown(
                    f"<div style='text-align:right; margin-top:4px;'>{badge(claim['status'])}</div>",
                    unsafe_allow_html=True,
                )

            st.markdown("<br>", unsafe_allow_html=True)

            # Claim description
            st.markdown(
                f"<div style='background: #F7F8FA; border: 1px solid #E4E8F0;"
                f"border-radius: 8px; padding: 12px 16px; margin-bottom: 12px;"
                f"font-family: DM Sans, sans-serif; font-size: 13px; color: #3D4A5C;'>"
                f"<strong style='color:#1C2333;'>Claim:</strong> {claim.get('claim_description', 'N/A')}</div>",
                unsafe_allow_html=True,
            )

            # Documents
            docs = claim.get("documents", [])
            if docs:
                doc_html = " ".join(
                    [f"<span style='background:#F0F3FF;border:1px solid #D0D8F5;border-radius:6px;"
                     f"padding:2px 9px;font-size:11px;color:#3B4CC0;font-family:DM Sans,sans-serif;'>📎 {d}</span>"
                     for d in docs]
                )
                st.markdown(f"<div style='margin-bottom:12px;'>{doc_html}</div>", unsafe_allow_html=True)

            # AI Analysis box
            if ai_text:
                risk_color  = "#8B1A1A" if fraud_risk == "HIGH" else "#196B44"
                risk_bg     = "#FFF5F5" if fraud_risk == "HIGH" else "#F0FBF7"
                risk_border = "#F5BCBC" if fraud_risk == "HIGH" else "#A3DFC4"
                risk_icon   = "⚠️" if fraud_risk == "HIGH" else "✓"

                st.markdown(
                    f"<div style='background:{risk_bg};border:1px solid {risk_border};"
                    f"border-radius:10px;padding:14px 18px;margin-bottom:12px;'>"
                    f"<div style='font-family:DM Sans,sans-serif;font-size:10px;font-weight:600;"
                    f"color:#8896AB;letter-spacing:1px;text-transform:uppercase;margin-bottom:8px;'>AI Analysis</div>"
                    f"<div style='display:flex;gap:20px;flex-wrap:wrap;'>"
                    f"<span style='font-family:DM Sans,sans-serif;font-size:12px;color:{risk_color};font-weight:600;'>"
                    f"{risk_icon} Fraud Risk: {fraud_risk}</span>"
                    f"<span style='font-family:DM Sans,sans-serif;font-size:12px;color:#3D4A5C;'>"
                    f"Verdict: {verdict}</span>"
                    f"<span style='font-family:DM Sans,sans-serif;font-size:12px;color:#3D4A5C;'>"
                    f"Docs: {docs_ratio}</span>"
                    f"</div>"
                    f"<div style='font-family:DM Sans,sans-serif;font-size:12px;color:#3D4A5C;margin-top:8px;'>"
                    f"<strong>Reason:</strong> {reason}</div>"
                    f"<div style='font-family:DM Sans,sans-serif;font-size:12px;color:#3B4CC0;margin-top:4px;font-weight:600;'>"
                    f"Recommendation: {recommendation}</div>"
                    f"</div>",
                    unsafe_allow_html=True,
                )

            # decisions.json linked record
            json_dec = get_latest_decision(claim["claim_id"])
            if json_dec:
                ai_action_val  = json_dec.get("action_AI", "N/A")
                off_action_val = json_dec.get("action_officer", "PENDING")
                fraud_verdict_j = json_dec.get("fraud_analysis", {}).get("verdict", "N/A")
                fraud_reason_j  = json_dec.get("fraud_analysis", {}).get("reason", "")
                doc_pct_j       = json_dec.get("document_validation", {}).get("completion_percentage", 0)
                ai_rec_j        = json_dec.get("recommendation", "")
                ts_j            = json_dec.get("timestamp", "")[:19].replace("T", " ")

                ai_col_color  = "#196B44" if ai_action_val == "APPROVED" else ("#8B1A1A" if ai_action_val == "REJECTED" else "#7A5900")
                off_col_color = "#196B44" if off_action_val == "APPROVED" else ("#8B1A1A" if off_action_val == "REJECTED" else "#7A5900")

                st.markdown(
                    f"<div style='background:#F5F3FF;border:1px solid #D5CCFF;"
                    f"border-radius:10px;padding:12px 18px;margin-bottom:12px;'>"
                    f"<div style='font-family:DM Sans,sans-serif;font-size:10px;font-weight:600;"
                    f"color:#6B50D0;letter-spacing:1px;text-transform:uppercase;margin-bottom:8px;'>"
                    f"Decisions.json — Linked Record &nbsp;"
                    f"<span style='font-size:10px;color:#9B8EC2;font-weight:400;'>{ts_j}</span></div>"
                    f"<div style='display:flex;gap:16px;flex-wrap:wrap;align-items:center;'>"
                    f"<span style='font-family:DM Sans,sans-serif;font-size:12px;'>"
                    f"AI Action: <strong style='color:{ai_col_color};'>{ai_action_val}</strong></span>"
                    f"<span style='font-family:DM Sans,sans-serif;font-size:12px;'>"
                    f"Officer Action: <strong style='color:{off_col_color};'>{off_action_val}</strong></span>"
                    f"<span style='font-family:DM Sans,sans-serif;font-size:12px;color:#3D4A5C;'>"
                    f"Fraud: <strong>{fraud_verdict_j}</strong></span>"
                    f"<span style='font-family:DM Sans,sans-serif;font-size:12px;color:#3D4A5C;'>"
                    f"Docs: <strong>{doc_pct_j:.0f}%</strong></span>"
                    f"</div>"
                    f"<div style='font-family:DM Sans,sans-serif;font-size:11px;color:#6B7A90;margin-top:6px;'>{fraud_reason_j}</div>"
                    f"<div style='font-family:DM Sans,sans-serif;font-size:11px;color:#3B4CC0;margin-top:4px;font-weight:600;'>{ai_rec_j}</div>"
                    f"</div>",
                    unsafe_allow_html=True,
                )

            officer_comment = st.text_area(
                "Officer Comments (optional):",
                placeholder="Add your notes or reason for decision...",
                key=f"comment_{claim['claim_id']}",
                height=70,
            )

            btn1, btn2, btn3 = st.columns(3)

            with btn1:
                if st.button("✅  Approve", key=f"approve_{claim['claim_id']}", use_container_width=True):
                    save_decision(
                        claim_id      = claim["claim_id"],
                        officer_id    = st.session_state.user_id,
                        decision      = "Approved",
                        comments      = officer_comment or "Approved by officer",
                        ai_suggestion = ai_text,
                    )
                    save_officer_action_to_decisions(
                        claim_id       = claim["claim_id"],
                        officer_id     = st.session_state.user_id,
                        officer_action = "APPROVED",
                        comments       = officer_comment or "Approved by officer",
                    )
                    st.success(f"✅ Claim {claim['claim_id']} approved.")
                    st.rerun()

            with btn2:
                if st.button("❌  Reject", key=f"reject_{claim['claim_id']}", use_container_width=True):
                    save_decision(
                        claim_id      = claim["claim_id"],
                        officer_id    = st.session_state.user_id,
                        decision      = "Rejected",
                        comments      = officer_comment or "Rejected by officer",
                        ai_suggestion = ai_text,
                    )
                    save_officer_action_to_decisions(
                        claim_id       = claim["claim_id"],
                        officer_id     = st.session_state.user_id,
                        officer_action = "REJECTED",
                        comments       = officer_comment or "Rejected by officer",
                    )
                    st.error(f"❌ Claim {claim['claim_id']} rejected.")
                    st.rerun()

            with btn3:
                if st.button("📄  Request More Info", key=f"info_{claim['claim_id']}", use_container_width=True):
                    update_claim_status(claim["claim_id"], "More Info Needed")
                    save_officer_action_to_decisions(
                        claim_id       = claim["claim_id"],
                        officer_id     = st.session_state.user_id,
                        officer_action = "MORE_INFO",
                        comments       = officer_comment or "More information required",
                    )
                    st.warning(f"📄 More info requested for {claim['claim_id']}")
                    st.rerun()

            st.markdown("</div><br>", unsafe_allow_html=True)







# ════════════════════════════════════════════════════════════════
# TAB 3 — AI DECISIONS (decisions.json) + OFFICER OVERRIDE
# ════════════════════════════════════════════════════════════════

with tab3:

    _live_path   = _resolve_decisions_file()
    _path_exists = _live_path.exists()
    _rec_count   = len(all_json_decisions)
    _path_color  = "#196B44" if _path_exists else "#8B1A1A"
    _path_icon   = "✓" if _path_exists else "✕"

    st.markdown(
        f"<div style='background:#F7F8FA;border:1px solid #E4E8F0;"
        f"border-radius:8px;padding:8px 14px;margin-bottom:12px;"
        f"font-family:DM Mono,monospace;font-size:11px;color:#3D4A5C;'>"
        f"decisions.json → "
        f"<span style='color:{_path_color};'>{_live_path}</span> "
        f"&nbsp;{_path_icon} {'Found' if _path_exists else 'NOT FOUND'} "
        f"&nbsp;·&nbsp; {_rec_count} record(s)"
        f"</div>",
        unsafe_allow_html=True,
    )

    if not unique_json_decisions:
        st.warning(
            f"📂 No records found in decisions.json.\n\n"
            f"**Expected location:** `{_live_path}`\n\n"
            f"Make sure `decisions.json` exists in your project root or pages folder, "
            f"then click **Refresh** in the sidebar."
        )
        if _path_exists:
            with st.expander("Raw decisions.json content (debug)"):
                try:
                    st.code(open(_live_path, encoding="utf-8").read(), language="json")
                except Exception as e:
                    st.error(f"Could not read file: {e}")
    else:
        sc1, sc2, sc3, sc4 = st.columns(4)
        sc1.metric("Total JSON Records",  len(all_json_decisions))
        sc2.metric("AI Approved",         len(ai_approved_decs))
        sc3.metric("Officer Pending",     len(officer_pending_decs))
        sc4.metric("Officer Actioned",    len(officer_done_decs))

        st.divider()
        section_label(f"{len(unique_json_decisions)} unique claim(s) in decisions.json")

        for rec in unique_json_decisions:
            cid            = rec.get("claim_id", "N/A")
            ins_type       = rec.get("insurance_type", "N/A").replace("_", " ").title()
            ai_action      = rec.get("action_AI", "N/A")
            off_action     = rec.get("action_officer", "PENDING")
            final_dec      = rec.get("final_decision", "N/A")
            recommendation = rec.get("recommendation", "")
            timestamp      = rec.get("timestamp", "")[:19].replace("T", " ")

            fraud          = rec.get("fraud_analysis", {})
            doc_val        = rec.get("document_validation", {})
            summary_rec    = rec.get("summary", {})

            fraud_verdict  = fraud.get("verdict", "N/A")
            fraud_reason   = fraud.get("reason", "")
            fraud_action_s = fraud.get("action", "")
            is_fraud       = fraud.get("is_fraud", False)
            doc_pct        = doc_val.get("completion_percentage", 0)
            uploaded       = doc_val.get("uploaded_count", 0)
            required_j     = doc_val.get("required_count", 0)
            missing_docs   = doc_val.get("missing_documents", [])
            fraud_risk_lvl = summary_rec.get("fraud_risk_level", "LOW")

            ai_clr   = "#196B44" if ai_action == "APPROVED" else ("#8B1A1A" if ai_action == "REJECTED" else "#7A5900")
            off_clr  = "#196B44" if off_action == "APPROVED" else ("#8B1A1A" if off_action == "REJECTED" else "#7A5900")
            risk_clr = "#8B1A1A" if (fraud_risk_lvl == "HIGH" or is_fraud) else "#196B44"
            risk_bg  = "#FFF5F5" if (fraud_risk_lvl == "HIGH" or is_fraud) else "#F0FBF7"
            risk_brd = "#F5BCBC" if (fraud_risk_lvl == "HIGH" or is_fraud) else "#A3DFC4"
            doc_clr  = "#196B44" if doc_pct == 100 else "#7A5900"
            already_actioned = off_action not in ("PENDING", "")

            st.markdown("<div class='claim-card'>", unsafe_allow_html=True)

            h1, h2 = st.columns([3, 1])
            with h1:
                st.markdown(
                    f"<div style='font-family:DM Mono,monospace;font-size:13px;"
                    f"font-weight:500;color:#3B4CC0;margin-bottom:4px;'>{cid}</div>"
                    f"<div style='font-family:DM Sans,sans-serif;font-size:12px;color:#8896AB;'>"
                    f"{ins_type} &nbsp;·&nbsp; {timestamp}</div>",
                    unsafe_allow_html=True,
                )
            with h2:
                badge_color = "#196B44" if final_dec == "APPROVED" else ("#8B1A1A" if final_dec == "REJECTED" else "#7A5900")
                badge_bg    = "#F0FBF7" if final_dec == "APPROVED" else ("#FFF5F5" if final_dec == "REJECTED" else "#FFFBEC")
                badge_brd   = "#A3DFC4" if final_dec == "APPROVED" else ("#F5BCBC" if final_dec == "REJECTED" else "#F0D060")
                st.markdown(
                    f"<div style='text-align:right;margin-top:4px;'>"
                    f"<span style='background:{badge_bg};border:1px solid {badge_brd};"
                    f"border-radius:20px;padding:3px 12px;font-size:11px;font-weight:600;"
                    f"color:{badge_color};font-family:DM Sans,sans-serif;'>{final_dec}</span></div>",
                    unsafe_allow_html=True,
                )

            st.markdown("<br>", unsafe_allow_html=True)

            aa_col, oa_col = st.columns(2)
            with aa_col:
                st.markdown(
                    f"<div style='background:#F7F8FA;border:1px solid #E4E8F0;"
                    f"border-radius:10px;padding:14px 18px;'>"
                    f"<div style='font-family:DM Sans,sans-serif;font-size:10px;font-weight:600;"
                    f"color:#8896AB;letter-spacing:1px;text-transform:uppercase;margin-bottom:8px;'>AI Action</div>"
                    f"<div style='font-family:DM Mono,monospace;font-size:22px;font-weight:600;"
                    f"color:{ai_clr};'>{ai_action}</div>"
                    f"<div style='font-family:DM Sans,sans-serif;font-size:11px;color:#8896AB;"
                    f"margin-top:6px;'>{recommendation}</div>"
                    f"</div>",
                    unsafe_allow_html=True,
                )
            with oa_col:
                off_icon = "✅" if off_action == "APPROVED" else ("❌" if off_action == "REJECTED" else "⏳")
                st.markdown(
                    f"<div style='background:#F7F8FA;border:1px solid #E4E8F0;"
                    f"border-radius:10px;padding:14px 18px;'>"
                    f"<div style='font-family:DM Sans,sans-serif;font-size:10px;font-weight:600;"
                    f"color:#8896AB;letter-spacing:1px;text-transform:uppercase;margin-bottom:8px;'>Officer Action</div>"
                    f"<div style='font-family:DM Mono,monospace;font-size:22px;font-weight:600;"
                    f"color:{off_clr};'>{off_icon} {off_action}</div>"
                    f"<div style='font-family:DM Sans,sans-serif;font-size:11px;color:#8896AB;"
                    f"margin-top:6px;'>{'Action recorded' if already_actioned else 'Awaiting officer decision'}</div>"
                    f"</div>",
                    unsafe_allow_html=True,
                )

            st.markdown("<br>", unsafe_allow_html=True)

            fd_col, dv_col = st.columns(2)
            with fd_col:
                st.markdown(
                    f"<div style='background:{risk_bg};border:1px solid {risk_brd};"
                    f"border-radius:10px;padding:14px 18px;height:100%;'>"
                    f"<div style='font-family:DM Sans,sans-serif;font-size:10px;font-weight:600;"
                    f"color:#8896AB;letter-spacing:1px;text-transform:uppercase;margin-bottom:8px;'>Fraud Analysis</div>"
                    f"<div style='font-family:DM Sans,sans-serif;font-size:13px;font-weight:700;"
                    f"color:{risk_clr};margin-bottom:4px;'>{'⚠️' if is_fraud else '✓'} {fraud_verdict}</div>"
                    f"<div style='font-family:DM Sans,sans-serif;font-size:11px;color:#3D4A5C;'>{fraud_reason}</div>"
                    f"<div style='font-family:DM Sans,sans-serif;font-size:11px;color:#3B4CC0;"
                    f"font-weight:600;margin-top:6px;'>Suggested: {fraud_action_s}</div>"
                    f"</div>",
                    unsafe_allow_html=True,
                )
            with dv_col:
                missing_html_j = " ".join(
                    [f"<span style='background:#FFF5F5;border:1px solid #F5BCBC;border-radius:6px;"
                     f"padding:2px 7px;font-size:11px;color:#8B1A1A;font-family:DM Sans,sans-serif;'>✕ {d}</span>"
                     for d in missing_docs]
                ) or "<span style='color:#196B44;font-size:11px;font-family:DM Sans,sans-serif;'>All documents present ✓</span>"
                st.markdown(
                    f"<div style='background:#F7F8FA;border:1px solid #E4E8F0;"
                    f"border-radius:10px;padding:14px 18px;height:100%;'>"
                    f"<div style='font-family:DM Sans,sans-serif;font-size:10px;font-weight:600;"
                    f"color:#8896AB;letter-spacing:1px;text-transform:uppercase;margin-bottom:8px;'>Document Validation</div>"
                    f"<div style='font-family:DM Mono,monospace;font-size:13px;font-weight:600;"
                    f"color:{doc_clr};margin-bottom:4px;'>{doc_pct:.0f}% ({uploaded}/{required_j})</div>"
                    f"<div>{missing_html_j}</div>"
                    f"</div>",
                    unsafe_allow_html=True,
                )

            st.markdown("<br>", unsafe_allow_html=True)
            if required_j > 0:
                st.progress(int(doc_pct))

            if not already_actioned:
                st.markdown(
                    "<div style='background:#FFFBEC;border:1px solid #F0D060;"
                    "border-radius:8px;padding:10px 14px;margin:10px 0;font-family:DM Sans,sans-serif;"
                    "font-size:12px;color:#7A5900;'>Officer action is <strong>pending</strong> — "
                    "please review and take action below.</div>",
                    unsafe_allow_html=True,
                )
                ov_comment = st.text_area(
                    "Officer Comments:",
                    placeholder="Add notes or reason for your decision...",
                    key=f"json_comment_{cid}",
                    height=68,
                )
                ov1, ov2, ov3 = st.columns(3)
                with ov1:
                    if st.button("✅ Approve", key=f"json_approve_{cid}", use_container_width=True):
                        save_officer_action_to_decisions(cid, st.session_state.user_id, "APPROVED", ov_comment or "Approved by officer")
                        save_decision(cid, st.session_state.user_id, "Approved", ov_comment or "Approved by officer")
                        update_claim_status(cid, "Approved")
                        st.success(f"✅ {cid} approved.")
                        st.rerun()
                with ov2:
                    if st.button("❌ Reject", key=f"json_reject_{cid}", use_container_width=True):
                        save_officer_action_to_decisions(cid, st.session_state.user_id, "REJECTED", ov_comment or "Rejected by officer")
                        save_decision(cid, st.session_state.user_id, "Rejected", ov_comment or "Rejected by officer")
                        update_claim_status(cid, "Rejected")
                        st.error(f"❌ {cid} rejected.")
                        st.rerun()
                with ov3:
                    if st.button("📄 More Info", key=f"json_info_{cid}", use_container_width=True):
                        save_officer_action_to_decisions(cid, st.session_state.user_id, "MORE_INFO", ov_comment or "More information required")
                        update_claim_status(cid, "More Info Needed")
                        st.warning(f"📄 More info requested for {cid}")
                        st.rerun()
            else:
                st.markdown(
                    f"<div style='background:#F0FBF7;border:1px solid #A3DFC4;"
                    f"border-radius:8px;padding:10px 14px;margin:8px 0;font-family:DM Sans,sans-serif;"
                    f"font-size:12px;color:#196B44;'>Officer has already actioned this claim: "
                    f"<strong>{off_action}</strong></div>",
                    unsafe_allow_html=True,
                )

            st.markdown("</div><br>", unsafe_allow_html=True)


# ════════════════════════════════════════════════════════════════
# TAB 4 — ALL CLAIMS HISTORY
# ════════════════════════════════════════════════════════════════

with tab4:

    if not all_claims:
        st.info("No claims submitted yet.")
    else:
        filter_col1, filter_col2 = st.columns([2, 2])
        with filter_col1:
            status_filter = st.selectbox(
                "Filter by Status",
                ["All", "Pending Review", "Approved", "Rejected", "More Info Needed"],
                key="history_filter",
            )
        with filter_col2:
            search_query = st.text_input(
                "Search by Claim ID or User",
                placeholder="e.g. CLM1234 or Raj Kumar",
                key="history_search",
            )

        filtered = list(reversed(all_claims))
        if status_filter != "All":
            filtered = [c for c in filtered if c.get("status") == status_filter]
        if search_query:
            q = search_query.lower()
            filtered = [
                c for c in filtered
                if q in c.get("claim_id", "").lower()
                or q in (get_user_by_id(c["user_id"]) or {}).get("name", "").lower()
            ]

        section_label(f"Showing {len(filtered)} of {len(all_claims)} claims")

        for claim in filtered:
            user   = get_user_by_id(claim["user_id"])
            policy = get_policy_by_id(claim["policy_id"])
            dec    = get_decision_by_claim(claim["claim_id"])
            status = claim.get("status", "Pending Review")

            with st.expander(
                f"{claim['claim_id']}  ·  {user['name'] if user else claim['user_id']}  ·  {status}"
            ):
                col1, col2 = st.columns(2)

                with col1:
                    st.markdown(f"**Customer:** {user['name'] if user else claim['user_id']}")
                    st.markdown(f"**Email:** {user['email'] if user else 'N/A'}")
                    st.markdown(f"**Policy:** {policy['policy_type'] if policy else claim['policy_id']}")
                    if policy:
                        st.markdown(f"**Coverage:** ₹{policy.get('coverage_amount', 'N/A'):,}")
                    st.markdown(f"**Submitted:** {claim.get('submission_date', 'N/A')[:10]}")
                    st.markdown(f"**Status:** {badge(status)}", unsafe_allow_html=True)

                with col2:
                    if dec:
                        st.markdown(f"**Officer ID:** {dec.get('officer_id', 'N/A')}")
                        date_str = dec.get("decision_date") or dec.get("officer_decision_date") or "N/A"
                        st.markdown(f"**Decision Date:** {date_str[:10] if date_str != 'N/A' else 'N/A'}")
                        comments = dec.get("comments") or dec.get("officer_comments") or "N/A"
                        st.markdown(f"**Comments:** {comments}")
                    else:
                        st.markdown("*No officer decision recorded yet.*")

                st.markdown(
                    f"<div style='background:#F7F8FA;border:1px solid #E4E8F0;"
                    f"border-radius:8px;padding:10px 14px;margin-top:10px;"
                    f"font-family:DM Sans,sans-serif;font-size:13px;color:#3D4A5C;'>"
                    f"{claim.get('claim_description', 'N/A')}</div>",
                    unsafe_allow_html=True,
                )

                docs = claim.get("documents", [])
                if docs:
                    doc_html = " ".join(
                        [f"<span style='background:#F0F3FF;border:1px solid #D0D8F5;border-radius:6px;"
                         f"padding:2px 9px;font-size:11px;color:#3B4CC0;font-family:DM Sans,sans-serif;'>📎 {d}</span>"
                         for d in docs]
                    )
                    st.markdown(f"<div style='margin-top:8px;'>{doc_html}</div>", unsafe_allow_html=True)

                if dec:
                    ai_text = dec.get("ai_suggestion") or ""
                    if ai_text:
                        st.markdown(
                            f"<div style='background:#F7F8FA;border:1px solid #E4E8F0;"
                            f"border-radius:8px;padding:10px 14px;margin-top:8px;"
                            f"font-family:DM Sans,sans-serif;font-size:12px;color:#6B7A90;'>"
                            f"<strong style='color:#3D4A5C;'>AI Summary:</strong> {ai_text}</div>",
                            unsafe_allow_html=True,
                        )

                if status in ("Pending Review", "More Info Needed"):
                    st.markdown("<br>", unsafe_allow_html=True)
                    ov_col1, ov_col2, ov_col3 = st.columns(3)
                    with ov_col1:
                        if st.button("✅ Quick Approve", key=f"hist_approve_{claim['claim_id']}", use_container_width=True):
                            save_decision(claim["claim_id"], st.session_state.user_id, "Approved", "Approved via history view")
                            st.success("Approved!")
                            st.rerun()
                    with ov_col2:
                        if st.button("❌ Quick Reject", key=f"hist_reject_{claim['claim_id']}", use_container_width=True):
                            save_decision(claim["claim_id"], st.session_state.user_id, "Rejected", "Rejected via history view")
                            st.error("Rejected!")
                            st.rerun()
                    with ov_col3:
                        if st.button("📄 More Info", key=f"hist_info_{claim['claim_id']}", use_container_width=True):
                            update_claim_status(claim["claim_id"], "More Info Needed")
                            st.warning("More info requested!")
                            st.rerun()


# ════════════════════════════════════════════════════════════════
# SIDEBAR
# ════════════════════════════════════════════════════════════════

with st.sidebar:
    st.markdown(
        "<div style='text-align:center;padding:16px 0 8px 0;'>"
        "<div style='font-family:Playfair Display,Georgia,serif;font-size:18px;font-weight:700;"
        "color:#1C2333;letter-spacing:-0.3px;'>InsureAI</div>"
        "<div style='font-family:DM Sans,sans-serif;font-size:10px;"
        "color:#8896AB;letter-spacing:2px;margin-top:2px;text-transform:uppercase;'>"
        "Officer Panel</div></div>",
        unsafe_allow_html=True,
    )
    st.divider()

    st.markdown(
        f"<div style='background:#F0F4FF;border:1px solid #BFC8F0;"
        f"border-radius:10px;padding:14px 16px;margin-bottom:14px;'>"
        f"<div style='font-family:DM Sans,sans-serif;font-size:10px;font-weight:600;"
        f"color:#3B4CC0;letter-spacing:1px;text-transform:uppercase;margin-bottom:6px;'>Logged in as</div>"
        f"<div style='font-family:DM Sans,sans-serif;font-size:14px;"
        f"font-weight:600;color:#1C2333;'>{st.session_state.user_name}</div>"
        f"<div style='font-family:DM Sans,sans-serif;font-size:11px;"
        f"color:#8896AB;margin-top:3px;'>Officer</div></div>",
        unsafe_allow_html=True,
    )

    st.divider()

    st.markdown(
        "<p style='font-family:DM Sans,sans-serif;font-size:10px;font-weight:600;"
        "color:#8896AB;letter-spacing:1.5px;text-transform:uppercase;margin-bottom:10px;'>Quick Stats</p>",
        unsafe_allow_html=True,
    )

    for label, count, color in [
        ("Pending",    len(pending_simple), "#C49A00"),
        ("AI Queue",   len(rag_pending),    "#6B50D0"),
        ("Approved",   len(approved),        "#196B44"),
        ("Rejected",   len(rejected),        "#8B1A1A"),
        ("More Info",  len(more_info),       "#2E5B8B"),
    ]:
        st.markdown(
            f"<div style='display:flex;justify-content:space-between;align-items:center;"
            f"font-family:DM Sans,sans-serif;font-size:12px;color:#3D4A5C;"
            f"padding:5px 0;border-bottom:1px solid #F0F2F5;'>"
            f"<span>{label}</span>"
            f"<span style='font-family:DM Mono,monospace;font-weight:600;color:{color};font-size:13px;'>"
            f"{count}</span></div>",
            unsafe_allow_html=True,
        )

    st.divider()

    if st.button("🔄  Refresh", use_container_width=True):
        st.rerun()

    st.markdown(
        "<div style='text-align:center;margin-top:16px;'>"
        "<span style='font-family:DM Sans,sans-serif;font-size:10px;"
        "color:#C5CEDE;letter-spacing:1px;'>Powered by AI · v1.0</span></div>",
        unsafe_allow_html=True,
    )
