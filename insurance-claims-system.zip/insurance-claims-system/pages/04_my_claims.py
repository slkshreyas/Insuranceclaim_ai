import streamlit as st
import json
import os
import re
import random
from datetime import datetime

# ─────────────────────────────────────────
# Page Config — MUST BE FIRST
# ─────────────────────────────────────────
st.set_page_config(page_title="My Claims · InsureAI", page_icon="🛡️", layout="wide")

# ─────────────────────────────────────────
# Auth Guard
# ─────────────────────────────────────────
if not st.session_state.get("user_logged_in"):
    st.switch_page("app.py")
    st.stop()

# ─────────────────────────────────────────
# Rejection Reasons Bank
# ─────────────────────────────────────────
REJECTION_REASONS = {
    "health": [
        "The submitted medical documents do not meet the minimum eligibility criteria under your policy.",
        "The treatment is categorised as a pre-existing condition exclusion under clause 4.2.",
        "Insufficient diagnostic reports were provided to validate the claimed amount.",
        "The hospitalisation duration did not meet the minimum 24-hour requirement for inpatient claims.",
        "The treating hospital is not on our approved network provider list.",
    ],
    "vehicle": [
        "The accident was reported beyond the 48-hour mandatory intimation window.",
        "The driver did not hold a valid licence at the time of the incident.",
        "The damage pattern is inconsistent with the reported cause of loss.",
        "The vehicle was being used for commercial purposes under a private-use policy.",
        "Third-party verification of the incident could not be completed.",
    ],
    "life": [
        "The claim was filed within the two-year contestability period.",
        "Material health information was not disclosed at policy inception.",
        "The cause of death falls under an excluded category per policy schedule 7.",
        "Nominee verification documents are incomplete or mismatched.",
        "The policy had lapsed due to non-payment of premium at the time of the event.",
    ],
    "property": [
        "The damage is attributed to wear and tear, which is explicitly excluded.",
        "No independent surveyor report was submitted within the stipulated timeframe.",
        "The declared property value was found to be under-insured by more than 20%.",
        "The incident falls under a clause requiring an additional endorsement not held.",
        "Supporting photographs and repair estimates were not provided.",
    ],
    "default": [
        "The claim does not satisfy the policy's standard eligibility conditions.",
        "Required supporting documents were missing or incomplete at the time of review.",
        "The claimed amount exceeds the sum insured limit for this policy year.",
        "The incident date falls outside the active coverage period of the policy.",
        "The claim was found to be a duplicate submission already processed under a different reference.",
    ],
}

def get_rejection_reason(claim: dict) -> str:
    existing = (
        claim.get("reason") or claim.get("rejection_reason") or
        claim.get("remarks") or claim.get("decision") or ""
    ).strip()
    if existing:
        return existing
    desc = str(claim.get("claim_description", "")).lower()
    if any(k in desc for k in ("hospital","medical","health","chest","cardiac","surgery","dental","icu","ccu","treatment")):
        return random.choice(REJECTION_REASONS["health"])
    elif any(k in desc for k in ("vehicle","car","accident","motor","bike","auto","collision","crash")):
        return random.choice(REJECTION_REASONS["vehicle"])
    elif any(k in desc for k in ("life","death","term","endowment","nominee","deceased")):
        return random.choice(REJECTION_REASONS["life"])
    elif any(k in desc for k in ("property","home","house","fire","flood","damage","building")):
        return random.choice(REJECTION_REASONS["property"])
    return random.choice(REJECTION_REASONS["default"])

# ─────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────
def detect_claim_type(claim: dict) -> str:
    desc = str(claim.get("claim_description", "")).lower()
    if any(k in desc for k in ("hospital","medical","health","chest","cardiac","surgery","dental","icu","ccu")):
        return "Health Insurance"
    elif any(k in desc for k in ("vehicle","car","accident","motor","bike","auto","collision")):
        return "Vehicle Insurance"
    elif any(k in desc for k in ("life","death","term","endowment","nominee")):
        return "Life Insurance"
    elif any(k in desc for k in ("property","home","house","fire","flood","damage")):
        return "Property Insurance"
    return "General Insurance"

def extract_amount(claim: dict) -> str:
    amt = claim.get("claim_amount") or claim.get("amount")
    if amt:
        try: return f"₹{float(str(amt).replace(',','').replace('₹','')):,.2f}"
        except: return str(amt)
    desc = claim.get("claim_description", "")
    match = re.search(r"(?:₹|Rs\.?)\s*([\d,]+(?:\.\d{1,2})?)", desc)
    if not match:
        match = re.search(r"([\d,]{4,}(?:\.\d{1,2})?)\s*(?:\(within|claim amount)", desc, re.IGNORECASE)
    if match:
        try: return f"₹{float(match.group(1).replace(',','')):,.2f}"
        except: pass
    return "—"

def fmt_date(raw):
    if not raw: return "—"
    for f in ("%Y-%m-%d %H:%M:%S","%Y-%m-%dT%H:%M:%S","%Y-%m-%d","%d-%m-%Y","%Y/%m/%d","%d/%m/%Y"):
        try: return datetime.strptime(str(raw).strip(), f).strftime("%d %b %Y")
        except: pass
    return str(raw)

def normalise_status(raw: str) -> str:
    """Always returns one of: approved | rejected | pending"""
    s = raw.lower().strip()
    if any(k in s for k in ("approv","success","settled","paid")):
        return "approved"
    if any(k in s for k in ("reject","denied","declin","refused")):
        return "rejected"
    return "pending"

# ─────────────────────────────────────────
# Load claims from data/claims.json
# ─────────────────────────────────────────
CLAIM_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "claims.json")

def load_claims() -> list:
    """
    Smart loader — tries to match claims against every identifier
    stored in session_state: user_id, username, email, phone.
    Falls back to showing ALL claims if nothing matches (safe for dev).
    """
    if not os.path.exists(CLAIM_PATH):
        st.warning(f"⚠️ File not found: `{os.path.abspath(CLAIM_PATH)}`")
        return []
    try:
        with open(CLAIM_PATH, "r") as f:
            data = json.load(f)
        if not isinstance(data, list):
            return []

        # Collect ALL identifiers stored at login
        identifiers = set()
        for key in ("user_id", "username", "email", "phone", "mobile", "userid"):
            val = st.session_state.get(key)
            if val:
                identifiers.add(str(val).lower().strip())

        if not identifiers:
            # Nothing in session to match against — show all (dev fallback)
            return data

        # Match claim if ANY of its identity fields matches ANY session identifier
        matched = []
        for c in data:
            claim_ids = {
                str(c.get("user_id",  "")).lower().strip(),
                str(c.get("username", "")).lower().strip(),
                str(c.get("email",    "")).lower().strip(),
                str(c.get("phone",    "")).lower().strip(),
            }
            if identifiers & claim_ids:   # intersection — any match is enough
                matched.append(c)

        return matched

    except json.JSONDecodeError as e:
        st.error(f"❌ Could not parse claims.json: {e}")
        return []
    except Exception as e:
        st.error(f"❌ Error loading claims: {e}")
        return []

# ─────────────────────────────────────────
# Status config — exactly 3 states
# ─────────────────────────────────────────
STATUS_CFG = {
    "approved": {"color":"#00c48c","rgb":"0,196,140",  "icon":"✅","label":"Approved",       "c2":"#00f2aa"},
    "pending":  {"color":"#f5a623","rgb":"245,166,35", "icon":"⏳","label":"Pending Review", "c2":"#ffd580"},
    "rejected": {"color":"#ff4d6d","rgb":"255,77,109", "icon":"❌","label":"Rejected",        "c2":"#ff8fa3"},
}

# ─────────────────────────────────────────
# CSS
# ─────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&family=DM+Sans:wght@300;400;500;600&display=swap');
:root{
    --blue-deep:#0a1f5c;--blue-mid:#1a6bff;--blue-light:#5b9bff;
    --surface:rgba(255,255,255,0.88);--border:rgba(26,107,255,0.15);
    --text-dark:#0d1b3e;--text-muted:#5c6e9a;
}
html,body,[data-testid="stAppViewContainer"],[data-testid="stMain"]{
    font-family:'DM Sans',sans-serif !important;background:transparent !important;
}
[data-testid="stAppViewContainer"]{
    background:
        radial-gradient(ellipse 80% 55% at 50% -10%,rgba(26,107,255,0.14) 0%,transparent 70%),
        radial-gradient(ellipse 55% 40% at 100% 85%,rgba(91,155,255,0.10) 0%,transparent 65%),
        linear-gradient(165deg,#f2f6ff 0%,#ffffff 55%,#eef4ff 100%) !important;
    min-height:100vh;
}
#MainMenu,footer,header,[data-testid="stDecoration"],[data-testid="stStatusWidget"]{visibility:hidden !important;}
[data-testid="stSidebar"]{
    background:linear-gradient(180deg,#060e20 0%,#0a1840 100%) !important;
    border-right:1px solid rgba(26,107,255,0.22) !important;
}
[data-testid="stSidebar"] *{color:#a8c0e8 !important;}

/* ── Hide "customer home" from the sidebar navigation ── */
[data-testid="stSidebarNav"] a[href*="customer_home"],
[data-testid="stSidebarNav"] li:has(a[href*="customer_home"]),
[data-testid="stSidebarNavItems"] a[href*="customer_home"],
[data-testid="stSidebarNavItems"] li:has(a[href*="customer_home"]),
section[data-testid="stSidebar"] nav ul li:has(a[href*="customer_home"]),
section[data-testid="stSidebar"] ul li:has(span:contains("customer home")) {
    display: none !important;
}
/* Streamlit ≥1.36 uses data-testid="stSidebarNavLink" */
[data-testid="stSidebarNavLink"][href*="customer_home"] {
    display: none !important;
}
.logo-badge{
    width:48px;height:48px;border-radius:14px;
    background:linear-gradient(135deg,#1a6bff,#0a3bbf);
    display:flex;align-items:center;justify-content:center;font-size:22px;
    box-shadow:0 0 0 2px rgba(26,107,255,0.3),0 0 18px rgba(26,107,255,0.55);
    position:relative;flex-shrink:0;
}
.logo-badge::after{content:"";position:absolute;inset:-5px;border-radius:18px;
    border:1.5px solid rgba(91,155,255,0.45);animation:ringPulse 2.4s ease-in-out infinite;}
@keyframes ringPulse{0%,100%{transform:scale(1);opacity:0.7;}50%{transform:scale(1.18);opacity:0.15;}}
.insureai-title{font-family:'Syne',sans-serif !important;font-weight:800;font-size:2rem;
    letter-spacing:0.12em;color:var(--blue-mid);animation:titleGlow 3s ease-in-out infinite;line-height:1.1;}
@keyframes titleGlow{
    0%,100%{text-shadow:0 0 6px rgba(26,107,255,0.5),0 0 18px rgba(26,107,255,0.35);}
    50%{text-shadow:0 0 10px rgba(26,107,255,0.85),0 0 30px rgba(26,107,255,0.6);}
}
.insureai-sub{font-family:'DM Sans',sans-serif;font-size:0.78rem;font-weight:500;
    letter-spacing:0.22em;color:var(--text-muted);text-transform:uppercase;margin-top:2px;}
.divider{height:1px;background:linear-gradient(90deg,transparent,rgba(26,107,255,0.25),transparent);margin:16px 0;}
@keyframes flowGlow{0%{transform:translateX(-120%) skewX(-15deg);}100%{transform:translateX(500%) skewX(-15deg);}}
@keyframes iconBreathe{0%,100%{transform:scale(1);filter:drop-shadow(0 0 4px currentColor);}50%{transform:scale(1.22);filter:drop-shadow(0 0 18px currentColor);}}
@keyframes cardFloat{0%,100%{transform:translateY(0);}50%{transform:translateY(-4px);}}
@keyframes fadeUp{from{opacity:0;transform:translateY(14px);}to{opacity:1;transform:translateY(0);}}
@keyframes borderPulse{0%,100%{opacity:0.5;}50%{opacity:1;}}
.stat-row{display:flex;gap:14px;margin-bottom:28px;flex-wrap:wrap;}
.stat-card{
    flex:1;min-width:150px;
    background:linear-gradient(135deg,rgba(255,255,255,0.95),rgba(240,248,255,0.88));
    border-radius:20px;padding:22px 24px;position:relative;overflow:hidden;cursor:pointer;
    animation:fadeUp 0.5s ease both, cardFloat 4s ease-in-out infinite;
    transition:transform 0.25s ease,box-shadow 0.25s ease;
}
.stat-card::before{
    content:"";position:absolute;inset:0;border-radius:20px;padding:1.5px;
    background:linear-gradient(135deg,var(--c1),var(--c2),var(--c1));
    -webkit-mask:linear-gradient(#fff 0 0) content-box,linear-gradient(#fff 0 0);
    -webkit-mask-composite:xor;mask-composite:exclude;
    animation:borderPulse 2.5s ease-in-out infinite;
}
.stat-card::after{
    content:"";position:absolute;top:-50%;left:0;width:35%;height:200%;
    background:linear-gradient(90deg,transparent,rgba(255,255,255,0.6),transparent);
    animation:flowGlow 3.5s ease-in-out infinite;pointer-events:none;
}
.stat-card:nth-child(1){--c1:#1a6bff;--c2:#5b9bff;animation-delay:0s,0s;}
.stat-card:nth-child(2){--c1:#00c48c;--c2:#00f2aa;animation-delay:0.1s,0.5s;}
.stat-card:nth-child(3){--c1:#f5a623;--c2:#ffd580;animation-delay:0.2s,1s;}
.stat-card:nth-child(4){--c1:#ff4d6d;--c2:#ff8fa3;animation-delay:0.3s,1.5s;}
.stat-card:nth-child(1)::after{animation-delay:0s;}
.stat-card:nth-child(2)::after{animation-delay:0.9s;}
.stat-card:nth-child(3)::after{animation-delay:1.8s;}
.stat-card:nth-child(4)::after{animation-delay:2.7s;}
.stat-card:hover{transform:translateY(-8px) scale(1.03) !important;
    box-shadow:0 0 0 2px var(--c1),0 0 30px var(--c1),0 16px 40px rgba(0,0,0,0.10) !important;}
.stat-icon{font-size:1.9rem;margin-bottom:10px;display:block;animation:iconBreathe 2.8s ease-in-out infinite;}
.stat-card:nth-child(1) .stat-icon{color:#1a6bff;animation-delay:0s;}
.stat-card:nth-child(2) .stat-icon{color:#00c48c;animation-delay:0.7s;}
.stat-card:nth-child(3) .stat-icon{color:#f5a623;animation-delay:1.4s;}
.stat-card:nth-child(4) .stat-icon{color:#ff4d6d;animation-delay:2.1s;}
.stat-value{
    font-family:'Syne',sans-serif;font-size:2rem;font-weight:800;line-height:1;
    background:linear-gradient(135deg,var(--c1),var(--c2));
    -webkit-background-clip:text;-webkit-text-fill-color:transparent;
}
.stat-label{font-size:0.73rem;color:var(--text-muted);margin-top:5px;font-weight:600;letter-spacing:0.08em;text-transform:uppercase;}
.claim-wrap{
    margin-bottom:20px;border-radius:20px;overflow:hidden;
    box-shadow:0 4px 24px rgba(26,107,255,0.08);
    transition:transform 0.2s ease,box-shadow 0.2s ease;animation:fadeUp 0.4s ease both;
}
.claim-wrap:hover{transform:translateY(-3px);box-shadow:0 10px 36px rgba(26,107,255,0.14);}
.claim-top{
    background:var(--surface);padding:22px 28px 20px 28px;
    border-left:5px solid var(--sc);
    border:1px solid rgba(200,210,230,0.5);border-bottom:none;
}
.claim-header{display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:10px;}
.claim-id{font-family:'Syne',sans-serif;font-size:1rem;font-weight:700;color:var(--blue-deep);letter-spacing:0.04em;}
.claim-subtype{font-size:0.82rem;color:var(--text-muted);margin-top:3px;}
.status-badge{
    display:inline-flex;align-items:center;gap:6px;padding:6px 16px;
    border-radius:30px;font-size:0.78rem;font-weight:700;letter-spacing:0.05em;
    border:1.5px solid;white-space:nowrap;
}
.meta-row{display:flex;gap:28px;flex-wrap:wrap;margin-top:16px;}
.meta-label{font-size:0.70rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.10em;margin-bottom:3px;font-weight:600;}
.meta-val{font-size:0.9rem;color:var(--text-dark);font-weight:500;}
.status-box{
    padding:16px 28px 18px;border-left:5px solid var(--sc);
    border:1px solid rgba(200,210,230,0.4);border-top:none;
    border-radius:0 0 20px 20px;
}
.status-box-title{font-size:0.70rem;text-transform:uppercase;letter-spacing:0.12em;font-weight:700;color:var(--sc);margin-bottom:8px;}
.status-box-text{font-size:0.86rem;line-height:1.7;color:var(--text-dark);}
.rejection-tip{
    margin-top:12px;padding:10px 14px;border-radius:10px;
    background:rgba(255,77,109,0.05);border:1px dashed rgba(255,77,109,0.3);
    font-size:0.78rem;color:var(--text-muted);line-height:1.6;
}
.chatbot-cta{
    display:flex;align-items:center;gap:16px;
    background:linear-gradient(135deg,rgba(26,107,255,0.09),rgba(91,155,255,0.05));
    border:1px solid rgba(26,107,255,0.22);border-radius:18px;padding:18px 22px;margin-top:28px;
}
.chatbot-cta-icon{
    width:46px;height:46px;border-radius:13px;
    background:linear-gradient(135deg,#1a6bff,#0a3bbf);
    display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0;
    box-shadow:0 0 14px rgba(26,107,255,0.45);
}
[data-testid="stButton"] button{
    background:linear-gradient(135deg,#1a6bff,#0a4dd4) !important;
    color:white !important;border:none !important;border-radius:14px !important;
    font-family:'DM Sans',sans-serif !important;font-size:0.9rem !important;
    font-weight:600 !important;padding:12px 0 !important;
    box-shadow:0 4px 18px rgba(26,107,255,0.40) !important;
}
[data-testid="stButton"] button:hover{
    transform:translateY(-2px) !important;box-shadow:0 8px 24px rgba(26,107,255,0.55) !important;
}
[data-testid="stSelectbox"]>div>div{
    background:white !important;border:1px solid var(--border) !important;
    border-radius:12px !important;font-family:'DM Sans',sans-serif !important;
}
.empty-state{text-align:center;padding:60px 20px;color:var(--text-muted);}
</style>
""", unsafe_allow_html=True)

# ─────────────────────────────────────────
# SIDEBAR
# ─────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div style="padding:22px 16px 10px;">
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;">
            <div class="logo-badge">🛡️</div>
            <div>
                <div class="insureai-title" style="font-size:1.3rem;">INSUREAI</div>
                <div class="insureai-sub">AI-Powered Coverage</div>
            </div>
        </div>
        <hr style="border:none;border-top:1px solid rgba(255,255,255,0.08);margin:0 0 18px;"/>
    </div>
    """, unsafe_allow_html=True)

# ─────────────────────────────────────────
# HEADER
# ─────────────────────────────────────────
username = st.session_state.get("username", "User")
st.markdown(f"""
<div style="display:flex;align-items:center;gap:16px;padding:24px 0 8px;border-bottom:1px solid var(--border);">
    <div class="logo-badge">🛡️</div>
    <div>
        <div class="insureai-title">INSUREAI</div>
        <div class="insureai-sub">Intelligence-Driven Insurance Assistant</div>
    </div>
</div>
<div style="margin-top:20px;">
    <div style="font-family:'Syne',sans-serif;font-weight:700;font-size:1.55rem;color:var(--blue-deep);">📋 My Claims</div>
    <div style="font-size:0.85rem;color:var(--text-muted);margin-top:3px;">
        All claims filed under <strong>{username}</strong>
    </div>
</div>
<div class="divider"></div>
""", unsafe_allow_html=True)

# ─────────────────────────────────────────
# LOAD + ENRICH
# ─────────────────────────────────────────
claims = load_claims()

for c in claims:
    c["_type"]   = detect_claim_type(c)
    c["_amount"] = extract_amount(c)
    c["_status"] = normalise_status(c.get("status", "pending"))
    c["_reason"] = get_rejection_reason(c) if c["_status"] == "rejected" else ""

st.session_state["user_claims"]      = claims
st.session_state["chatbot_username"] = username

# ─────────────────────────────────────────
# STATS
# ─────────────────────────────────────────
total    = len(claims)
approved = sum(1 for c in claims if c["_status"] == "approved")
pending  = sum(1 for c in claims if c["_status"] == "pending")
rejected = sum(1 for c in claims if c["_status"] == "rejected")

st.markdown(f"""
<div class="stat-row">
    <div class="stat-card"><span class="stat-icon">📋</span>
        <div class="stat-value">{total}</div><div class="stat-label">Total Claims</div></div>
    <div class="stat-card"><span class="stat-icon">✅</span>
        <div class="stat-value">{approved}</div><div class="stat-label">Approved</div></div>
    <div class="stat-card"><span class="stat-icon">⏳</span>
        <div class="stat-value">{pending}</div><div class="stat-label">Pending</div></div>
    <div class="stat-card"><span class="stat-icon">❌</span>
        <div class="stat-value">{rejected}</div><div class="stat-label">Rejected</div></div>
</div>
""", unsafe_allow_html=True)

# ─────────────────────────────────────────
# FILTER + SORT
# ─────────────────────────────────────────
col_f, col_s = st.columns([3, 1])
with col_f:
    status_filter = st.selectbox("Filter", ["All","Approved","Pending","Rejected"],
                                  label_visibility="collapsed")
with col_s:
    sort_by = st.selectbox("Sort", ["Newest First","Oldest First","Amount ↑","Amount ↓"],
                            label_visibility="collapsed")

filtered = claims if status_filter == "All" else [
    c for c in claims if c["_status"] == status_filter.lower()
]

def sort_key(c):
    if "Amount" in sort_by:
        raw = c.get("_amount","—").replace("₹","").replace(",","")
        try: return float(raw)
        except: return 0
    raw = c.get("submission_date", c.get("date",""))
    for f in ("%Y-%m-%d %H:%M:%S","%Y-%m-%d","%d-%m-%Y"):
        try: return datetime.strptime(str(raw).strip(), f)
        except: pass
    return datetime.min

filtered = sorted(filtered, key=sort_key, reverse=sort_by in ("Newest First","Amount ↓"))

st.markdown(
    f"<div style='font-size:0.8rem;color:var(--text-muted);margin-bottom:16px;'>"
    f"{len(filtered)} claim(s) shown</div>",
    unsafe_allow_html=True
)

# ─────────────────────────────────────────
# CLAIM CARDS
# ─────────────────────────────────────────
if not filtered:
    st.markdown("""
    <div class="empty-state">
        <div style="font-size:3rem;margin-bottom:12px;">📭</div>
        <div style="font-family:'Syne',sans-serif;font-size:1.1rem;color:var(--blue-deep);margin-bottom:6px;">No claims found</div>
        <div>No claims match your current filter, or none have been filed yet.</div>
    </div>
    """, unsafe_allow_html=True)

else:
    for i, claim in enumerate(filtered):
        ns        = claim["_status"]
        cfg       = STATUS_CFG[ns]
        color     = cfg["color"]
        rgb       = cfg["rgb"]

        claim_id  = claim.get("claim_id", f"CLM-{i+1:04d}")
        ctype     = claim["_type"]
        amount    = claim["_amount"]
        date_sub  = fmt_date(claim.get("submission_date", claim.get("date","")))
        date_upd  = fmt_date(claim.get("last_updated",   claim.get("updated_date","")))
        policy_no = claim.get("policy_id", claim.get("policy_number","—"))

        # ── Card top ──
        st.markdown(f"""
        <div class="claim-wrap" style="animation-delay:{i*0.08}s;">
          <div class="claim-top" style="--sc:{color};">
            <div class="claim-header">
              <div>
                <div class="claim-id">{claim_id}</div>
                <div class="claim-subtype">{ctype}</div>
              </div>
              <div class="status-badge"
                   style="color:{color};background:rgba({rgb},0.10);
                          border-color:{color};box-shadow:0 0 12px rgba({rgb},0.25);">
                {cfg['icon']}&nbsp;{cfg['label']}
              </div>
            </div>
            <div class="meta-row">
              <div>
                <div class="meta-label">Claim Amount</div>
                <div class="meta-val" style="font-family:'Syne',sans-serif;
                     color:var(--blue-mid);font-weight:700;font-size:1rem;">{amount}</div>
              </div>
              <div>
                <div class="meta-label">Policy ID</div>
                <div class="meta-val">{policy_no}</div>
              </div>
              <div>
                <div class="meta-label">Date Submitted</div>
                <div class="meta-val">{date_sub}</div>
              </div>
              <div>
                <div class="meta-label">Last Updated</div>
                <div class="meta-val">{date_upd}</div>
              </div>
            </div>
          </div>
        </div>
        """, unsafe_allow_html=True)

        # ── Status box (separate render = no HTML escaping) ──
        if ns == "rejected":
            reason = claim["_reason"]
            st.markdown(f"""
            <div class="status-box"
                 style="--sc:{color};background:rgba({rgb},0.05);
                        border-color:rgba({rgb},0.3);border-left-color:{color};margin-top:-20px;">
              <div class="status-box-title">❌ &nbsp;Reason for Rejection</div>
              <div class="status-box-text">{reason}</div>
              <div class="rejection-tip">
                💡 <strong>Next steps:</strong> You may appeal this decision by contacting your
                claims officer with additional supporting documents. Use the
                <strong>InsureAI Assistant</strong> below for step-by-step resubmission guidance.
              </div>
            </div>
            """, unsafe_allow_html=True)

        elif ns == "approved":
            st.markdown(f"""
            <div class="status-box"
                 style="--sc:{color};background:rgba({rgb},0.05);
                        border-color:rgba({rgb},0.3);border-left-color:{color};margin-top:-20px;">
              <div class="status-box-title">✅ &nbsp;Approval Confirmation</div>
              <div class="status-box-text">
                Your claim has been reviewed and approved. The settlement amount will be
                credited to your registered bank account within
                <strong>5–7 working days</strong>. Contact support if not received after 7 days.
              </div>
            </div>
            """, unsafe_allow_html=True)

        else:
            st.markdown(f"""
            <div class="status-box"
                 style="--sc:{color};background:rgba({rgb},0.05);
                        border-color:rgba({rgb},0.3);border-left-color:{color};margin-top:-20px;">
              <div class="status-box-title">⏳ &nbsp;Under Review</div>
              <div class="status-box-text">
                Your claim is currently being reviewed by our underwriting team.
                Document verification is in progress. You will be notified via email
                once a final decision is made. This typically takes
                <strong>5–10 business days</strong>.
              </div>
            </div>
            """, unsafe_allow_html=True)

# ─────────────────────────────────────────
# CHATBOT CTA
# ─────────────────────────────────────────
st.markdown("""
<div class="divider" style="margin-top:32px;"></div>
<div class="chatbot-cta">
    <div class="chatbot-cta-icon">💬</div>
    <div>
        <div style="font-family:'Syne',sans-serif;font-size:0.95rem;font-weight:700;color:var(--blue-deep);">
            Need help understanding your claim?
        </div>
        <div style="font-size:0.8rem;color:var(--text-muted);margin-top:2px;">
            The InsureAI Assistant already knows your claims — ask about rejection reasons,
            appeal steps, pending timelines, or coverage queries.
        </div>
    </div>
</div>
""", unsafe_allow_html=True)

col1, col2, col3 = st.columns([1, 2, 1])
with col2:
    if st.button("💬 Ask InsureAI About My Claims", use_container_width=True):
        lines = []
        for c in claims:
            line = (
                f"- ID: {c.get('claim_id','?')} | Type: {c['_type']} | "
                f"Status: {c['_status'].title()} | Amount: {c['_amount']} | "
                f"Policy: {c.get('policy_id','?')} | "
                f"Submitted: {fmt_date(c.get('submission_date','?'))}"
            )
            if c.get("_reason"):
                line += f" | Rejection Reason: {c['_reason']}"
            lines.append(line)

        st.session_state["chatbot_claims_context"] = "\n".join(lines) if lines else "No claims on file."
        st.session_state["claim_context_hint"] = (
            f"Hi, I'm {username}. I've just viewed my claims page. "
            f"Can you summarise my claims and explain anything important, especially any rejections?"
        )
        st.switch_page("pages/05_chatbot.py")