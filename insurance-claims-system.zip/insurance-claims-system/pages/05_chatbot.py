import streamlit as st
from modules.rag_system import generate_chatbot_response, load_datasets
 
# -----------------------------
# Page Config — MUST BE FIRST
# -----------------------------
st.set_page_config(page_title="InsureAI", page_icon="🛡️", layout="wide")
 


# -----------------------------
# Auth Guard
# -----------------------------
if not st.session_state.get('user_logged_in'):
    st.switch_page("app.py")
    st.stop()
 
# -----------------------------
# Load datasets into ChromaDB
# -----------------------------
load_datasets(clear_before_load=False)
 
# -----------------------------
# FUTURISTIC CSS
# -----------------------------
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&family=DM+Sans:wght@300;400;500;600&display=swap');
 
/* ── ROOT ── */
:root {
    --blue-deep:   #0a1f5c;
    --blue-mid:    #1a6bff;
    --blue-light:  #5b9bff;
    --blue-glow:   rgba(26,107,255,0.35);
    --white:       #ffffff;
    --surface:     rgba(255,255,255,0.72);
    --border:      rgba(26,107,255,0.18);
    --text-dark:   #0d1b3e;
    --text-muted:  #5c6e9a;
    --radius-lg:   20px;
    --radius-xl:   28px;
}
 
/* ── PAGE BACKGROUND ── */
html, body,
[data-testid="stAppViewContainer"],
[data-testid="stMain"] {
    font-family: 'DM Sans', sans-serif !important;
    background: transparent !important;
}
 
[data-testid="stAppViewContainer"] {
    background:
        radial-gradient(ellipse 80% 60% at 50% -10%,  rgba(26,107,255,0.18) 0%, transparent 70%),
        radial-gradient(ellipse 60% 40% at 100% 80%,  rgba(91,155,255,0.12) 0%, transparent 65%),
        radial-gradient(ellipse 50% 50% at 0%   60%,  rgba(10,31,92,0.07)   0%, transparent 60%),
        linear-gradient(170deg, #f2f6ff 0%, #ffffff 55%, #eef4ff 100%)
    !important;
    min-height: 100vh;
}
 
/* ── HIDE STREAMLIT CHROME ── */
#MainMenu, footer, header,
[data-testid="stDecoration"],
[data-testid="stStatusWidget"] { visibility: hidden !important; }


 
/* ── SIDEBAR ── */
[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #060e20 0%, #0a1840 100%) !important;
    border-right: 1px solid rgba(26,107,255,0.25) !important;
    box-shadow: 4px 0 32px rgba(26,107,255,0.12) !important;
}
[data-testid="stSidebar"] * { color: #a8c0e8 !important; }
[data-testid="stSidebar"] hr { border-color: rgba(255,255,255,0.08) !important; }
 
/* ── LOGO BADGE ── */
.logo-badge {
    width: 48px; height: 48px;
    border-radius: 14px;
    background: linear-gradient(135deg, #1a6bff, #0a3bbf);
    display: flex; align-items: center; justify-content: center;
    font-size: 22px;
    box-shadow:
        0 0 0 2px rgba(26,107,255,0.3),
        0 0 18px rgba(26,107,255,0.55),
        0 0 40px rgba(26,107,255,0.25);
    position: relative;
    flex-shrink: 0;
}
.logo-badge::after {
    content: "";
    position: absolute;
    inset: -5px;
    border-radius: 18px;
    border: 1.5px solid rgba(91,155,255,0.45);
    animation: ringPulse 2.4s ease-in-out infinite;
}
@keyframes ringPulse {
    0%, 100% { transform: scale(1);   opacity: 0.7; }
    50%       { transform: scale(1.18); opacity: 0.15; }
}
 
/* ── GLOWING TITLE ── */
.insureai-title {
    font-family: 'Syne', sans-serif !important;
    font-weight: 800;
    font-size: 2rem;
    letter-spacing: 0.12em;
    color: var(--blue-mid);
    text-shadow:
        0 0 6px  rgba(26,107,255,0.55),
        0 0 20px rgba(26,107,255,0.40),
        0 0 48px rgba(26,107,255,0.25);
    animation: titleGlow 3s ease-in-out infinite;
    line-height: 1.1;
}
@keyframes titleGlow {
    0%, 100% {
        text-shadow:
            0 0 6px  rgba(26,107,255,0.5),
            0 0 18px rgba(26,107,255,0.35),
            0 0 42px rgba(26,107,255,0.2);
    }
    50% {
        text-shadow:
            0 0 10px rgba(26,107,255,0.85),
            0 0 30px rgba(26,107,255,0.60),
            0 0 70px rgba(26,107,255,0.35);
    }
}
.insureai-sub {
    font-family: 'DM Sans', sans-serif;
    font-size: 0.78rem;
    font-weight: 500;
    letter-spacing: 0.22em;
    color: var(--text-muted);
    text-transform: uppercase;
    margin-top: 2px;
}
 
/* ── HEADER WRAPPER ── */
.header-wrap {
    display: flex;
    align-items: center;
    gap: 16px;
    padding: 24px 0 10px;
    border-bottom: 1px solid var(--border);
    margin-bottom: 20px;
}
.user-pill {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    background: rgba(26,107,255,0.08);
    border: 1px solid var(--border);
    border-radius: 30px;
    padding: 5px 14px 5px 8px;
    font-size: 0.82rem;
    color: var(--blue-deep);
    margin-top: 6px;
}
.user-dot {
    width: 26px; height: 26px;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--blue-mid), var(--blue-deep));
    color: white;
    display: flex; align-items: center; justify-content: center;
    font-size: 13px;
}
 
/* ── HIDE NATIVE CHAT MESSAGES ── */
[data-testid="stChatMessage"] { display: none !important; }
 
/* ── CHAT CONTAINER ── */
.chat-scroll {
    max-height: 62vh;
    overflow-y: auto;
    padding: 8px 4px 16px;
    scroll-behavior: smooth;
    scrollbar-width: thin;
    scrollbar-color: rgba(26,107,255,0.25) transparent;
}
.chat-scroll::-webkit-scrollbar { width: 5px; }
.chat-scroll::-webkit-scrollbar-thumb {
    background: rgba(26,107,255,0.25);
    border-radius: 10px;
}
 
/* ── BUBBLE ROWS ── */
.bubble-row {
    display: flex;
    align-items: flex-end;
    gap: 10px;
    margin: 8px 0;
    animation: fadeUp 0.28s ease forwards;
}
.bubble-row.left  { flex-direction: row; }
.bubble-row.right { flex-direction: row-reverse; }
 
@keyframes fadeUp {
    from { opacity: 0; transform: translateY(10px); }
    to   { opacity: 1; transform: translateY(0); }
}
 
/* ── AVATARS ── */
.avatar {
    width: 36px; height: 36px;
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-size: 15px;
    flex-shrink: 0;
}
.avatar.bot-av {
    background: linear-gradient(135deg, #0a1f5c, #0d2d7a);
    border: 2px solid rgba(26,107,255,0.55);
    box-shadow: 0 0 14px rgba(26,107,255,0.45);
    color: #7eb8ff;
}
.avatar.user-av {
    background: linear-gradient(135deg, var(--blue-mid), #0a52e0);
    color: white;
    box-shadow: 0 0 12px rgba(26,107,255,0.5);
}
 
/* ── BUBBLES ── */
.bubble {
    max-width: 62%;
    padding: 12px 18px;
    font-size: 0.9rem;
    line-height: 1.55;
    word-break: break-word;
}
.bubble.bot {
    background: var(--surface);
    color: var(--text-dark);
    border-radius: 18px 18px 18px 4px;
    border: 1px solid var(--border);
    box-shadow:
        0 2px 12px rgba(26,107,255,0.08),
        inset 0 1px 0 rgba(255,255,255,0.9);
    backdrop-filter: blur(8px);
}
.bubble.user {
    background: linear-gradient(135deg, #1a6bff, #0a4dd4);
    color: white;
    border-radius: 18px 18px 4px 18px;
    box-shadow:
        0 4px 18px rgba(26,107,255,0.40),
        0 1px 4px rgba(26,107,255,0.25);
}
 
/* ── THINKING DOTS ── */
.typing {
    display: flex;
    gap: 5px;
    align-items: center;
    padding: 4px 2px;
}
.typing span {
    width: 7px; height: 7px;
    background: var(--blue-mid);
    border-radius: 50%;
    animation: bounce 1.1s ease-in-out infinite;
    opacity: 0.85;
}
.typing span:nth-child(1) { animation-delay: 0s;    }
.typing span:nth-child(2) { animation-delay: 0.22s; }
.typing span:nth-child(3) { animation-delay: 0.44s; }
 
@keyframes bounce {
    0%, 80%, 100% { transform: translateY(0);   opacity: 0.6; }
    40%            { transform: translateY(-7px); opacity: 1;   }
}
 
/* ── CHAT INPUT BOX ── */
[data-testid="stChatInputContainer"] {
    background: rgba(255,255,255,0.88) !important;
    border: 1.5px solid rgba(26,107,255,0.28) !important;
    border-radius: 18px !important;
    box-shadow:
        0 4px 24px rgba(26,107,255,0.10),
        0 1px 4px  rgba(26,107,255,0.07) !important;
    backdrop-filter: blur(10px) !important;
    padding: 4px 6px !important;
    transition: box-shadow 0.2s ease, border-color 0.2s ease !important;
}
[data-testid="stChatInputContainer"]:focus-within {
    border-color: rgba(26,107,255,0.55) !important;
    box-shadow:
        0 0 0 4px rgba(26,107,255,0.12),
        0 6px 28px rgba(26,107,255,0.15) !important;
}
[data-testid="stChatInputContainer"] textarea {
    font-family: 'DM Sans', sans-serif !important;
    font-size: 0.92rem !important;
    color: var(--text-dark) !important;
    padding: 10px 4px !important;
}
[data-testid="stChatInputContainer"] textarea::placeholder {
    color: #8fa8d0 !important;
    font-style: italic;
}
 
/* SEND BUTTON */
[data-testid="stChatInputContainer"] button {
    background: linear-gradient(135deg, var(--blue-mid), #0a4dd4) !important;
    border: none !important;
    border-radius: 12px !important;
    width: 42px !important; height: 42px !important;
    color: white !important;
    box-shadow: 0 2px 12px rgba(26,107,255,0.45) !important;
    transition: transform 0.15s ease, box-shadow 0.15s ease !important;
}
[data-testid="stChatInputContainer"] button:hover {
    transform: translateY(-2px) !important;
    box-shadow: 0 6px 20px rgba(26,107,255,0.55) !important;
}
[data-testid="stChatInputContainer"] button:active {
    transform: scale(0.92) !important;
}
 
/* ── DIVIDER LINE UNDER HEADER ── */
.section-divider {
    height: 1px;
    background: linear-gradient(90deg, transparent, rgba(26,107,255,0.25), transparent);
    margin: 0 0 18px;
}
</style>
""", unsafe_allow_html=True)
 
# -----------------------------
# SIDEBAR
# -----------------------------
with st.sidebar:
    st.markdown("""
    <div style="padding: 22px 16px 10px;">
        <div style="display:flex; align-items:center; gap:12px; margin-bottom:20px;">
            <div class="logo-badge">🛡️</div>
            <div>
                <div class="insureai-title" style="font-size:1.3rem;">INSUREAI</div>
                <div class="insureai-sub">AI-Powered Coverage</div>
            </div>
        </div>
        <hr style="border:none; border-top:1px solid rgba(255,255,255,0.08); margin:0 0 18px;" />
        <div style="font-size:0.8rem; color:#6a88b8; margin-bottom:8px; letter-spacing:0.1em; text-transform:uppercase;">Navigation</div>
    </div>
    """, unsafe_allow_html=True)
 
# -----------------------------
# HEADER
# -----------------------------

st.markdown(f"""
<div class="header-wrap">
    <div class="logo-badge">🛡️</div>
    <div>
        <div class="insureai-title">INSUREAI</div>
        <div class="insureai-sub">Intelligence-Driven Insurance Assistant</div>
    </div>
</div>
<div class="user-pill">
    <div class="user-dot">👤</div>    
</div>
<div class="section-divider" style="margin-top:14px;"></div>
""", unsafe_allow_html=True)
 
# -----------------------------
# SESSION
# -----------------------------
if "messages" not in st.session_state:
    st.session_state.messages = []
 
# -----------------------------
# RENDER CHAT HISTORY
# -----------------------------
def render_messages():
    html = '<div class="chat-scroll" id="chat-scroll">'
    for msg in st.session_state.messages:
        # Sanitize to prevent XSS
        content = (
            msg["content"]
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\n", "<br>")
        )
        if msg["role"] == "user":
            html += f"""
            <div class="bubble-row right">
                <div class="bubble user">{content}</div>
                <div class="avatar user-av">👤</div>
            </div>"""
        else:
            html += f"""
            <div class="bubble-row left">
                <div class="avatar bot-av">🛡️</div>
                <div class="bubble bot">{content}</div>
            </div>"""
    html += "</div>"
    # Auto-scroll to bottom
    html += """
    <script>
        const el = document.getElementById('chat-scroll');
        if (el) el.scrollTop = el.scrollHeight;
    </script>
    """
    st.markdown(html, unsafe_allow_html=True)
 
render_messages()
 
# -----------------------------
# CHAT INPUT
# -----------------------------
user_input = st.chat_input("Ask me anything about your insurance policy…")
 
if user_input:
    # Append user message
    st.session_state.messages.append({"role": "user", "content": user_input})
 
    # Show thinking indicator
    st.markdown("""
    <div class="bubble-row left" style="margin-top:8px;">
        <div class="avatar bot-av">🛡️</div>
        <div class="bubble bot">
            <div class="typing">
                <span></span><span></span><span></span>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)
 
    # Generate response
    bot_response = generate_chatbot_response(user_input)
 
    # Append bot response and rerun
    st.session_state.messages.append({"role": "assistant", "content": bot_response})
    st.rerun()