import os
import pandas as pd
import chromadb
from chromadb.utils import embedding_functions

# --------------------------------
# CONFIGd
# --------------------------------
CHROMA_PATH = "data/chroma"

FILES = [
    {
        "path": "policy_clauses.csv",
        "collection": "policy_clauses",
        "text_column": "clause_description"
    },
    {
        "path": "fraud_cases.csv",
        "collection": "fraud_cases",
        "text_column": "case_description"
    },
    {
        "path": "similar_claims.csv",
        "collection": "similar_claims",
        "text_column": "claim_description"
    }
]

# --------------------------------
# INIT CHROMADB
# --------------------------------
os.makedirs(CHROMA_PATH, exist_ok=True)

client = chromadb.PersistentClient(path=CHROMA_PATH)

embedding_function = embedding_functions.SentenceTransformerEmbeddingFunction(
    model_name="all-MiniLM-L6-v2"
)

# --------------------------------
# LOAD FUNCTION
# --------------------------------
def load_csv_to_chroma(file_config):
    path = file_config["path"]
    collection_name = file_config["collection"]
    text_column = file_config["text_column"]

    if not os.path.exists(path):
        print(f"❌ File not found: {path}")
        return

    df = pd.read_csv(path)

    collection = client.get_or_create_collection(
        name=collection_name,
        embedding_function=embedding_function
    )

    # Skip if already loaded
    if collection.count() > 0:
        print(f"⏭ Skipping {collection_name} (already loaded)")
        return

    documents = []
    metadatas = []
    ids = []

    for i, row in df.iterrows():
        text = str(row.get(text_column, "")).strip()

        if not text:
            continue

        documents.append(text)

        # store all other columns as metadata
        metadata = {
            col: str(row[col]) for col in df.columns if col != text_column
        }
        metadatas.append(metadata)

        ids.append(f"{collection_name}_{i}")

    if documents:
        collection.add(
            documents=documents,
            metadatas=metadatas,
            ids=ids
        )
        print(f"✅ Loaded {collection_name} ({len(documents)} records)")
    else:
        print(f"⚠️ No valid data in {collection_name}")

# --------------------------------
# RUN FOR ALL FILES
# --------------------------------
for file in FILES:
    load_csv_to_chroma(file)

print("\n🚀 All datasets vectorized and stored in ChromaDB")