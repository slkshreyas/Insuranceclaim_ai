"""
Document Processor Module - Extends RAG System
Handles: PDF parsing, document validation, fraud analysis, report generation, visualization
UPDATED: Now stores decisions in centralized decisions.json
"""

import os
import sys
import json
import logging
import plotly.graph_objects as go
from pathlib import Path
from datetime import datetime

# ════════════════════════════════════════════════════════════════
# LOGGING SETUP — Structured, Coloured, Multi-handler
# Shares log files with rag_system so all events go to one place.
# Outputs to:
#   logs/rag_system.log   — INFO+  (shared with rag_system)
#   logs/rag_errors.log   — ERROR+ (shared with rag_system)
#   stdout                — coloured terminal output
# ════════════════════════════════════════════════════════════════
os.makedirs("logs", exist_ok=True)

class _Colours:
    RESET   = "\033[0m"
    BOLD    = "\033[1m"
    GREY    = "\033[38;5;240m"
    CYAN    = "\033[36m"
    GREEN   = "\033[32m"
    YELLOW  = "\033[33m"
    RED     = "\033[31m"
    MAGENTA = "\033[35m"
    BG_RED  = "\033[41m"

_LEVEL_COLOURS = {
    "DEBUG"    : _Colours.GREY,
    "INFO"     : _Colours.CYAN,
    "WARNING"  : _Colours.YELLOW,
    "ERROR"    : _Colours.RED,
    "CRITICAL" : _Colours.BG_RED + _Colours.BOLD,
}

class _ColourFormatter(logging.Formatter):
    FILE_FMT    = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
    CONSOLE_FMT = "{bold}%(asctime)s{reset} | {lc}%(levelname)-8s{reset} | {cyan}%(name)s{reset} | %(message)s"

    def __init__(self, use_colour: bool = False):
        super().__init__()
        self.use_colour = use_colour

    def format(self, record: logging.LogRecord) -> str:
        lc  = _LEVEL_COLOURS.get(record.levelname, "")
        fmt = (
            self.CONSOLE_FMT.format(
                bold=_Colours.BOLD, reset=_Colours.RESET,
                lc=lc, cyan=_Colours.CYAN
            )
            if self.use_colour else self.FILE_FMT
        )
        return logging.Formatter(fmt, datefmt="%Y-%m-%d %H:%M:%S").format(record)

def _log_banner(title: str, width: int = 60) -> None:
    """Print a visible section banner to stdout."""
    bar = "═" * width
    print(f"\n{_Colours.CYAN}{_Colours.BOLD}{bar}{_Colours.RESET}")
    print(f"{_Colours.CYAN}{_Colours.BOLD}  {title}{_Colours.RESET}")
    print(f"{_Colours.CYAN}{_Colours.BOLD}{bar}{_Colours.RESET}\n")

def _build_doc_logger(name: str) -> logging.Logger:
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger
    logger.setLevel(logging.DEBUG)

    fh_all = logging.FileHandler("logs/rag_system.log", encoding="utf-8")
    fh_all.setLevel(logging.INFO)
    fh_all.setFormatter(_ColourFormatter(use_colour=False))

    fh_err = logging.FileHandler("logs/rag_errors.log", encoding="utf-8")
    fh_err.setLevel(logging.ERROR)
    fh_err.setFormatter(_ColourFormatter(use_colour=False))

    sh = logging.StreamHandler(stream=sys.stdout)
    sh.setLevel(logging.INFO)
    try:
        sh.stream.reconfigure(encoding="utf-8", errors="replace")
    except AttributeError:
        pass
    sh.setFormatter(_ColourFormatter(use_colour=True))

    logger.addHandler(fh_all)
    logger.addHandler(fh_err)
    logger.addHandler(sh)
    logger.propagate = False
    return logger

log = _build_doc_logger(__name__)
_log_banner("DOCUMENT PROCESSOR — InsureAI")

# ================================
# 1. DOCUMENT REQUIREMENTS
# ================================
DOCUMENT_REQUIREMENTS = {
    'health_insurance': {
        'required': ['medical_report', 'id_proof', 'prescription'],
        'description': 'Health Insurance Claim Documents'
    },
    'car_insurance': {
        'required': ['registration', 'driver_license', 'police_report', 'damage_photos'],
        'description': 'Car Insurance Claim Documents'
    },
    'home_insurance': {
        'required': ['property_deed', 'damage_photos', 'id_proof', 'police_report'],
        'description': 'Home Insurance Claim Documents'
    },
    'travel_insurance': {
        'required': ['passport', 'ticket', 'medical_report', 'cancellation_proof'],
        'description': 'Travel Insurance Claim Documents'
    }
}


# ================================
# 2. EXTRACT TEXT FROM PDF
# ================================
# ================================
# 2. EXTRACT TEXT FROM PDF
# ================================
def extract_text_from_pdf(file_path_or_bytes):
    """Extract text from PDF file path OR in-memory bytes (Streamlit uploads)"""
    try:
        import PyPDF2
        from io import BytesIO

        # ✅ If it's bytes/BytesIO (Streamlit upload), read directly
        if isinstance(file_path_or_bytes, (bytes, BytesIO)):
            file_obj = BytesIO(file_path_or_bytes) if isinstance(file_path_or_bytes, bytes) else file_path_or_bytes
        else:
            # It's a file path string — open from disk
            file_obj = open(file_path_or_bytes, 'rb')

        text = ""
        pdf_reader = PyPDF2.PdfReader(file_obj)
        for page in pdf_reader.pages:
            text += page.extract_text() + "\n"

        log.info(f"📄 PDF extracted — {len(text):,} characters read")
        return text

    except ImportError:
        log.error("❌ PyPDF2 not installed — run: pip install PyPDF2")
        return None
    except Exception as e:
        log.error(f"❌ PDF extraction failed: {e}")
        return None


# ================================
# 4. PARSE UPLOADED FILES
# ================================
def extract_document_content(uploaded_files):
    """
    Extract text content from all uploaded files.
    Supports Streamlit UploadedFile objects (in-memory) and file paths.

    Args:
        uploaded_files: List of Streamlit UploadedFile objects or file paths

    Returns:
        dict: {filename: extracted_text}
    """
    extracted_content = {}

    for file in uploaded_files:
        try:
            file_name = Path(file.name if hasattr(file, 'name') else str(file)).name

            if file_name.lower().endswith('.pdf'):
                # ✅ FIX: Read bytes from Streamlit memory, don't use file path
                if hasattr(file, 'read'):
                    file_bytes = file.read()
                    file.seek(0)  # Reset pointer so it can be read again later
                    text = extract_text_from_pdf(file_bytes)
                else:
                    text = extract_text_from_pdf(str(file))
            else:
                text = f"File: {file_name}"

            if text:
                extracted_content[file_name] = text
                log.info(f"   ✅ Processed  : {file_name}")
            else:
                log.warning(f"   ⚠️  No text extracted from: {file_name}")

        except Exception as e:
            log.error(f"[ERROR] Failed to process {file}: {e}")

    return extracted_content






# ================================
# 5. VALIDATE DOCUMENTS
# ================================
def validate_documents(uploaded_files, insurance_type):
    """
    Check if all required documents are present

    Args:
        uploaded_files: List of uploaded files
        insurance_type: Type of insurance (health, car, home, travel)

    Returns:
        dict: Validation results with missing/present docs
    """

    if insurance_type not in DOCUMENT_REQUIREMENTS:
        return {
            "status": "ERROR",
            "message": f"Unknown insurance type: {insurance_type}",
            "valid": False,
            "required_documents": [],
            "uploaded_documents": [],
            "missing_documents": [],
            "found_documents": [],
            "completion_percentage": 0,
            "required_count": 0,
            "uploaded_count": 0
        }

    required_docs = DOCUMENT_REQUIREMENTS[insurance_type]['required']
    uploaded_file_names = [f.name if hasattr(f, 'name') else str(f) for f in uploaded_files]

    # Check which required docs are uploaded
    missing_docs = []
    found_docs = []

    for req_doc in required_docs:
        doc_found = False
        for uploaded in uploaded_file_names:
            if req_doc.lower() in uploaded.lower():
                doc_found = True
                found_docs.append(req_doc)
                break

        if not doc_found:
            missing_docs.append(req_doc)

    completion_percentage = (len(found_docs) / len(required_docs) * 100) if required_docs else 0
    validation_valid = len(missing_docs) == 0

    result = {
        "status": "COMPLETE" if validation_valid else "INCOMPLETE",
        "insurance_type": insurance_type,
        "required_documents": required_docs,
        "uploaded_documents": uploaded_file_names,
        "found_documents": found_docs,
        "missing_documents": missing_docs,
        "completion_percentage": round(completion_percentage, 2),
        "valid": validation_valid,
        "message": "All required documents uploaded" if validation_valid
                   else f"Missing {len(missing_docs)} documents: {', '.join(missing_docs)}",
        "required_count": len(required_docs),
        "uploaded_count": len(found_docs)
    }

    log.info("━" * 56)
    log.info(f"📋 DOCUMENT VALIDATION")
    log.info(f"   Insurance type : {insurance_type}")
    log.info(f"   Status         : {result['status']}")
    log.info(f"   Completion     : {result['completion_percentage']}%  ({result['uploaded_count']}/{result['required_count']})")
    if result['missing_documents']:
        log.warning(f"   Missing docs   : {', '.join(result['missing_documents'])}")
    else:
        log.info(f"   Missing docs   : None — all documents present ✅")
    log.info("━" * 56)
    return result


# ================================
# 6. GENERATE FINAL REPORT
# ✅ FIX: Now calls save_decision_to_json() automatically
# ================================
def generate_final_report(fraud_analysis, document_validation, claim_id=None):
    """
    Combine fraud analysis + document validation into final report.
    Automatically saves the decision to data/decisions.json.

    Args:
        fraud_analysis: Result from analyze_claim()
        document_validation: Result from validate_documents()
        claim_id: Optional claim ID (auto-generated if None)

    Returns:
        dict: Final comprehensive report
    """

    # Determine final status
    doc_valid    = document_validation.get('valid', False)
    missing_docs = document_validation.get('missing_documents', [])
    is_fraud     = fraud_analysis.get('is_fraud', None)

    # ══════════════════════════════════════════════════════════════
    # HARD RULE: Missing documents → IMMEDIATE REJECTION
    # No officer review, no pending state — auto-rejected by AI.
    # ══════════════════════════════════════════════════════════════
    if not doc_valid:
        missing_list   = ', '.join(missing_docs) if missing_docs else 'required documents'
        final_decision = "REJECTED"
        rejection_reason = (
            f"Claim automatically rejected: {len(missing_docs)} required document(s) "
            f"not uploaded — {missing_list}. "
            f"Please resubmit with all required documents."
        )
        recommendation = rejection_reason
        log.warning("🚫 AUTO-REJECT TRIGGERED in generate_final_report()")
        log.warning(f"   Claim ID     : {claim_id}")
        log.warning(f"   Missing Docs : {missing_list}")
        log.warning(f"   Decision     : REJECTED immediately — no officer review")
    elif is_fraud:
        final_decision   = "REJECTED"
        rejection_reason = f"Claim appears fraudulent: {fraud_analysis.get('reason', 'Suspicious indicators detected')}"
        recommendation   = rejection_reason
    elif fraud_analysis.get('action') == 'INVESTIGATE':
        final_decision   = "UNDER_REVIEW"
        recommendation   = "Manual review required by officer"
        rejection_reason = None
    else:
        final_decision   = "AI APPROVED ✅       Officer Pending ❗"
        recommendation   = "Claim appears genuine and complete"
        rejection_reason = None

    insurance_type = document_validation.get('insurance_type')

    # ── Determine officer action status ─────────────────────────────
    # If AI auto-rejects due to missing docs → officer action is also
    # set to REJECTED immediately (no manual review needed).
    # For all other cases → officer must still review.
    auto_rejected_docs = (not doc_valid)
    officer_action = "REJECTED" if auto_rejected_docs else "PENDING"

    final_report = {
        "final_decision": final_decision,
        "recommendation": recommendation,
        "rejection_reason": rejection_reason,          # None if approved/under_review
        "auto_rejected": auto_rejected_docs,           # True when docs are missing
        "fraud_analysis": {
            "verdict": fraud_analysis.get('verdict'),
            "is_fraud": fraud_analysis.get('is_fraud'),
            "reason": fraud_analysis.get('reason'),
            "action": fraud_analysis.get('action'),
            "raw_response": fraud_analysis.get('raw')
        },
        "document_validation": {
            "status": document_validation.get('status'),
            "insurance_type": insurance_type,
            "uploaded_count": document_validation.get('uploaded_count'),
            "required_count": document_validation.get('required_count'),
            "completion_percentage": document_validation.get('completion_percentage'),
            "missing_documents": document_validation.get('missing_documents', []),
            "found_documents": document_validation.get('found_documents', [])
        },
        "summary": {
            "claim_id": claim_id,
            "insurance_type": insurance_type,
            "total_documents_required": document_validation.get('required_count'),
            "total_documents_uploaded": document_validation.get('uploaded_count'),
            "fraud_risk_level": "HIGH" if is_fraud else ("MEDIUM" if fraud_analysis.get('action') == 'INVESTIGATE' else "LOW"),
            "document_completeness": document_validation.get('completion_percentage'),
            "approval_status": final_decision
        }
    }

    # ── 2-STEP VERIFICATION ───────────────────────────────────────
    # action_AI    = what the AI decided
    # action_officer = REJECTED immediately if docs missing,
    #                  else PENDING (officer must review)
    final_report["action_AI"]      = final_decision
    final_report["action_officer"] = officer_action

    if auto_rejected_docs:
        log.warning("🚫 AUTO-REJECT — Final report locked")
        log.warning(f"   Claim ID     : {claim_id}")
        log.warning(f"   AI Decision  : REJECTED")
        log.warning(f"   Officer Action: REJECTED (auto — missing docs — no review needed)")
    else:
        log.info("━" * 56)
        log.info(f"📊 FINAL REPORT GENERATED")
        log.info(f"   Claim ID      : {claim_id}")
        log.info(f"   AI Decision   : {final_decision}")
        log.info(f"   Officer Action: PENDING")
        log.info(f"   Recommendation: {recommendation[:80]}")
        log.info("━" * 56)
    
    # Save to decisions.json
    save_decision_to_json(final_report, insurance_type, claim_id)

    return final_report


# ================================
# 7. CREATE VISUALIZATION GRAPHS
# ================================
def create_fraud_gauge(fraud_score, insurance_type):
    """Create fraud risk gauge chart"""

    fig = go.Figure()

    fig.add_trace(go.Indicator(
        mode="gauge+number+delta",
        value=fraud_score,
        title="Fraud Risk Score",
        delta={'reference': 30},
        gauge={
            'axis': {'range': [0, 100]},
            'bar': {'color': "darkblue"},
            'steps': [
                {'range': [0, 30], 'color': "lightgreen"},
                {'range': [30, 70], 'color': "yellow"},
                {'range': [70, 100], 'color': "lightcoral"}
            ],
            'threshold': {
                'line': {'color': "red", 'width': 4},
                'thickness': 0.75,
                'value': 70
            }
        }
    ))

    fig.update_layout(
        height=400,
        paper_bgcolor='#FFFFFF',
        plot_bgcolor='#F0F6FF',
        title_text=f"{insurance_type} - Fraud Risk Assessment",
        font=dict(color='#0A1628'),
    )

    return fig


def create_validation_bar_chart(validation_data):
    """Create document validation bar chart"""

    required = validation_data.get('required_count', 0)
    uploaded = validation_data.get('uploaded_count', 0)
    missing = required - uploaded if required >= uploaded else 0

    fig = go.Figure(data=[
        go.Bar(
            x=['Required', 'Uploaded', 'Missing'],
            y=[required, uploaded, missing],
            marker_color=['blue', 'green', 'red'],
            text=[required, uploaded, missing],
            textposition='auto'
        )
    ])

    fig.update_layout(
        title=f"Document Validation - {validation_data.get('insurance_type', 'Insurance')}",
        xaxis_title="Document Status",
        yaxis_title="Count",
        height=400
    )

    return fig


# ================================
# SAVE DECISION TO CENTRALIZED decisions.json ✅
# ================================
def save_decision_to_json(report, insurance_type, claim_id=None):
    """ 
    💾 Save final decision to centralized decisions.json file

    This is the PRIMARY method for storing decisions!
    Called automatically by generate_final_report().

    Args:
        report: Final report from generate_final_report()
        insurance_type: Type of insurance
        claim_id: Unique claim ID (auto-generated if None)

    Returns:
        dict: Saved decision record
    """
    try:
        os.makedirs("data", exist_ok=True)
        decisions_file = "data/decisions.json"

        # Generate claim ID if not provided
        if not claim_id:
            claim_id = f"CLM_{int(datetime.now().timestamp())}"

        # ── Determine officer action ─────────────────────────────
        # If auto-rejected due to missing docs, officer action = REJECTED
        # immediately. Otherwise officer still needs to review (PENDING).
        action_officer = report.get('action_officer', 'PENDING')
        auto_rejected  = report.get('auto_rejected', False)

        # Create decision record
        decision_record = {
            "claim_id":        claim_id,
            "timestamp":       datetime.now().isoformat(),
            "insurance_type":  insurance_type,
            "final_decision":  report.get('final_decision'),
            "action_AI":       report.get('action_AI', report.get('final_decision')),
            "action_officer":  action_officer,
            "auto_rejected":   auto_rejected,           # True = rejected due to missing docs
            "rejection_reason": report.get('rejection_reason'),  # Human-readable reason
            "recommendation":  report.get('recommendation'),
            "fraud_analysis": {
                "is_fraud": report['fraud_analysis'].get('is_fraud'),
                "verdict":  report['fraud_analysis'].get('verdict'),
                "reason":   report['fraud_analysis'].get('reason'),
                "action":   report['fraud_analysis'].get('action')
            },
            "document_validation": {
                "status":               report['document_validation'].get('status'),
                "uploaded_count":       report['document_validation'].get('uploaded_count'),
                "required_count":       report['document_validation'].get('required_count'),
                "completion_percentage":report['document_validation'].get('completion_percentage'),
                "missing_documents":    report['document_validation'].get('missing_documents', []),
                "found_documents":      report['document_validation'].get('found_documents', [])
            },
            "summary": report.get('summary')
        }

        # Load existing decisions or create new list
        if os.path.exists(decisions_file):
            with open(decisions_file, 'r') as f:
                try:
                    decisions = json.load(f)
                    if not isinstance(decisions, list):
                        decisions = [decisions]  # Convert to list if single object
                except json.JSONDecodeError:
                    decisions = []
        else:
            decisions = []

        # Append new decision
        decisions.append(decision_record)

        # Save back to file
        with open(decisions_file, 'w') as f:
            json.dump(decisions, f, indent=2)

        log.info("━" * 56)
        log.info(f"💾 DECISION SAVED TO decisions.json")
        log.info(f"   Claim ID      : {claim_id}")
        log.info(f"   Final Decision: {decision_record['final_decision']}")
        log.info(f"   Auto Rejected : {decision_record['auto_rejected']}")
        log.info(f"   Action AI     : {decision_record['action_AI']}")
        log.info(f"   Action Officer: {decision_record['action_officer']}")
        log.info(f"   Total records : {len(decisions)}")
        log.info(f"   File          : {decisions_file}")
        log.info("━" * 56)
        print(f"✅ Decision #{len(decisions)} stored: {claim_id}")
        return decision_record

    except Exception as e:
        log.error(f"❌ FAILED to save decision to decisions.json: {e}")
        print(f"❌ Error saving decision: {e}")
        return None


# ================================
# RETRIEVE DECISIONS FROM JSON
# ================================
def get_all_decisions(insurance_type=None):
    """
    Retrieve all decisions or filter by insurance type

    Args:
        insurance_type: Optional filter (e.g., 'car_insurance')

    Returns:
        list: Decision records
    """
    try:
        decisions_file = "data/decisions.json"

        if not os.path.exists(decisions_file):
            log.warning(f"[⚠️] No decisions file found: {decisions_file}")
            return []

        with open(decisions_file, 'r') as f:
            decisions = json.load(f)

        if insurance_type:
            decisions = [d for d in decisions if d.get('insurance_type') == insurance_type]

        log.info(f"📂 Retrieved {len(decisions)} decision(s) from decisions.json")
        return decisions

    except Exception as e:
        log.error(f"[ERROR] Failed to retrieve decisions: {e}")
        return []


# ================================
# LEGACY: SAVE REPORT TO INDIVIDUAL FILES
# ================================
def save_report_to_file(report, insurance_type, claim_id=None):
    """
    Save final report to individual timestamped JSON file (LEGACY)

    Note: Use save_decision_to_json() instead for centralized storage.
    decisions.json is now written automatically by generate_final_report().
    """
    try:
        os.makedirs("data/reports", exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        file_name = f"data/reports/claim_{claim_id or 'temp'}_{timestamp}.json"

        with open(file_name, 'w') as f:
            json.dump(report, f, indent=2)

        log.info(f"[OK] Report saved to {file_name}")
        return file_name

    except Exception as e:
        log.error(f"[ERROR] Failed to save report: {e}")
        return None


# ================================
# USAGE EXAMPLE
# ================================
if __name__ == "__main__":
    print("✅ Document Processor Module Loaded")
    print(f"📋 Supported Insurance Types: {list(DOCUMENT_REQUIREMENTS.keys())}")
    print(f"\n💾 Primary storage function: save_decision_to_json()")
    print(f"📂 Decisions stored in: data/decisions.json")
    print(f"\n🔁 generate_final_report() now auto-saves to decisions.json!")