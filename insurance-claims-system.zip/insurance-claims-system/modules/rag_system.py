# modules/rag_system.py
 
# -------------------------------
# RAG System for Insurance Claims
# WITH 2-STEP VERIFICATION
# (Preliminary analysis → Officer final approval)
# -------------------------------
 
import os
import sys
import logging
import json
import pandas as pd
import chromadb
from datetime import datetime
from dotenv import load_dotenv
 
# ════════════════════════════════════════════════════════════════
# LOGGING SETUP — Structured, Coloured, Multi-handler
# Outputs to:
#   logs/rag_system.log      — full INFO+ log (UTF-8, persistent)
#   logs/rag_errors.log      — ERROR+ only   (UTF-8, persistent)
#   stdout (terminal)        — coloured, human-readable
# ════════════════════════════════════════════════════════════════
os.makedirs("logs", exist_ok=True)

# ── ANSI colour codes for terminal output ───────────────────────
class _Colours:
    RESET   = "\033[0m"
    BOLD    = "\033[1m"
    GREY    = "\033[38;5;240m"
    CYAN    = "\033[36m"
    GREEN   = "\033[32m"
    YELLOW  = "\033[33m"
    RED     = "\033[31m"
    MAGENTA = "\033[35m"
    BG_RED  = "\033[41m"

_LEVEL_COLOURS = {
    "DEBUG"    : _Colours.GREY,
    "INFO"     : _Colours.CYAN,
    "WARNING"  : _Colours.YELLOW,
    "ERROR"    : _Colours.RED,
    "CRITICAL" : _Colours.BG_RED + _Colours.BOLD,
}

# ── Custom formatter: coloured for terminal, plain for files ─────
class _ColourFormatter(logging.Formatter):
    """Apply ANSI colours per log level for terminal readability."""
    FILE_FMT    = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
    CONSOLE_FMT = "{bold}%(asctime)s{reset} | {lc}%(levelname)-8s{reset} | {cyan}%(name)s{reset} | %(message)s"

    def __init__(self, use_colour: bool = False):
        super().__init__()
        self.use_colour = use_colour

    def format(self, record: logging.LogRecord) -> str:
        lc   = _LEVEL_COLOURS.get(record.levelname, "")
        fmt  = (
            self.CONSOLE_FMT.format(
                bold=_Colours.BOLD, reset=_Colours.RESET,
                lc=lc, cyan=_Colours.CYAN
            )
            if self.use_colour else self.FILE_FMT
        )
        formatter = logging.Formatter(fmt, datefmt="%Y-%m-%d %H:%M:%S")
        return formatter.format(record)

# ── Section banner helper (printed to terminal only) ─────────────
def _log_banner(title: str, width: int = 60) -> None:
    """Print a visible section banner to stdout."""
    bar = "═" * width
    print(f"\n{_Colours.CYAN}{_Colours.BOLD}{bar}{_Colours.RESET}")
    print(f"{_Colours.CYAN}{_Colours.BOLD}  {title}{_Colours.RESET}")
    print(f"{_Colours.CYAN}{_Colours.BOLD}{bar}{_Colours.RESET}\n")

# ── Build handlers ───────────────────────────────────────────────
def _build_logger(name: str) -> logging.Logger:
    """
    Build and return a named logger with three handlers:
      1. rag_system.log   — INFO+  (all events)
      2. rag_errors.log   — ERROR+ (failures only)
      3. stdout           — INFO+  (coloured terminal)
    """
    logger = logging.getLogger(name)
    if logger.handlers:          # avoid duplicate handlers on reload
        return logger
    logger.setLevel(logging.DEBUG)

    # ① Full log — INFO and above
    fh_all = logging.FileHandler("logs/rag_system.log", encoding="utf-8")
    fh_all.setLevel(logging.INFO)
    fh_all.setFormatter(_ColourFormatter(use_colour=False))

    # ② Error log — ERROR and above only
    fh_err = logging.FileHandler("logs/rag_errors.log", encoding="utf-8")
    fh_err.setLevel(logging.ERROR)
    fh_err.setFormatter(_ColourFormatter(use_colour=False))

    # ③ Terminal — INFO and above, coloured
    sh = logging.StreamHandler(stream=sys.stdout)
    sh.setLevel(logging.INFO)
    try:
        sh.stream.reconfigure(encoding="utf-8", errors="replace")
    except AttributeError:
        pass   # Python < 3.7 fallback
    sh.setFormatter(_ColourFormatter(use_colour=True))

    logger.addHandler(fh_all)
    logger.addHandler(fh_err)
    logger.addHandler(sh)
    logger.propagate = False
    return logger

log = _build_logger(__name__)
_log_banner("RAG SYSTEM — InsureAI  |  2-Step Verification")
 
 
# --------------------------------
# Load Environment Variables
# --------------------------------
load_dotenv()
API_KEY = os.getenv("GROQ_API_KEY")
 
 
# --------------------------------
# Initialize Groq Client
# --------------------------------
client = None
CLIENT_INIT_ERROR = None
 
try:
    from groq import Groq
    if not API_KEY:
        raise RuntimeError("GROQ_API_KEY is missing in .env file.")
    client = Groq(api_key=API_KEY)
    log.info("✅ Groq client initialised — model: llama-3.3-70b-versatile")
except Exception as e:
    CLIENT_INIT_ERROR = e
    client = None
    log.error(f"❌ Groq client FAILED to initialise: {e}")
    log.error("   Fix: check GROQ_API_KEY in .env and run: pip install groq")
 
 
def _require_client():
    """Raise a clear error if Groq client is not ready."""
    if client is None:
        log.error("[ERROR] Groq client is not available.")
        raise RuntimeError(
            f"Groq client not initialized.\n"
            f"Fix: Check GROQ_API_KEY in .env and run: pip install groq\n"
            f"Cause: {CLIENT_INIT_ERROR!r}"
        )
 
 
# --------------------------------
# ChromaDB Setup
# --------------------------------
try:
    os.makedirs("data/chroma", exist_ok=True)
    chroma_client     = chromadb.PersistentClient(path="data/chroma")
    policy_collection = chroma_client.get_or_create_collection(name="policy_clauses")
    fraud_collection  = chroma_client.get_or_create_collection(name="fraud_cases")
    claims_collection = chroma_client.get_or_create_collection(name="similar_claims")
    log.info("✅ ChromaDB collections ready — policy_clauses | fraud_cases | similar_claims")
except Exception as e:
    log.critical(f"💀 ChromaDB CRITICAL FAILURE — cannot start: {e}")
    raise
 
 
# --------------------------------
# Load CSV Data into ChromaDB
# --------------------------------
def load_datasets(clear_before_load: bool = False):
    """
    Load CSV files into ChromaDB.
    - Skips if already populated (prevents duplicates).
    - Pass clear_before_load=True to force a fresh reload.
    """
    try:
        if clear_before_load:
            log.info("[RESET] Clearing existing ChromaDB collections...")
            policy_collection.delete(where={})
            fraud_collection.delete(where={})
            claims_collection.delete(where={})
            log.info("[OK] Collections cleared.")
 
        elif (policy_collection.count() > 0 or
              fraud_collection.count() > 0 or
              claims_collection.count() > 0):
            log.info("⏭  ChromaDB already populated — skipping CSV reload")
            return
 
        # --- Validate CSV files exist ---
        required_files = [
            "data/policy_clauses.csv",
            "data/fraud_cases.csv",
            "data/similar_claims.csv"
        ]
        for f in required_files:
            if not os.path.exists(f):
                raise FileNotFoundError(f"Required file missing: {f}")
 
        # --- Load CSVs ---
        policy_df = pd.read_csv("data/policy_clauses.csv")
        fraud_df  = pd.read_csv("data/fraud_cases.csv")
        claims_df = pd.read_csv("data/similar_claims.csv")
 
        log.info(f"[DATA] Loaded CSVs - policy: {len(policy_df)} rows | "
                 f"fraud: {len(fraud_df)} rows | claims: {len(claims_df)} rows")
 
        # --- Insert into ChromaDB ---
        for i, row in policy_df.iterrows():
            policy_collection.add(
                documents=[str(row.get("clause_description", ""))],
                ids=[f"policy_{i}"],
                metadatas=[{"source": "policy_clauses.csv",
                            **{k: str(row[k]) for k in row.index if k != "clause_description"}}],
            )
 
        for i, row in fraud_df.iterrows():
            fraud_collection.add(
                documents=[str(row.get("case_description", ""))],
                ids=[f"fraud_{i}"],
                metadatas=[{"source": "fraud_cases.csv",
                            **{k: str(row[k]) for k in row.index if k != "case_description"}}],
            )
 
        for i, row in claims_df.iterrows():
            claims_collection.add(
                documents=[str(row.get("claim_description", ""))],
                ids=[f"claim_{i}"],
                metadatas=[{"source": "similar_claims.csv",
                            **{k: str(row[k]) for k in row.index if k != "claim_description"}}],
            )
 
        log.info("[OK] All datasets loaded into ChromaDB successfully.")
 
    except FileNotFoundError as e:
        log.error(f"[ERROR] Missing CSV file: {e}")
        raise
    except Exception as e:
        log.error(f"[ERROR] Failed to load datasets: {e}")
        raise
 
 
# --------------------------------
# Internal Search Helper
# --------------------------------
def _query(collection, query: str, n: int) -> list:
    """Run ChromaDB similarity search. Returns matched documents."""
    try:
        if not query or not query.strip():
            raise ValueError("Search query cannot be empty.")
        results = collection.query(query_texts=[query], n_results=n)
        docs = (results or {}).get("documents", [[]])[0]
        log.info(f"[SEARCH] '{collection.name}' -> {len(docs)} result(s).")
        return docs
    except Exception as e:
        log.error(f"[ERROR] ChromaDB search failed on '{collection.name}': {e}")
        return []   # return empty so app does not crash
 
 
def _search_policy_clauses(query: str, n: int = 3) -> list:
    return _query(policy_collection, query, n)
 
def _search_fraud_cases(query: str, n: int = 2) -> list:
    return _query(fraud_collection, query, n)
 
def _search_similar_claims(query: str, n: int = 3) -> list:
    return _query(claims_collection, query, n)
 
 
# --------------------------------
# Analyze Claim - Fraud Detection
# (SAME AS BEFORE - No changes)
# --------------------------------
def analyze_claim(claim_description: str) -> dict:
    """
    Analyzes a claim and detects fraud.
 
    Returns dict:
      - is_fraud  : True or False
      - verdict   : "FRAUD" or "GENUINE"
      - reason    : Why it is fraud or genuine
      - action    : APPROVE / REJECT / INVESTIGATE
      - raw       : Full AI response text
      - error     : Error message if something failed (else None)
    """
 
    # --- Default error result ---
    error_result = {
        "is_fraud" : None,
        "verdict"  : None,
        "reason"   : None,
        "action"   : None,
        "raw"      : None,
        "error"    : None
    }
 
    # --- Input validation ---
    if not claim_description or not claim_description.strip():
        log.warning("[WARN] analyze_claim() called with empty description.")
        error_result["error"] = "Claim description cannot be empty."
        return error_result
 
    try:
        _require_client()
 
        log.info("━" * 56)
        log.info(f"🔍 FRAUD ANALYSIS STARTED")
        log.info(f"   Description : {claim_description[:80]}...")
 
        clauses        = _search_policy_clauses(claim_description)
        fraud_cases    = _search_fraud_cases(claim_description)
        similar_claims = _search_similar_claims(claim_description)
 
        prompt = f"""
You are a senior insurance fraud detection expert.
 
Analyze this insurance claim and decide clearly: is it FRAUD or GENUINE?
 
Claim:
"{claim_description}"
 
Relevant Policy Clauses:
{clauses}
 
Similar Past Claims:
{similar_claims}
 
Known Fraud Examples:
{fraud_cases}
 
---
 
Decide FRAUD if any of these are true:
- Claim is too vague (missing date, location, or basic details)
- No police report mentioned for accidents
- No supporting documents mentioned
- Story is logically inconsistent or impossible
- Asking for full/maximum amount without proof
- Damage is exaggerated beyond reason
 
Decide GENUINE if all of these are true:
- Has specific date, time, and location
- Mentions police report or witnesses
- Has repair estimate, medical records, or photos
- Story is clear and logically consistent
- Claim amount is reasonable
 
Respond in EXACTLY this format, nothing else:
 
VERDICT: FRAUD or GENUINE
REASON: explain in 1-2 lines exactly why
ACTION: APPROVE or REJECT or INVESTIGATE
IS_FRAUD: true or false
"""
 
        response = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[{"role": "user", "content": prompt}]
        )
 
        raw = response.choices[0].message.content.strip()
        log.info("🤖 AI Response received:")
        for _line in raw.splitlines():
            log.info(f"   {_line}")
 
        # --- Parse result ---
        result = {
            "is_fraud" : None,
            "verdict"  : None,
            "reason"   : None,
            "action"   : None,
            "raw"      : raw,
            "error"    : None
        }
 
        for line in raw.splitlines():
            line = line.strip()
            if line.startswith("VERDICT:"):
                val = line.split(":", 1)[1].strip().upper()
                result["verdict"]  = val
                result["is_fraud"] = "FRAUD" in val
            elif line.startswith("REASON:"):
                result["reason"]   = line.split(":", 1)[1].strip()
            elif line.startswith("ACTION:"):
                result["action"]   = line.split(":", 1)[1].strip()
            elif line.startswith("IS_FRAUD:"):
                result["is_fraud"] = "true" in line.split(":", 1)[1].strip().lower()
 
        # --- Validate parsed result ---
        if result["verdict"] is None:
            log.warning("[WARN] AI response did not follow expected format.")
            result["error"] = "AI response format was unexpected. Check raw field."
 
        log.info(f"✅ FRAUD ANALYSIS COMPLETE")
        log.info(f"   Verdict  : {result['verdict']}")
        log.info(f"   Is Fraud : {result['is_fraud']}")
        log.info(f"   Action   : {result['action']}")
        log.info(f"   Reason   : {result.get('reason','—')}")
        log.info("━" * 56)
 
        return result
 
    except RuntimeError as e:
        log.error(f"[ERROR] Client error in analyze_claim(): {e}")
        error_result["error"] = str(e)
        return error_result
    except Exception as e:
        log.error(f"[ERROR] Unexpected error in analyze_claim(): {e}")
        error_result["error"] = f"Unexpected error: {str(e)}"
        return error_result
 
 
# ════════════════════════════════════════════════════════════════
# ✨ NEW: 2-STEP VERIFICATION FUNCTIONS
# ════════════════════════════════════════════════════════════════

def save_preliminary_decision(claim_id, user_id, fraud_analysis, document_validation, final_report):
    """
    Save preliminary claim analysis to decisions.json
    Status: "Pending Officer Review"
    Officer will make final approval/rejection decision.
    
    Args:
        claim_id: Claim ID
        user_id: User ID
        fraud_analysis: Result from analyze_claim()
        document_validation: Result from validate_documents()
        final_report: Result from generate_final_report()
    
    Returns:
        bool: True if saved successfully, False otherwise
    """
    try:
        log.info("━" * 56)
        log.info(f"💾 SAVING PRELIMINARY DECISION")
        log.info(f"   Claim ID : {claim_id}")
        log.info(f"   User  ID : {user_id}")
        os.makedirs("data", exist_ok=True)
        decisions_file = "data/decisions.json"
        
        # Load existing decisions
        if os.path.exists(decisions_file):
            with open(decisions_file, "r") as f:
                decisions = json.load(f)
        else:
            decisions = []
        
        # ── Determine status: auto-reject if docs are missing ───────
        # When documents are incomplete, the claim is rejected immediately
        # by the AI — no officer review is required or allowed.
        missing_docs   = document_validation.get("missing_documents", [])
        docs_complete  = document_validation.get("valid", False)
        auto_rejected  = not docs_complete
        final_dec_val  = final_report.get("final_decision", "REJECTED")

        if auto_rejected:
            record_status  = "Auto-Rejected: Missing Documents"
            officer_action = "REJECTED"
            missing_list   = ', '.join(missing_docs) if missing_docs else 'required documents'
            rejection_note = (
                f"Automatically rejected by AI — {len(missing_docs)} required "
                f"document(s) not uploaded: {missing_list}."
            )
            log.warning("🚫 AUTO-REJECT TRIGGERED")
            log.warning(f"   Claim ID      : {claim_id}")
            log.warning(f"   Missing Docs  : {missing_list}")
            log.warning(f"   Action        : REJECTED immediately (no officer review)")
        else:
            record_status  = "Pending Officer Review"
            officer_action = "PENDING"
            rejection_note = final_report.get("rejection_reason")

        # Create preliminary decision record
        preliminary_decision = {
            "decision_id":    f"DEC{str(user_id)[:8].upper()}_{int(datetime.now().timestamp())}",
            "claim_id":       claim_id,
            "user_id":        user_id,
            "officer_id":     None if not auto_rejected else "AI_AUTO_REJECT",
            "status":         record_status,
            "auto_rejected":  auto_rejected,
            "rejection_reason": rejection_note,
            "ai_analysis": {
                "fraud_verdict": fraud_analysis.get("verdict"),
                "is_fraud":      fraud_analysis.get("is_fraud"),
                "fraud_reason":  fraud_analysis.get("reason"),
                "ai_suggestion": fraud_analysis.get("action")
            },
            "document_validation": {
                "uploaded_count":       document_validation.get("uploaded_count"),
                "required_count":       document_validation.get("required_count"),
                "completion_percentage":document_validation.get("completion_percentage"),
                "found_documents":      document_validation.get("found_documents", []),
                "missing_documents":    missing_docs
            },
            "final_report": {
                "final_decision": final_dec_val,
                "recommendation": final_report.get("recommendation"),
                "rejection_reason": rejection_note
            },
            "submission_date":      datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "officer_decision_date":datetime.now().strftime("%Y-%m-%d %H:%M:%S") if auto_rejected else None,
            "officer_comments":     rejection_note if auto_rejected else "",
            "action_AI":      final_dec_val,
            "action_officer": officer_action,   # REJECTED immediately if docs missing
            "final_decision": final_dec_val if auto_rejected else None
        }
        
        # Add to decisions list
        decisions.append(preliminary_decision)
        
        # Save back to file
        with open(decisions_file, "w") as f:
            json.dump(decisions, f, indent=4)
        
        log.info(f"✅ Preliminary decision saved")
        log.info(f"   Decision ID : {preliminary_decision['decision_id']}")
        log.info(f"   Status      : {preliminary_decision['status']}")
        log.info(f"   Action AI   : {preliminary_decision['action_AI']}")
        log.info(f"   Action Off. : {preliminary_decision['action_officer']}")
        log.info("━" * 56)
        return True
        
    except Exception as e:
        log.error(f"[ERROR] Failed to save preliminary decision: {e}")
        return False


def get_pending_claims_for_officer():
    """
    Retrieve all pending claims for officer review.
    Returns list of decisions with status "Pending Officer Review"
    """
    try:
        decisions_file = "data/decisions.json"
        
        if not os.path.exists(decisions_file):
            log.info("[INFO] No decisions file found. No pending claims.")
            return []
        
        with open(decisions_file, "r") as f:
            all_decisions = json.load(f)
        
        # Filter for pending claims — exclude auto-rejected (missing doc) claims
        # Auto-rejected claims are already finalized and need no officer action.
        pending = [
            d for d in all_decisions
            if d.get("status") == "Pending Officer Review"
            and not d.get("auto_rejected", False)
        ]

        auto_rej_count = sum(1 for d in all_decisions if d.get("auto_rejected", False))
        log.info(f"📋 OFFICER QUEUE LOADED")
        log.info(f"   Pending review  : {len(pending)}")
        log.info(f"   Auto-rejected   : {auto_rej_count}  (missing docs — excluded)")
        return pending
        
    except Exception as e:
        log.error(f"[ERROR] Failed to retrieve pending claims: {e}")
        return []


def get_auto_rejected_claims():
    """
    Retrieve all claims that were automatically rejected by the AI
    due to missing/incomplete documents.

    These are FINAL rejections — no officer action is needed or allowed.
    They are shown in the officer dashboard as read-only entries.

    Returns:
        list: Auto-rejected decision records
    """
    try:
        decisions_file = "data/decisions.json"

        if not os.path.exists(decisions_file):
            log.info("[INFO] No decisions file found. No auto-rejected claims.")
            return []

        with open(decisions_file, "r") as f:
            all_decisions = json.load(f)

        auto_rejected = [
            d for d in all_decisions
            if d.get("auto_rejected", False) is True
            or d.get("status", "").startswith("Auto-Rejected")
        ]

        log.info(f"🚫 AUTO-REJECTED CLAIMS LOADED")
        log.info(f"   Count : {len(auto_rejected)} claim(s) rejected due to missing documents")
        return auto_rejected

    except Exception as e:
        log.error(f"[ERROR] Failed to retrieve auto-rejected claims: {e}")
        return []


def save_officer_final_decision(decision_id, officer_id, final_decision, comments=""):
    """
    Save officer's final approval/rejection decision.
    
    Args:
        decision_id: The preliminary decision ID
        officer_id: Officer's user ID
        final_decision: "Approved" or "Rejected" or "More Info Needed"
        comments: Officer's comments
    
    Returns:
        bool: True if saved successfully
    """
    try:
        log.info("━" * 56)
        log.info(f"👔 OFFICER FINAL DECISION RECEIVED")
        log.info(f"   Decision ID : {decision_id}")
        log.info(f"   Officer ID  : {officer_id}")
        log.info(f"   Decision    : {final_decision}")
        log.info(f"   Comments    : {comments[:80] if comments else '—'}")
        decisions_file = "data/decisions.json"

        if not os.path.exists(decisions_file):
            log.error("❌ decisions.json not found — cannot save officer decision")
            return False

        with open(decisions_file, "r") as f:
            decisions = json.load(f)

        # Find and update the decision
        for decision in decisions:
            if decision["decision_id"] == decision_id:
                decision["status"] = final_decision  # APPROVED / REJECTED / More Info Needed
                decision["officer_id"] = officer_id
                decision["officer_comments"] = comments
                decision["officer_decision_date"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                decision["final_decision"] = final_decision
                
                with open(decisions_file, "w") as f:
                    json.dump(decisions, f, indent=4)
                
                log.info(f"✅ Officer decision saved")
                log.info(f"   {decision_id}  →  {final_decision}")
                log.info("━" * 56)
                return True
        
        log.error(f"[ERROR] Decision {decision_id} not found")
        return False
        
    except Exception as e:
        log.error(f"[ERROR] Failed to save officer decision: {e}")
        return False
 
 
# --------------------------------
# Customer Chatbot Response
# (SAME AS BEFORE - No changes)
# --------------------------------
def generate_chatbot_response(user_question: str) -> str:
    """
    Answers customer insurance questions using
    relevant policy clauses as context.
    Returns answer string or error message string.
    """
    if not user_question or not user_question.strip():
        log.warning("[WARN] generate_chatbot_response() called with empty question.")
        return "Please enter a valid question."
 
    try:
        _require_client()
 
        log.info(f"[CHAT] Question: '{user_question[:80]}'")
 
        clauses = _search_policy_clauses(user_question)
 
        prompt = f"""
You are a helpful insurance assistant.
Use the policy clauses below to answer the customer's question clearly and simply.
 
Policy Clauses:
{clauses}
 
Customer Question:
{user_question}
"""
 
        response = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[{"role": "user", "content": prompt}]
        )
 
        answer = response.choices[0].message.content.strip()
        log.info("[OK] Chatbot response generated successfully.")
        return answer
 
    except RuntimeError as e:
        log.error(f"[ERROR] Client error in generate_chatbot_response(): {e}")
        return f"Service unavailable: {str(e)}"
    except Exception as e:
        log.error(f"[ERROR] Unexpected error in generate_chatbot_response(): {e}")
        return "Something went wrong. Please try again later."
 
 
# --------------------------------
# Startup - Seed data if empty
# --------------------------------
if __name__ == "__main__":
    load_datasets(clear_before_load=False)
    print("[OK] Datasets loaded into ChromaDB at data/chroma/")