"""
data_handler.py - UPDATED WITH AUTHENTICATION
Member 1 - Backend Data Layer
Handles all JSON read/write operations for:
    - users.json (with password)
    - policies.json
    - claims.json
    - decisions.json
"""

import json
import os
from datetime import datetime
from uuid import uuid4
import hashlib

# ════════════════════════════════════════════════════════════════════
# FILE PATHS — Central place to manage all data file locations
# ════════════════════════════════════════════════════════════════════

USERS_FILE     = "data/users.json"
POLICIES_FILE  = "data/policies.json"
CLAIMS_FILE    = "data/claims.json"
DECISIONS_FILE = "data/decisions.json"


# ════════════════════════════════════════════════════════════════════
# CORE HELPERS — Read & Write JSON safely
# ════════════════════════════════════════════════════════════════════

def load_json(file_path):
    """Read a JSON file and return its contents as a Python list."""
    if not os.path.exists(file_path):
        return []
    try:
        with open(file_path, "r") as f:
            content = f.read().strip()
            if not content:
                return []
            return json.loads(content)
    except (json.JSONDecodeError, IOError):
        return []


def save_json(file_path, data):
    """Write a Python list/dict to a JSON file."""
    try:
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        with open(file_path, "w") as f:
            json.dump(data, f, indent=4)
        return True
    except IOError as e:
        print(f"ERROR saving {file_path}: {e}")
        return False


def initialize_files():
    """Create all required JSON files with empty lists if they don't exist."""
    for file_path in [USERS_FILE, POLICIES_FILE, CLAIMS_FILE, DECISIONS_FILE]:
        if not os.path.exists(file_path):
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            save_json(file_path, [])
            print(f"✅ Created: {file_path}")
        else:
            print(f"✔️  Already exists: {file_path}")


# ════════════════════════════════════════════════════════════════════
# AUTHENTICATION — LOGIN FUNCTIONS (BOTH NAMES SUPPORTED)
# ════════════════════════════════════════════════════════════════════

def authenticate_user(email, password):
    """
    Authenticate user for login.
    
    Args:
        email (str): User email
        password (str): User password
    
    Returns:
        dict: User record if credentials match
        None: If email not found or password incorrect
    """
    users = load_json(USERS_FILE)
    for user in users:
        if user["email"].lower() == email.strip().lower():
            if user.get("password") == hash_password(password):
                return user
            else:
                return None  # Wrong password
    return None  # Email not found


def login_user(email, password):
    """
    Alias for authenticate_user() - same functionality
    For backward compatibility and alternative naming.
    
    Args:
        email (str): User email
        password (str): User password
    
    Returns:
        dict: User record if credentials match
        None: If email not found or password incorrect
    """
    return authenticate_user(email, password)


# ════════════════════════════════════════════════════════════════════
# USER MANAGEMENT — users.json (UPDATED WITH PASSWORD)
# ════════════════════════════════════════════════════════════════════

"""
data_handler.py - UPDATED WITH AUTHENTICATION
Member 1 - Backend Data Layer
Handles all JSON read/write operations for:
    - users.json (with password)
    - policies.json
    - claims.json
    - decisions.json
"""

import json
import os
from datetime import datetime
from uuid import uuid4

# ════════════════════════════════════════════════════════════════════
# FILE PATHS — Central place to manage all data file locations
# ════════════════════════════════════════════════════════════════════

USERS_FILE     = "data/users.json"
POLICIES_FILE  = "data/policies.json"
CLAIMS_FILE    = "data/claims.json"
DECISIONS_FILE = "data/decisions.json"


# ════════════════════════════════════════════════════════════════════
# CORE HELPERS — Read & Write JSON safely
# ════════════════════════════════════════════════════════════════════

def load_json(file_path):
    """Read a JSON file and return its contents as a Python list."""
    if not os.path.exists(file_path):
        return []
    try:
        with open(file_path, "r") as f:
            content = f.read().strip()
            if not content:
                return []
            return json.loads(content)
    except (json.JSONDecodeError, IOError):
        return []


def save_json(file_path, data):
    """Write a Python list/dict to a JSON file."""
    try:
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        with open(file_path, "w") as f:
            json.dump(data, f, indent=4)
        return True
    except IOError as e:
        print(f"ERROR saving {file_path}: {e}")
        return False


def initialize_files():
    """Create all required JSON files with empty lists if they don't exist."""
    for file_path in [USERS_FILE, POLICIES_FILE, CLAIMS_FILE, DECISIONS_FILE]:
        if not os.path.exists(file_path):
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            save_json(file_path, [])
            print(f"✅ Created: {file_path}")
        else:
            print(f"✔️  Already exists: {file_path}")


# ════════════════════════════════════════════════════════════════════
# AUTHENTICATION — LOGIN FUNCTIONS (BOTH NAMES SUPPORTED)
# ════════════════════════════════════════════════════════════════════

def authenticate_user(email, password):
    """
    Authenticate user for login.
    
    Args:
        email (str): User email
        password (str): User password
    
    Returns:
        dict: User record if credentials match
        None: If email not found or password incorrect
    """
    users = load_json(USERS_FILE)
    for user in users:
        if user["email"].lower() == email.strip().lower():
            if user.get("password") == password:
                return user
            else:
                return None  # Wrong password
    return None  # Email not found


def login_user(email, password):
    """
    Alias for authenticate_user() - same functionality
    For backward compatibility and alternative naming.
    
    Args:
        email (str): User email
        password (str): User password
    
    Returns:
        dict: User record if credentials match
        None: If email not found or password incorrect
    """
    return authenticate_user(email, password)


# ════════════════════════════════════════════════════════════════════
# USER MANAGEMENT — users.json (UPDATED WITH PASSWORD)
# ════════════════════════════════════════════════════════════════════

def hash_password(password):
    """Hash password using SHA256"""
    return hashlib.sha256(password.encode()).hexdigest()


def register_user(name, email, password, phone, role="customer"):
    """
    Register a new user (customer or officer) and save to users.json.
    The role is selected by the user; no secret key is required.

    Args:
        name (str): Full name
        email (str): Email
        password (str): Password
        phone (str): Phone number
        role (str): "customer" or "officer" (default: "customer")

    Returns:
        dict: Newly created user record
        None: If email already exists or validation fails
    """

    # Basic validation
    if not name or not email or not password or not phone:
        print("ERROR: Name, email, password and phone are required.")
        return None

    if len(password) < 4:
        print("ERROR: Password must be at least 4 characters.")
        return None

    users = load_json(USERS_FILE)

    # Check if email already registered
    for user in users:
        if user["email"].lower() == email.lower():
            print(f"ERROR: Email {email} already registered.")
            return None

    # Validate role
    role = role.lower()
    if role not in ["customer", "officer"]:
        role = "customer"  # default fallback

    # Create new user record
    new_user = {
        "user_id": "U" + str(uuid4())[:8].upper(),
        "name": name.strip(),
        "email": email.strip().lower(),
        "password": password,
        "phone": phone.strip(),
        "role": role,
        "date_joined": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }

    users.append(new_user)
    save_json(USERS_FILE, users)
    print(f"✅ User registered: {new_user['user_id']} — {new_user['name']} ({new_user['role']})")
    return new_user


def get_user_by_id(user_id):
    """Fetch a user record by their user_id."""
    users = load_json(USERS_FILE)
    for user in users:
        if user["user_id"] == user_id:
            return user
    return None


def get_user_by_email(email):
    """Fetch a user record by their email."""
    users = load_json(USERS_FILE)
    for user in users:
        if user["email"].lower() == email.strip().lower():
            return user
    return None


def get_all_users():
    """Return all registered users."""
    return load_json(USERS_FILE)


# ════════════════════════════════════════════════════════════════════
# POLICY MANAGEMENT — policies.json
# ════════════════════════════════════════════════════════════════════

AVAILABLE_POLICIES = [
    {
        "policy_type"     : "Car Insurance",
        "coverage_amount" : 50000,
        "premium_amount"  : 500,
        "description"     : "Covers accidents, collisions and third-party damage."
    },
    {
        "policy_type"     : "Health Insurance",
        "coverage_amount" : 100000,
        "premium_amount"  : 800,
        "description"     : "Covers hospitalization, emergency care and surgery."
    },
    {
        "policy_type"     : "Travel Insurance",
        "coverage_amount" : 5000,
        "premium_amount"  : 200,
        "description"     : "Covers trip cancellation, baggage loss and medical emergencies abroad."
    },
    {
        "policy_type"     : "Home Insurance",
        "coverage_amount" : 75000,
        "premium_amount"  : 600,
        "description"     : "Covers property damage, theft and natural disasters."
    }
]


def get_available_policies():
    """Return the list of insurance policies available for purchase."""
    return AVAILABLE_POLICIES


def buy_policy(user_id, policy_type):
    """Purchase an insurance policy for a user and save to policies.json."""
    
    if not get_user_by_id(user_id):
        print(f"ERROR: User {user_id} not found.")
        return None

    policy_template = None
    for p in AVAILABLE_POLICIES:
        if p["policy_type"].lower() == policy_type.lower():
            policy_template = p
            break

    if not policy_template:
        print(f"ERROR: Policy type '{policy_type}' not available.")
        return None

    policies = load_json(POLICIES_FILE)

    new_policy = {
        "policy_id"      : "POL" + str(uuid4())[:8].upper(),
        "user_id"        : user_id,
        "policy_type"    : policy_template["policy_type"],
        "coverage_amount": policy_template["coverage_amount"],
        "premium_amount" : policy_template["premium_amount"],
        "purchase_date"  : datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "status"         : "Active"
    }

    policies.append(new_policy)
    save_json(POLICIES_FILE, policies)
    print(f"✅ Policy purchased: {new_policy['policy_id']} — {new_policy['policy_type']}")
    return new_policy


def get_user_policies(user_id):
    """Get all insurance policies purchased by a specific user."""
    policies = load_json(POLICIES_FILE)
    return [p for p in policies if p["user_id"] == user_id]


def get_policy_by_id(policy_id):
    """Fetch a specific policy by its policy_id."""
    policies = load_json(POLICIES_FILE)
    for policy in policies:
        if policy["policy_id"] == policy_id:
            return policy
    return None


# ════════════════════════════════════════════════════════════════════
# CLAIM MANAGEMENT — claims.json
# ════════════════════════════════════════════════════════════════════

def submit_claim(user_id, policy_id, description, documents=None):
    """File a new insurance claim and save to claims.json."""
    
    if not description or not description.strip():
        print("ERROR: Claim description is required.")
        return None

    if not get_user_by_id(user_id):
        print(f"ERROR: User {user_id} not found.")
        return None

    if not get_policy_by_id(policy_id):
        print(f"ERROR: Policy {policy_id} not found.")
        return None

    claims = load_json(CLAIMS_FILE)

    new_claim = {
        "claim_id"         : "CLM" + str(uuid4())[:8].upper(),
        "user_id"          : user_id,
        "policy_id"        : policy_id,
        "claim_description": description.strip(),
        "documents"        : documents if documents else [],
        "submission_date"  : datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "status"           : "Pending Review"
    }

    claims.append(new_claim)
    save_json(CLAIMS_FILE, claims)
    print(f"✅ Claim submitted: {new_claim['claim_id']}")
    return new_claim


def get_claim_by_id(claim_id):
    """Fetch a specific claim by its claim_id."""
    claims = load_json(CLAIMS_FILE)
    for claim in claims:
        if claim["claim_id"] == claim_id:
            return claim
    return None


def get_user_claims(user_id):
    """Get all claims filed by a specific user."""
    claims = load_json(CLAIMS_FILE)
    return [c for c in claims if c["user_id"] == user_id]


def get_pending_claims():
    """Get all claims with status 'Pending Review'."""
    claims = load_json(CLAIMS_FILE)
    return [c for c in claims if c["status"] == "Pending Review"]


def get_all_claims():
    """Return every claim in the system."""
    return load_json(CLAIMS_FILE)


def update_claim_status(claim_id, new_status):
    """Update the status of a claim."""
    valid_statuses = ["Pending Review", "Approved", "Rejected", "More Info Needed"]
    if new_status not in valid_statuses:
        print(f"ERROR: Invalid status '{new_status}'.")
        return False

    claims = load_json(CLAIMS_FILE)
    updated = False

    for claim in claims:
        if claim["claim_id"] == claim_id:
            claim["status"] = new_status
            claim["last_updated"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            updated = True
            break

    if updated:
        save_json(CLAIMS_FILE, claims)
        print(f"✅ Claim {claim_id} status updated to: {new_status}")
    else:
        print(f"ERROR: Claim {claim_id} not found.")

    return updated


# ════════════════════════════════════════════════════════════════════
# DECISION MANAGEMENT — decisions.json
# ════════════════════════════════════════════════════════════════════

def save_decision(claim_id, officer_id, decision, comments, ai_suggestion=""):
    """Save an officer's decision on a claim."""
    
    if not get_claim_by_id(claim_id):
        print(f"ERROR: Claim {claim_id} not found.")
        return None

    decisions = load_json(DECISIONS_FILE)

    new_decision = {
        "decision_id"  : "DEC" + str(uuid4())[:8].upper(),
        "claim_id"     : claim_id,
        "officer_id"   : officer_id,
        "decision"     : decision,
        "comments"     : comments.strip() if comments else "",
        "ai_suggestion": ai_suggestion,
        "decision_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }

    decisions.append(new_decision)
    save_json(DECISIONS_FILE, decisions)

    update_claim_status(claim_id, decision)

    print(f"✅ Decision saved: {new_decision['decision_id']} — {decision}")
    return new_decision


def get_decision_by_claim(claim_id):
    """Get the officer's decision for a specific claim."""
    decisions = load_json(DECISIONS_FILE)
    for decision in decisions:
        if decision["claim_id"] == claim_id:
            return decision
    return None


def get_all_decisions():
    """Return all officer decisions."""
    return load_json(DECISIONS_FILE)
    """
    Register a new customer and save to users.json.

    Args:
        name (str): Customer full name
        email (str): Customer email
        password (str): Customer password
        phone (str): Customer phone number

    Returns:
        dict: Newly created user record
        None: If email already exists or validation fails
    """
    # Basic validation
    if not name or not email or not password or not phone:
        print("ERROR: Name, email, password and phone are required.")
        return None

    if len(password) < 4:
        print("ERROR: Password must be at least 4 characters.")
        return None

    users = load_json(USERS_FILE)

    # Check if email already registered
    for user in users:
        if user["email"].lower() == email.lower():
            print(f"ERROR: Email {email} already registered.")
            return None

    # Create new user record
    new_user = {
        "user_id"    : "U" + str(uuid4())[:8].upper(),
        "name"       : name.strip(),
        "email"      : email.strip().lower(),
        "password"   : password,
        "phone"      : phone.strip(),
        "role"       : role,   # ✅ NEW FIELD
        "date_joined": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    users.append(new_user)
    save_json(USERS_FILE, users)
    print(f"✅ User registered: {new_user['user_id']} — {new_user['name']}")
    return new_user


def get_user_by_id(user_id):
    """Fetch a user record by their user_id."""
    users = load_json(USERS_FILE)
    for user in users:
        if user["user_id"] == user_id:
            return user
    return None


def get_user_by_email(email):
    """Fetch a user record by their email."""
    users = load_json(USERS_FILE)
    for user in users:
        if user["email"].lower() == email.strip().lower():
            return user
    return None


def get_all_users():
    """Return all registered users."""
    return load_json(USERS_FILE)


# ════════════════════════════════════════════════════════════════════
# POLICY MANAGEMENT — policies.json
# ════════════════════════════════════════════════════════════════════

AVAILABLE_POLICIES = [
    {
        "policy_type"     : "Car Insurance",
        "coverage_amount" : 50000,
        "premium_amount"  : 500,
        "description"     : "Covers accidents, collisions and third-party damage."
    },
    {
        "policy_type"     : "Health Insurance",
        "coverage_amount" : 100000,
        "premium_amount"  : 800,
        "description"     : "Covers hospitalization, emergency care and surgery."
    },
    {
        "policy_type"     : "Travel Insurance",
        "coverage_amount" : 5000,
        "premium_amount"  : 200,
        "description"     : "Covers trip cancellation, baggage loss and medical emergencies abroad."
    },
    {
        "policy_type"     : "Home Insurance",
        "coverage_amount" : 75000,
        "premium_amount"  : 600,
        "description"     : "Covers property damage, theft and natural disasters."
    }
]


def get_available_policies():
    """Return the list of insurance policies available for purchase."""
    return AVAILABLE_POLICIES


def buy_policy(user_id, policy_type):
    """Purchase an insurance policy for a user and save to policies.json."""
    
    if not get_user_by_id(user_id):
        print(f"ERROR: User {user_id} not found.")
        return None

    policy_template = None
    for p in AVAILABLE_POLICIES:
        if p["policy_type"].lower() == policy_type.lower():
            policy_template = p
            break

    if not policy_template:
        print(f"ERROR: Policy type '{policy_type}' not available.")
        return None

    policies = load_json(POLICIES_FILE)

    new_policy = {
        "policy_id"      : "POL" + str(uuid4())[:8].upper(),
        "user_id"        : user_id,
        "policy_type"    : policy_template["policy_type"],
        "coverage_amount": policy_template["coverage_amount"],
        "premium_amount" : policy_template["premium_amount"],
        "purchase_date"  : datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "status"         : "Active"
    }

    policies.append(new_policy)
    save_json(POLICIES_FILE, policies)
    print(f"✅ Policy purchased: {new_policy['policy_id']} — {new_policy['policy_type']}")
    return new_policy


def get_user_policies(user_id):
    """Get all insurance policies purchased by a specific user."""
    policies = load_json(POLICIES_FILE)
    return [p for p in policies if p["user_id"] == user_id]


def get_policy_by_id(policy_id):
    """Fetch a specific policy by its policy_id."""
    policies = load_json(POLICIES_FILE)
    for policy in policies:
        if policy["policy_id"] == policy_id:
            return policy
    return None


# ════════════════════════════════════════════════════════════════════
# CLAIM MANAGEMENT — claims.json
# ════════════════════════════════════════════════════════════════════

def submit_claim(user_id, policy_id, description, documents=None):
    """File a new insurance claim and save to claims.json."""
    
    if not description or not description.strip():
        print("ERROR: Claim description is required.")
        return None

    if not get_user_by_id(user_id):
        print(f"ERROR: User {user_id} not found.")
        return None

    if not get_policy_by_id(policy_id):
        print(f"ERROR: Policy {policy_id} not found.")
        return None

    claims = load_json(CLAIMS_FILE)

    new_claim = {
        "claim_id"         : "CLM" + str(uuid4())[:8].upper(),
        "user_id"          : user_id,
        "policy_id"        : policy_id,
        "claim_description": description.strip(),
        "documents"        : documents if documents else [],
        "submission_date"  : datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "status"           : "Pending Review"
    }

    claims.append(new_claim)
    save_json(CLAIMS_FILE, claims)
    print(f"✅ Claim submitted: {new_claim['claim_id']}")
    return new_claim


def get_claim_by_id(claim_id):
    """Fetch a specific claim by its claim_id."""
    claims = load_json(CLAIMS_FILE)
    for claim in claims:
        if claim["claim_id"] == claim_id:
            return claim
    return None


def get_user_claims(user_id):
    """Get all claims filed by a specific user."""
    claims = load_json(CLAIMS_FILE)
    return [c for c in claims if c["user_id"] == user_id]


def get_pending_claims():
    """Get all claims with status 'Pending Review'."""
    claims = load_json(CLAIMS_FILE)
    return [c for c in claims if c["status"] == "Pending Review"]


def get_all_claims():
    """Return every claim in the system."""
    return load_json(CLAIMS_FILE)


def update_claim_status(claim_id, new_status):
    """Update the status of a claim."""
    valid_statuses = ["Pending Review", "Approved", "Rejected", "More Info Needed"]
    if new_status not in valid_statuses:
        print(f"ERROR: Invalid status '{new_status}'.")
        return False

    claims = load_json(CLAIMS_FILE)
    updated = False

    for claim in claims:
        if claim["claim_id"] == claim_id:
            claim["status"] = new_status
            claim["last_updated"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            updated = True
            break

    if updated:
        save_json(CLAIMS_FILE, claims)
        print(f"✅ Claim {claim_id} status updated to: {new_status}")
    else:
        print(f"ERROR: Claim {claim_id} not found.")

    return updated


# ════════════════════════════════════════════════════════════════════
# DECISION MANAGEMENT — decisions.json
# ════════════════════════════════════════════════════════════════════

def save_decision(claim_id, officer_id, decision, comments, ai_suggestion=""):
    """Save an officer's decision on a claim."""
    
    if not get_claim_by_id(claim_id):
        print(f"ERROR: Claim {claim_id} not found.")
        return None

    decisions = load_json(DECISIONS_FILE)

    new_decision = {
        "decision_id"  : "DEC" + str(uuid4())[:8].upper(),
        "claim_id"     : claim_id,
        "officer_id"   : officer_id,
        "decision"     : decision,
        "comments"     : comments.strip() if comments else "",
        "ai_suggestion": ai_suggestion,
        "decision_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }

    decisions.append(new_decision)
    save_json(DECISIONS_FILE, decisions)

    update_claim_status(claim_id, decision)

    print(f"✅ Decision saved: {new_decision['decision_id']} — {decision}")
    return new_decision


def get_decision_by_claim(claim_id):
    """Get the officer's decision for a specific claim."""
    decisions = load_json(DECISIONS_FILE)
    for decision in decisions:
        if decision["claim_id"] == claim_id:
            return decision
    return None


def get_all_decisions():
    """Return all officer decisions."""
    return load_json(DECISIONS_FILE)