"""
PDF Report Generator for Insurance Claims - FIXED
Generates professional PDF reports with claim analysis, fraud detection, and decision
Fixed: hexValue() error - using hex string directly
"""

import os
from datetime import datetime
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak, Image
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT, TA_JUSTIFY
import json

class ClaimReportGenerator:
    """Generate professional PDF reports for insurance claims"""
    
    def __init__(self):
        self.styles = getSampleStyleSheet()
        self.setup_custom_styles()
        os.makedirs("data/reports", exist_ok=True)
    
    def setup_custom_styles(self):
        """Setup custom paragraph styles"""
        # Title style
        self.styles.add(ParagraphStyle(
            name='CustomTitle',
            parent=self.styles['Heading1'],
            fontSize=24,
            textColor=colors.HexColor('#1f77b4'),
            spaceAfter=30,
            alignment=TA_CENTER,
            fontName='Helvetica-Bold'
        ))
        
        # Heading style
        self.styles.add(ParagraphStyle(
            name='CustomHeading',
            parent=self.styles['Heading2'],
            fontSize=14,
            textColor=colors.HexColor('#1f77b4'),
            spaceAfter=12,
            spaceBefore=12,
            fontName='Helvetica-Bold'
        ))
        
        # Normal style
        self.styles.add(ParagraphStyle(
            name='CustomNormal',
            parent=self.styles['Normal'],
            fontSize=10,
            alignment=TA_JUSTIFY,
            spaceAfter=6
        ))
        
        # Label style
        self.styles.add(ParagraphStyle(
            name='Label',
            parent=self.styles['Normal'],
            fontSize=9,
            textColor=colors.HexColor('#666666'),
            fontName='Helvetica-Bold'
        ))
    
    def generate_claim_report(self, claim_data, fraud_analysis, document_validation, final_decision):
        """
        Generate a comprehensive PDF report for a claim
        
        Args:
            claim_data: Claim information dict
            fraud_analysis: Fraud detection results dict
            document_validation: Document validation results dict
            final_decision: Final approval/rejection decision dict
        
        Returns:
            str: Path to generated PDF file
        """
        
        claim_id = claim_data.get('claim_id', 'CLAIM')
        insurance_type = claim_data.get('policy_type', 'Insurance')
        
        # Create PDF file path
        pdf_filename = f"data/reports/CLAIM_{claim_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        
        # Create PDF document
        doc = SimpleDocTemplate(
            pdf_filename,
            pagesize=letter,
            rightMargin=0.75*inch,
            leftMargin=0.75*inch,
            topMargin=0.75*inch,
            bottomMargin=0.75*inch
        )
        
        # Build story (content)
        story = []
        
        # ========================
        # HEADER & TITLE
        # ========================
        story.append(Paragraph("🏢 INSURANCE CLAIM REPORT", self.styles['CustomTitle']))
        story.append(Spacer(1, 0.2*inch))
        
        # Report Date
        report_date = datetime.now().strftime("%B %d, %Y at %I:%M %p")
        story.append(Paragraph(f"<b>Report Generated:</b> {report_date}", self.styles['CustomNormal']))
        story.append(Spacer(1, 0.3*inch))
        
        # ========================
        # SECTION 1: CLAIM DETAILS
        # ========================
        story.append(Paragraph("1. CLAIM DETAILS", self.styles['CustomHeading']))
        
        claim_details = [
            ['Claim ID:', claim_data.get('claim_id', 'N/A')],
            ['Insurance Type:', insurance_type],
            ['Claim Status:', claim_data.get('status', 'Pending Review')],
            ['Submission Date:', claim_data.get('submission_date', 'N/A')],
            ['Policy ID:', claim_data.get('policy_id', 'N/A')],
        ]
        
        claim_table = Table(claim_details, colWidths=[2*inch, 4*inch])
        claim_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#f0f0f0')),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 1, colors.lightgrey)
        ]))
        
        story.append(claim_table)
        story.append(Spacer(1, 0.3*inch))
        
        # Claim Description
        story.append(Paragraph("<b>Claim Description:</b>", self.styles['Label']))
        claim_desc = claim_data.get('claim_description', 'No description provided')
        story.append(Paragraph(claim_desc, self.styles['CustomNormal']))
        story.append(Spacer(1, 0.3*inch))
        
        # ========================
        # SECTION 2: DOCUMENT VALIDATION
        # ========================
        story.append(Paragraph("2. DOCUMENT VALIDATION", self.styles['CustomHeading']))
        
        doc_valid = document_validation.get('valid', False)
        completion = document_validation.get('completion_percentage', 0)
        
        # Status indicator - FIXED: Use hex string directly
        status_color_hex = "#00aa00" if doc_valid else "#ff0000"
        status_text = "✅ COMPLETE" if doc_valid else "❌ INCOMPLETE"
        
        doc_info = [
            ['Status:', Paragraph(f'<font color="{status_color_hex}"><b>{status_text}</b></font>', self.styles['Normal'])],
            ['Completion:', f"{completion}%"],
            ['Required Documents:', str(len(document_validation.get('required_documents', [])))],
            ['Uploaded Documents:', str(len(document_validation.get('uploaded_documents', [])))],
            ['Missing Documents:', str(len(document_validation.get('missing_documents', [])))],
        ]
        
        doc_table = Table(doc_info, colWidths=[2*inch, 4*inch])
        doc_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#f0f0f0')),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 1, colors.lightgrey)
        ]))
        
        story.append(doc_table)
        story.append(Spacer(1, 0.15*inch))
        
        # Documents list
        if document_validation.get('uploaded_documents'):
            story.append(Paragraph("<b>Uploaded Documents:</b>", self.styles['Label']))
            docs_text = ", ".join(document_validation.get('uploaded_documents', []))
            story.append(Paragraph(docs_text, self.styles['CustomNormal']))
        
        if document_validation.get('missing_documents'):
            story.append(Paragraph("<b>Missing Documents:</b>", self.styles['Label']))
            missing_text = ", ".join(document_validation.get('missing_documents', []))
            story.append(Paragraph(f'<font color="red"><b>{missing_text}</b></font>', self.styles['CustomNormal']))
        
        story.append(Spacer(1, 0.3*inch))
        
        # ========================
        # SECTION 3: FRAUD DETECTION ANALYSIS
        # ========================
        story.append(Paragraph("3. FRAUD DETECTION ANALYSIS", self.styles['CustomHeading']))
        
        is_fraud = fraud_analysis.get('is_fraud', False)
        verdict = fraud_analysis.get('verdict', 'UNKNOWN')
        
        # FIXED: Use hex string directly instead of hexValue()
        fraud_color_hex = "#ff0000" if is_fraud else "#00aa00"
        fraud_status = "FRAUDULENT ❌" if is_fraud else "GENUINE ✅"
        
        fraud_info = [
            ['Verdict:', Paragraph(f'<font color="{fraud_color_hex}"><b>{verdict}</b></font>', self.styles['Normal'])],
            ['Status:', Paragraph(f'<font color="{fraud_color_hex}"><b>{fraud_status}</b></font>', self.styles['Normal'])],
            ['Risk Level:', 'HIGH' if is_fraud else 'LOW'],
            ['Recommended Action:', fraud_analysis.get('action', 'INVESTIGATE')],
        ]
        
        fraud_table = Table(fraud_info, colWidths=[2*inch, 4*inch])
        fraud_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#f0f0f0')),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 1, colors.lightgrey)
        ]))
        
        story.append(fraud_table)
        story.append(Spacer(1, 0.15*inch))
        
        # Analysis reason
        story.append(Paragraph("<b>Analysis Reason:</b>", self.styles['Label']))
        reason = fraud_analysis.get('reason', 'No detailed analysis provided')
        story.append(Paragraph(reason, self.styles['CustomNormal']))
        story.append(Spacer(1, 0.3*inch))
        
        # ========================
        # SECTION 4: FINAL DECISION
        # ========================
        story.append(Paragraph("4. FINAL DECISION", self.styles['CustomHeading']))
        
        final_status = final_decision.get('final_decision', 'PENDING')
        recommendation = final_decision.get('recommendation', 'Under review')
        
        # Decision color coding - FIXED: Use hex strings directly
        if 'APPROVED' in final_status:
            decision_color_hex = "#00aa00"
            decision_emoji = "✅"
        elif 'REJECTED' in final_status:
            decision_color_hex = "#ff0000"
            decision_emoji = "❌"
        else:
            decision_color_hex = "#ffaa00"
            decision_emoji = "⚠️"
        
        # Big decision box
        decision_text = f'<font color="{decision_color_hex}" size=16><b>{decision_emoji} {final_status}</b></font>'
        story.append(Paragraph(decision_text, self.styles['CustomHeading']))
        story.append(Spacer(1, 0.15*inch))
        
        # Decision details
        final_info = [
            ['Status:', final_status],
            ['Recommendation:', recommendation],
            ['Decision Date:', datetime.now().strftime("%B %d, %Y")],
            ['Decision Time:', datetime.now().strftime("%I:%M %p")],
        ]
        
        final_table = Table(final_info, colWidths=[2*inch, 4*inch])
        final_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#f0f0f0')),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 9),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 1, colors.lightgrey)
        ]))
        
        story.append(final_table)
        story.append(Spacer(1, 0.3*inch))
        
        # ========================
        # SECTION 5: SUMMARY
        # ========================
        story.append(Paragraph("5. ASSESSMENT SUMMARY", self.styles['CustomHeading']))
        
        summary_text = f"""
        <b>Claim ID:</b> {claim_id}<br/>
        <b>Insurance Type:</b> {insurance_type}<br/>
        <b>Document Validation:</b> {'✅ PASSED' if doc_valid else '❌ FAILED'}<br/>
        <b>Fraud Detection:</b> {'❌ FRAUD DETECTED' if is_fraud else '✅ GENUINE'}<br/>
        <b>Final Status:</b> <b><font color="{'#00aa00' if 'APPROVED' in final_status else '#ff0000'}">{final_status}</font></b><br/>
        """
        
        story.append(Paragraph(summary_text, self.styles['CustomNormal']))
        story.append(Spacer(1, 0.3*inch))
        
        # ========================
        # FOOTER
        # ========================
        story.append(Spacer(1, 0.2*inch))
        
        footer_text = """
        <i>This is an automated report generated by the Insurance Claims Processing System.<br/>
        All analysis is based on AI fraud detection and document validation algorithms.<br/>
        Final approval requires officer review and authorization.</i>
        """
        story.append(Paragraph(footer_text, self.styles['Normal']))
        
        story.append(Spacer(1, 0.1*inch))
        
        generated_text = f"Report Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        story.append(Paragraph(generated_text, self.styles['Normal']))
        
        # Build PDF
        try:
            doc.build(story)
            print(f"✅ PDF Report generated: {pdf_filename}")
            return pdf_filename
        except Exception as e:
            print(f"❌ Error generating PDF: {e}")
            return None
    
    def save_report_json(self, claim_data, fraud_analysis, document_validation, final_decision):
        """Save report as JSON"""
        report = {
            "claim_data": claim_data,
            "fraud_analysis": fraud_analysis,
            "document_validation": document_validation,
            "final_decision": final_decision,
            "generated_at": datetime.now().isoformat()
        }
        
        claim_id = claim_data.get('claim_id', 'CLAIM')
        json_filename = f"data/reports/CLAIM_{claim_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        try:
            with open(json_filename, 'w') as f:
                json.dump(report, f, indent=2)
            print(f"✅ JSON Report saved: {json_filename}")
            return json_filename
        except Exception as e:
            print(f"❌ Error saving JSON: {e}")
            return None


# ================================
# USAGE EXAMPLE
# ================================

if __name__ == "__main__":
    # Sample data
    claim_data = {
        'claim_id': 'CLM3F9A1B2C',
        'policy_type': 'Health Insurance',
        'status': 'Pending Review',
        'submission_date': '2024-02-25',
        'policy_id': 'POL3F9A1B2C',
        'claim_description': 'Admitted to Apollo Hospital with acute chest pain and breathlessness. Emergency cardiac catheterization and stent placement performed. Hospital stay: 5 days.'
    }
    
    fraud_analysis = {
        'is_fraud': False,
        'verdict': 'GENUINE',
        'reason': 'Claim has proper documentation, specific dates, hospital records, and medical diagnosis confirmed by tests',
        'action': 'APPROVE'
    }
    
    document_validation = {
        'valid': True,
        'completion_percentage': 100.0,
        'required_documents': ['medical_report', 'hospital_bill', 'discharge_summary'],
        'uploaded_documents': ['medical_report.pdf', 'hospital_bill.pdf', 'discharge_summary.pdf'],
        'missing_documents': []
    }
    
    final_decision = {
        'final_decision': 'APPROVED',
        'recommendation': 'Claim appears genuine and complete. Payment authorized.'
    }
    
    # Generate reports
    generator = ClaimReportGenerator()
    pdf_path = generator.generate_claim_report(claim_data, fraud_analysis, document_validation, final_decision)
    json_path = generator.save_report_json(claim_data, fraud_analysis, document_validation, final_decision)
    
    print(f"\n✅ Reports generated:")
    print(f"   PDF: {pdf_path}")
    print(f"   JSON: {json_path}")